import { Construct } from 'constructs';
import { Duration } from 'aws-cdk-lib';
import { Schedule } from 'aws-cdk-lib/aws-scheduler';
import {
  ScalableTarget,
  ServiceNamespace,
  TargetTrackingScalingPolicy,
  PredefinedMetric,
} from 'aws-cdk-lib/aws-applicationautoscaling';
import {
  GraphWidget,
  Dashboard,
  Metric,
  Stats,
} from 'aws-cdk-lib/aws-cloudwatch';
import { Alias, Function } from 'aws-cdk-lib/aws-lambda';

export interface LambdaProvisionedConcurrencyScalingConfig {
  /**
   * Minimum provisioned concurrency
   * @default 1
   */
  minProvisionedConcurrency?: number;
  /**
   * Maximum provisioned concurrency
   * @default 10
   */
  maxProvisionedConcurrency?: number;
  scheduledConcurrency?: {
    enabled: boolean;
    min: number;
    schedule: Schedule;
  };
  /**
   * Autoscaling configuration for lambda provisioned concurrency
   */
  autoscaling?: {
    enabled: boolean;
    /**
     * Desired provisioned concurrency utilization percentage expressed as a decimal
     * @default 0.7
     */
    provisionedConcurrencyUtilizationPercentage?: number;
    /**
     * The name of the target tracking policy
     * @default `${id}-TargetTrackingPolicy`
     */
    policyName?: string;
    /**
     * The amount of time in seconds to wait after a scale in activity completes before another scale in activity can start
     * @default 0
     */
    scaleInCooldown?: Duration;
    /**
     * The amount of time in seconds to wait after a scale out activity completes before another scale out activity can start
     * @default 0
     */
    scaleOutCooldown?: Duration;
  };
}

export interface LambdaProvisionedConcurrencyScalingProps {
  /**
   * Lambda function to provision concurrency for
   */
  lambdaFunction: Function;
  /**
   * Alias used by the lambda function
   */
  lambdaFunctionAlias: Alias;
  /**
   * CloudWatch dashboard to add widgets to
   */
  cloudWatchDashboard?: Dashboard;
  config: LambdaProvisionedConcurrencyScalingConfig;
}

const MIN_PROVISIONED_CONCURRENCY = 1;
const MAX_PROVISIONED_CONCURRENCY = 10;
const DEFAULT_PROVISIONED_CONCURRENCY_UTILIZATION_PERCENTAGE = 0.7;

export class LambdaProvisionedConcurrencyScaling extends Construct {
  constructor(
    scope: Construct,
    id: string,
    props: LambdaProvisionedConcurrencyScalingProps
  ) {
    super(scope, id);

    const { lambdaFunctionAlias, config } = props;
    const { autoscaling } = config;
    const lambdaFunctionName = props.lambdaFunction.functionName;

    // validate props
    if (
      autoscaling?.provisionedConcurrencyUtilizationPercentage &&
      (autoscaling?.provisionedConcurrencyUtilizationPercentage < 0.1 ||
        autoscaling?.provisionedConcurrencyUtilizationPercentage > 0.9)
    ) {
      throw new Error(
        'provisionedConcurrencyUtilizationPercentage must be between 0.1 and 0.9'
      );
    }

    const scalableTarget = new ScalableTarget(this, `${id}-ScalableTarget`, {
      minCapacity:
        config.minProvisionedConcurrency ?? MIN_PROVISIONED_CONCURRENCY,
      maxCapacity:
        config.maxProvisionedConcurrency ?? MAX_PROVISIONED_CONCURRENCY,
      resourceId: `function:${lambdaFunctionName}:${lambdaFunctionAlias.aliasName}`,
      scalableDimension: 'lambda:function:ProvisionedConcurrency',
      serviceNamespace: ServiceNamespace.LAMBDA,
    });
    // manually add dependency to prevent scalable target from being created before alias
    scalableTarget.node.addDependency(lambdaFunctionAlias);

    if (config.scheduledConcurrency?.enabled) {
      //TODO
      throw new Error('Scheduled concurrency not implemented yet');
    }

    if (autoscaling?.enabled) {
      new TargetTrackingScalingPolicy(this, `${id}-TargetTrackingPolicy`, {
        scalingTarget: scalableTarget,
        targetValue:
          autoscaling.provisionedConcurrencyUtilizationPercentage ??
          DEFAULT_PROVISIONED_CONCURRENCY_UTILIZATION_PERCENTAGE,
        policyName: autoscaling.policyName ?? `${id}-TargetTrackingPolicy`,
        predefinedMetric:
          PredefinedMetric.LAMBDA_PROVISIONED_CONCURRENCY_UTILIZATION,
        scaleInCooldown: autoscaling.scaleInCooldown,
        scaleOutCooldown: autoscaling.scaleOutCooldown,
      });
    }

    if (props.cloudWatchDashboard) {
      const provisionedConcurrencyInvocationsMetric = new Metric({
        namespace: 'AWS/Lambda',
        metricName: 'ProvisionedConcurrentExecutions',
        dimensionsMap: {
          FunctionName: lambdaFunctionName,
        },
        period: Duration.minutes(5),
        statistic: Stats.SUM,
        label: 'Provisioned Concurrency Invocations',
      });

      const spilloverInvocationsMetric = new Metric({
        namespace: 'AWS/Lambda',
        metricName: 'ProvisionedConcurrencySpilloverInvocations',
        dimensionsMap: {
          FunctionName: lambdaFunctionName,
        },
        period: Duration.minutes(5),
        statistic: Stats.SUM,
        label: 'Spillover Invocations',
      });

      const utilizationMetric = new Metric({
        namespace: 'AWS/Lambda',
        metricName: 'ProvisionedConcurrencyUtilization',
        dimensionsMap: {
          FunctionName: lambdaFunctionName,
          Resource: `${lambdaFunctionName}:${lambdaFunctionAlias.aliasName}`,
        },
        period: Duration.minutes(5),
        statistic: Stats.AVERAGE,
        label: 'Provisioned Concurrency Utilization Percentage (0-1)',
      });

      props.cloudWatchDashboard.addWidgets(
        new GraphWidget({
          title: `Provisioned Concurrency Invocations - ${lambdaFunctionName}`,
          left: [
            provisionedConcurrencyInvocationsMetric,
            spilloverInvocationsMetric,
          ],
        }),
        new GraphWidget({
          title: `Provisioned Concurrency Utilization - ${lambdaFunctionName}`,
          left: [utilizationMetric],
        })
      );
    }
  }
}
