# LambdaProvisionedConcurrencyScaling CDK Construct

## Overview

The `LambdaProvisionedConcurrencyScaling` construct enables provisioned concurrency for lambda functions, with built-in support for autoscaling and monitoring. This construct helps ensure your lambda functions are always warm and ready to handle traffic, reducing cold starts and improving latency for critical workloads.

---

## How It Works: Application Auto Scaling for Lambda

When you use this construct, the following AWS resources and logic are created:

- **Scalable Target:**
  - An Application Auto Scaling scalable target is created for your Lambda function alias.
  - The scalable target manages the `ProvisionedConcurrency` for your Lambda function, using the resource ID format: `function:<lambda-function-name>:<alias>`.
  - You specify `minCapacity` and `maxCapacity` to bound the provisioned concurrency.

- **Target Tracking Scaling Policy:**
  - If autoscaling is enabled, a target tracking scaling policy is attached to the scalable target.
  - The policy tracks the `ProvisionedConcurrencyUtilization` metric and automatically adjusts provisioned concurrency to keep utilization near a configurable target value (default: 0.7).
  - Cooldown periods can be configured for scale-in and scale-out events.

- **Dependency Management:**
  - The construct ensures the scalable target is created after the Lambda alias, preventing race conditions during deployment.

- **Scheduled Concurrency (Planned):**
  - The construct is designed to support scheduled concurrency, allowing you to scale provisioned concurrency based on a schedule (feature not yet implemented).

---

## Monitoring

This construct can automatically add CloudWatch Dashboard widgets for key Lambda provisioned concurrency metrics. These widgets help you monitor concurrency, utilization, and spillover events in real time.

### Metrics Visualized

- **ProvisionedConcurrentExecutions:** Number of Lambda executions served by provisioned concurrency.
- **ProvisionedConcurrencySpilloverInvocations:** Number of invocations that couldn't be served by provisioned concurrency and fell back to on-demand (potential cold starts).
- **ProvisionedConcurrencyUtilization:** The percentage utilization (0-1) of the provisioned concurrency.

### Example: CloudWatch Dashboard Widget Code

Below are the code snippets used in the construct to add these widgets to your dashboard:

```typescript
const provisionedConcurrencyInvocationsMetric = new Metric({
  namespace: 'AWS/Lambda',
  metricName: 'ProvisionedConcurrentExecutions',
  dimensionsMap: {
    FunctionName: lambdaFunctionName,
  },
  period: Duration.minutes(5),
  statistic: Stats.SUM,
  label: 'Provisioned Concurrency Invocations',
});

const spilloverInvocationsMetric = new Metric({
  namespace: 'AWS/Lambda',
  metricName: 'ProvisionedConcurrencySpilloverInvocations',
  dimensionsMap: {
    FunctionName: lambdaFunctionName,
  },
  period: Duration.minutes(5),
  statistic: Stats.SUM,
  label: 'Spillover Invocations',
});

const utilizationMetric = new Metric({
  namespace: 'AWS/Lambda',
  metricName: 'ProvisionedConcurrencyUtilization',
  dimensionsMap: {
    FunctionName: lambdaFunctionName,
    Resource: `${lambdaFunctionName}:${lambdaFunctionAlias}`,
  },
  period: Duration.minutes(5),
  statistic: Stats.AVERAGE,
  label: 'Provisioned Concurrency Utilization Percentage (0-1)',
});

props.cloudWatchDashboard.addWidgets(
  new GraphWidget({
    title: `Provisioned Concurrency Invocations - ${lambdaFunctionName}`,
    left: [
      provisionedConcurrencyInvocationsMetric,
      spilloverInvocationsMetric,
    ],
  }),
  new GraphWidget({
    title: `Provisioned Concurrency Utilization - ${lambdaFunctionName}`,
    left: [utilizationMetric],
  })
);
```

---

## References

- [AWS Lambda Provisioned Concurrency](https://docs.aws.amazon.com/lambda/latest/dg/provisioned-concurrency.html)
- CLI commands for introspection:
  - `aws application-autoscaling describe-scaling-policies --service-namespace lambda`
  - `aws application-autoscaling describe-scheduled-actions --service-namespace lambda`

---

## Example Usage

```typescript
new LambdaProvisionedConcurrencyScaling(this, 'MyProvisionedConcurrency', {
  lambdaFunction,
  lambdaFunctionAlias,
  cloudWatchDashboard,
  config: {
    minProvisionedConcurrency: 2,
    maxProvisionedConcurrency: 10,
    autoscaling: {
      enabled: true,
      provisionedConcurrencyUtilizationPercentage: 0.7,
    },
  },
});
```
