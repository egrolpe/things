import { Duration } from 'aws-cdk-lib';
import { CfnPermission, Function, FunctionProps } from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';

export interface ConnectFunctionProps extends FunctionProps {
  instanceArn: string;
}

export class ConnectFunction extends Function {
  constructor(scope: Construct, id: string, props: ConnectFunctionProps) {
    // Ensure valid timeout
    const timeout = props.timeout ?? Duration.seconds(8);
    if (timeout.toSeconds() > 8) {
      throw new Error(
        `Invalid timeout: ${timeout.toSeconds()} seconds. Timeout for Connect lambdas must be less than or equal to 8 seconds.`
      );
    }

    super(scope, id, {
      ...props,
      timeout,
    });

    // create permission for connect to invoke lambda
    new CfnPermission(this, `${id}-connect-permission`, {
      action: 'lambda:InvokeFunction',
      functionName: this.functionName,
      principal: 'connect.amazonaws.com',
      sourceArn: props.instanceArn,
    });
  }
}
