import { CfnOutput, Duration, Stack } from 'aws-cdk-lib';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as cloudwatchActions from 'aws-cdk-lib/aws-cloudwatch-actions';
import { Table } from 'aws-cdk-lib/aws-dynamodb';
import { Rule, RuleTargetInput, Schedule } from 'aws-cdk-lib/aws-events';
import { LambdaFunction } from 'aws-cdk-lib/aws-events-targets';
import {
  Effect,
  ManagedPolicy,
  Policy,
  PolicyStatement,
  Role,
  ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';
import { Alias, Code, Function, Runtime } from 'aws-cdk-lib/aws-lambda';
import * as sns from 'aws-cdk-lib/aws-sns';
import * as subscriptions from 'aws-cdk-lib/aws-sns-subscriptions';
import { Construct } from 'constructs';
import { ConnectFunction } from './constructs/lambda/ConnectFunction';
import {
  LambdaProvisionedConcurrencyScaling,
  LambdaProvisionedConcurrencyScalingConfig,
} from './constructs/lambda/LambdaProvisionedConcurrencyScaling';

export interface ConnectLamdaProps {
  configTable: Table;
  prefix: string;
  instanceArn: string;
  stage: string;
  region: string;
  snsSubscriptionEmail: string;
  LambdaProvisionedConcurrencyScalingConfig?: LambdaProvisionedConcurrencyScalingConfig;
}

const LAMBDA_ALIAS = 'active';

// connect lambdas facilitating functionality for Amazon Connect
export class ConnectLamdas extends Construct {
  constructor(scope: Construct, id: string, props: ConnectLamdaProps) {
    super(scope, id);

    const region = props.region;
    const account = Stack.of(this).account;

    const commonFunctionProps = {
      runtime: Runtime.NODEJS_22_X,
      timeout: Duration.seconds(8),
      handler: 'index.handler',
    };

    // Set provisioned concurrency to 1 if detailed provisioned concurrency config is not used
    const provisionedConcurrentExecutions = !props
      .LambdaProvisionedConcurrencyScalingConfig?.autoscaling?.enabled
      ? 1
      : undefined;

    // #region config-retrieval lambda

    // create retrieve config lambda
    const retrieveConfigFn = new ConnectFunction(this, 'config-retrieval', {
      ...commonFunctionProps,
      functionName: `${props.prefix}-config-retrieval`,
      code: Code.fromAsset('./dist/retrieveConfig'),
      instanceArn: props.instanceArn,
      environment: {
        DDB_TABLE: props.configTable.tableName,
        LEX_PREFIX: props.prefix,
        SALESFORCE_PREFIX: '',
      },
    });

    retrieveConfigFn.role?.addManagedPolicy(
      ManagedPolicy.fromAwsManagedPolicyName(
        'service-role/AWSLambdaBasicExecutionRole'
      )
    );

    // grant permissions to retrieveConfigFn lambda
    props.configTable.grantReadWriteData(retrieveConfigFn);

    // create version of lambda
    const retrieveConfigVersion = retrieveConfigFn.currentVersion;

    // Add an alias to the Lambda function with provisioned concurrency
    const retrieveConfigAlias = new Alias(this, 'config-retrieval-alias', {
      aliasName: LAMBDA_ALIAS,
      version: retrieveConfigVersion,
      provisionedConcurrentExecutions,
    });

    // detailed provisioned concurrency config
    if (props.LambdaProvisionedConcurrencyScalingConfig?.autoscaling?.enabled) {
      new LambdaProvisionedConcurrencyScaling(
        this,
        'config-retrieval-provisioned-concurrency',
        {
          lambdaFunction: retrieveConfigFn,
          lambdaFunctionAlias: retrieveConfigAlias,
          config: props.LambdaProvisionedConcurrencyScalingConfig,
        }
      );
    }

    // Create CloudWatch metric for Lambda errors
    const retrieveConfigFnErrorMetric = new cloudwatch.Metric({
      namespace: 'AWS/Lambda',
      metricName: 'Errors',
      dimensionsMap: {
        FunctionName: retrieveConfigFn.functionName,
      },
      period: Duration.minutes(5),
      statistic: 'Sum',
    });

    // Create CloudWatch Alarm for Lambda errors
    const retrieveConfigFnErrorAlarm = new cloudwatch.Alarm(
      this,
      'ConfigRetrievalLambdaErrorAlarm',
      {
        alarmName: `${props.prefix}-config-retrieval-lambda-error-alarm`,
        metric: retrieveConfigFnErrorMetric,
        threshold: 0,
        comparisonOperator:
          cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
        evaluationPeriods: 1,
        treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
        actionsEnabled: true,
        alarmDescription:
          'The lambda that supports the AWS Connect flow for Spanish and French during runtime has failed.',
      }
    );

    // create output for lambda
    const retrieveConfigOutput = new CfnOutput(
      this,
      'arn-config-retrieval-output',
      {
        value: retrieveConfigAlias.functionArn,
        exportName: `${props.prefix}-config-retrieval-lambda-arn`,
      }
    );
    retrieveConfigOutput.overrideLogicalId('arnLambdaConfigRetrieval');

    // #endregion

    // #region Lex Fulfillment Lambda

    // create lex fulfillment lambda
    const lexHandlerFn = new Function(this, 'lex-handler', {
      ...commonFunctionProps,
      functionName: `${props.prefix}-lex-handler`,
      code: Code.fromAsset('./dist/lexHandler'),
      timeout: Duration.seconds(60),
      memorySize: 512,
      environment: {
        MIN_NLU_CONFIDENCE: '0.7',
        DDB_TABLE: props.configTable.tableName,
        CONNECT_INSTANCE_ARN: props.instanceArn,
      },
    });

    lexHandlerFn.role?.addManagedPolicy(
      ManagedPolicy.fromAwsManagedPolicyName(
        'service-role/AWSLambdaBasicExecutionRole'
      )
    );

    // grant permissions to retrieveConfigFn lambda
    props.configTable.grantReadData(lexHandlerFn);

    // Add permission for lex:RecognizeText
    lexHandlerFn.addToRolePolicy(
      new PolicyStatement({
        actions: ['lex:RecognizeText'],
        resources: ['*'],
      })
    );

    // create version of lambda
    const lexHandlerVersion = lexHandlerFn.currentVersion;

    // Add an alias to the Lambda function with provisioned concurrency
    const lexHandlerAlias = new Alias(this, 'lex-handler-alias', {
      aliasName: LAMBDA_ALIAS,
      version: lexHandlerVersion,
    });

    // Create CloudWatch metric for Lambda errors
    const lexHandlerFnErrorMetric = new cloudwatch.Metric({
      namespace: 'AWS/Lambda',
      metricName: 'Errors',
      dimensionsMap: {
        FunctionName: lexHandlerFn.functionName,
      },
      period: Duration.minutes(5),
      statistic: 'Sum',
    });

    // Create CloudWatch Alarm for Lambda errors
    const lexHandlerFnErrorAlarm = new cloudwatch.Alarm(
      this,
      'lexHandlerLambdaErrorAlarm',
      {
        alarmName: `${props.prefix}-lex-handler-lambda-error-alarm`,
        metric: lexHandlerFnErrorMetric,
        threshold: 0,
        comparisonOperator:
          cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
        evaluationPeriods: 1,
        treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
        actionsEnabled: true,
        alarmDescription:
          'The lambda that supports the Lex bots during runtime has failed',
      }
    );

    // create output for lambda
    const lexHandlerOutput = new CfnOutput(
      this,
      'arn-verbiage-fulfillment-output',
      {
        value: lexHandlerAlias.functionArn,
        exportName: `${props.prefix}-lex-handler-lambda-arn`,
      }
    );
    lexHandlerOutput.overrideLogicalId('arnLambdaLexHandler');

    // #endregion

    // #region Connect Sync Lambda

    // create connect sync lambda
    const connectSyncFn = new Function(this, 'connect-sync', {
      ...commonFunctionProps,
      functionName: `${props.prefix}-connect-sync`,
      code: Code.fromAsset('./dist/connectSync'),
      timeout: Duration.seconds(60),
      memorySize: 512,
      environment: {
        DDB_TABLE: props.configTable.tableName,
        INSTANCE_ID: props.instanceArn,
        REGION: region,
        BOT_ALIAS_NAME: 'active',
        LAMBDA_PREFIX: `${props.prefix}-`,
        LEX_PREFIX: `${props.prefix}-`,
        ACCOUNT_ID: account,
      },
    });

    connectSyncFn.role?.addManagedPolicy(
      ManagedPolicy.fromAwsManagedPolicyName(
        'service-role/AWSLambdaBasicExecutionRole'
      )
    );

    // grant permissions to retrieveConfigFn lambda
    props.configTable.grantReadWriteData(connectSyncFn);

    // create version of lambda
    const connectSyncVersion = connectSyncFn.currentVersion;

    // Add an alias to the Lambda function with provisioned concurrency
    const connectSyncAlias = new Alias(this, 'connect-sync-alias', {
      aliasName: LAMBDA_ALIAS,
      version: connectSyncVersion,
    });

    // create permission for connect to index lex/lambda
    const lambdaLexPermissions = new PolicyStatement({
      actions: [
        'lex:ListBots',
        'lex:ListBotAliases',
        'lambda:ListAliases',
        'lambda:ListFunctions',
      ],
      resources: ['*'],
    });

    connectSyncFn.addToRolePolicy(lambdaLexPermissions);

    // create output for lambda
    const connectSyncOutput = new CfnOutput(this, 'arn-connect-sync-output', {
      value: connectSyncAlias.functionArn,
      exportName: `${props.prefix}-connect-sync-lambda-arn`,
    });
    connectSyncOutput.overrideLogicalId('arnLambdaConnectSync');

    // create an eventbridge rule to trigger the connect sync lambda everyday at midnight
    const connectSyncRule = new Rule(this, 'connect-sync-rule', {
      schedule: Schedule.expression('cron(0 0 * * ? *)'),
      ruleName: `${props.prefix}-connect-sync-rule`,
    });

    // add target to rule
    connectSyncRule.addTarget(
      new LambdaFunction(connectSyncAlias, {
        event: RuleTargetInput.fromObject({
          source: 'connect-sync',
        }),
      })
    );

    connectSyncFn.addToRolePolicy(
      new PolicyStatement({
        actions: [
          'connect:ListQueues',
          'connect:ListContactFlows',
          'connect:ListContactFlowModules',
        ],
        resources: [
          `${props.instanceArn}/queue/*`,
          `${props.instanceArn}/contact-flow/*`,
          `${props.instanceArn}`,
          `${props.instanceArn}/flow-module/*`,
        ],
      })
    );

    // Create CloudWatch metric for Lambda errors
    const connectSyncFnErrorMetric = new cloudwatch.Metric({
      namespace: 'AWS/Lambda',
      metricName: 'Errors',
      dimensionsMap: {
        FunctionName: connectSyncFn.functionName,
      },
      period: Duration.minutes(5),
      statistic: 'Sum',
    });

    // Create CloudWatch Alarm for Lambda errors
    const connectSyncFnErrorAlarm = new cloudwatch.Alarm(
      this,
      'ConnectSyncLambdaErrorAlarm',
      {
        alarmName: `${props.prefix}-connect-sync-lambda-error-alarm`,
        metric: connectSyncFnErrorMetric,
        threshold: 0,
        comparisonOperator:
          cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
        evaluationPeriods: 1,
        treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
        actionsEnabled: true,
        alarmDescription:
          'The lambda that supports the loading of ARN and configurations into DynamoDB that supports Spanish and French flows has failed.',
      }
    );

    const lexLambdaRole = new Role(this, 'lexwarmer-role', {
      roleName: `${props.prefix}-${region}-lex-ivr-role`,
      assumedBy: new ServicePrincipal('lambda.amazonaws.com'),
      description: 'IAM role for IVR Lambdas to interface with Lex',
    });

    const lambdaInlinePolicy = new Policy(this, `lexwarmer-policy`, {
      statements: [
        new PolicyStatement({
          effect: Effect.ALLOW,
          actions: [
            'logs:CreateLogGroup',
            'logs:CreateLogStream',
            'logs:PutLogEvents',
            'lex:ListBots',
            'lex:ListBotVersions',
            'lex:ListBotAliases',
            'lex:RecognizeText',
            'lex:ListAggregatedUtterances',
            'lex:ListBotLocales',
          ],
          resources: ['*'],
        }),
      ],
    });
    lexLambdaRole.attachInlinePolicy(lambdaInlinePolicy);

    const lexWarmerRule = new Rule(this, 'lex-warmer-Rule', {
      schedule: Schedule.rate(Duration.minutes(4)),
      ruleName: `${props.prefix}-lex-warmer-rule`,
    });

    const lexWarmerLambda = new Function(this, 'lexWarmerLambda', {
      ...commonFunctionProps,
      functionName: `${props.prefix}-lex-warmer`,
      code: Code.fromAsset('./dist/lexWarmer'),
      timeout: Duration.seconds(90),
      memorySize: 512,
      role: lexLambdaRole,
      environment: {
        region,
      },
    });

    // add target to rule
    lexWarmerRule.addTarget(
      new LambdaFunction(lexWarmerLambda, {
        event: RuleTargetInput.fromObject({
          source: `${props.prefix}-lex-warmer-rule`,
        }),
      })
    );

    // Create CloudWatch metric for Lambda errors
    const lexWarmerLambdaErrorMetric = new cloudwatch.Metric({
      namespace: 'AWS/Lambda',
      metricName: 'Errors',
      dimensionsMap: {
        FunctionName: lexWarmerLambda.functionName,
      },
      period: Duration.minutes(5),
      statistic: 'Sum',
    });

    // Create CloudWatch Alarm for Lambda errors
    const lexWarmerLambdaErrorAlarm = new cloudwatch.Alarm(
      this,
      'lexWarmerLambdaErrorAlarm',
      {
        alarmName: `${props.prefix}-lex-warmer-lambda-error-alarm`,
        metric: lexWarmerLambdaErrorMetric,
        threshold: 0,
        comparisonOperator:
          cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
        evaluationPeriods: 1,
        treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
        actionsEnabled: true,
        alarmDescription: 'The lambda that keeps the lex bots warm has failed.',
      }
    );

    const lexInitializerLambda = new ConnectFunction(
      this,
      'lexInitializerLambda',
      {
        ...commonFunctionProps,
        functionName: `${props.prefix}-lex-initializer`,
        code: Code.fromAsset('./dist/lexInitializer'),
        instanceArn: props.instanceArn,
        memorySize: 512,
        role: lexLambdaRole,
        environment: {
          region,
          DDB_TABLE: props.configTable.tableName,
          LEX_PREFIX: props.prefix,
        },
      }
    );

    // grant permissions to lexInitializer lambda
    props.configTable.grantReadWriteData(lexInitializerLambda);

    // create version of lambda
    const lexInitializerLambdaVersion = lexInitializerLambda.currentVersion;

    // Add an alias to the Lambda function with provisioned concurrency
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const lexInitializerLambdaAlias = new Alias(
      this,
      'lex-initializer-lambda-alias',
      {
        aliasName: 'active',
        version: lexInitializerLambdaVersion,
        provisionedConcurrentExecutions,
      }
    );

    const asyncLambdaInvokerFn = new Function(this, 'asyncLambdaInvokerFn', {
      ...commonFunctionProps,
      functionName: `${props.prefix}-async-lambda-invoker`,
      code: Code.fromAsset('./dist/asyncLambdaInvoker'),
      timeout: Duration.seconds(90),
      memorySize: 512,
      role: lexLambdaRole,
      environment: {},
    });

    asyncLambdaInvokerFn.role?.addManagedPolicy(
      ManagedPolicy.fromAwsManagedPolicyName(
        'service-role/AWSLambdaBasicExecutionRole'
      )
    );

    // create version of lambda
    const asyncLambdaInvokerFnVersion = asyncLambdaInvokerFn.currentVersion;

    // Add an alias to the Lambda function with provisioned concurrency
    new Alias(this, 'async-lambda-invoker-fn-alias', {
      aliasName: LAMBDA_ALIAS,
      version: asyncLambdaInvokerFnVersion,
      provisionedConcurrentExecutions,
    });

    // #endregion

    // #region SNS
    // Create SNS topic for Lambda error notifications
    const errorTopic = new sns.Topic(this, 'LambdaErrorTopic', {
      topicName: `${props.prefix}-topic`,
    });

    // Subscribe the SNS topic to the CloudWatch Alarm
    errorTopic.addSubscription(
      new subscriptions.EmailSubscription(props.snsSubscriptionEmail)
    );

    // Add the CloudWatch Alarm action to publish to SNS topic
    retrieveConfigFnErrorAlarm.addAlarmAction(
      new cloudwatchActions.SnsAction(errorTopic)
    );

    // Add the CloudWatch Alarm action to publish to SNS topic
    lexHandlerFnErrorAlarm.addAlarmAction(
      new cloudwatchActions.SnsAction(errorTopic)
    );

    // Add the CloudWatch Alarm action to publish to SNS topic
    connectSyncFnErrorAlarm.addAlarmAction(
      new cloudwatchActions.SnsAction(errorTopic)
    );

    // Add the CloudWatch Alarm action to publish to SNS topic
    connectSyncFnErrorAlarm.addAlarmAction(
      new cloudwatchActions.SnsAction(errorTopic)
    );

    // Add the CloudWatch Alarm action to publish to SNS topic
    lexWarmerLambdaErrorAlarm.addAlarmAction(
      new cloudwatchActions.SnsAction(errorTopic)
    );

    // #endregion
  }
}
