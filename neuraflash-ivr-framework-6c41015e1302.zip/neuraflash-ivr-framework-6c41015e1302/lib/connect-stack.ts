import { Aws, Stack, StackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { ConfigTable } from './config-table';
import { ConnectLamdaProps, ConnectLamdas } from './connect-lambdas';
//import { ConnectReporting } from "./connect-reporting";

interface ConnectProps extends StackProps {
  configTableName: string;
  lambdaPrefixName: string;
  prefix: string;
  instanceArn: string;
  stage: string;
  accountNumber: string;
  snsSubscriptionEmail: string;
  connectLambdasProps: {
    LambdaProvisionedConcurrencyScalingConfig: ConnectLamdaProps['LambdaProvisionedConcurrencyScalingConfig'];
  };
}

// main stack for deploying resources
export class ConnectStack extends Stack {
  constructor(scope: Construct, id: string, props: ConnectProps) {
    super(scope, id, props);

    const { prefix, stage, env, instanceArn, snsSubscriptionEmail } = props;
    const region = env?.region ?? Aws.REGION;

    // create config table
    const configTable = new ConfigTable(
      this,
      `${region}-${props.configTableName}`,
      {
        prefix,
        tableName: props.configTableName,
      }
    );

    // create connect lambdas
    new ConnectLamdas(this, `${region}-${props.lambdaPrefixName}`, {
      ...props.connectLambdasProps,
      configTable: configTable.table,
      prefix,
      instanceArn,
      stage,
      region,
      snsSubscriptionEmail,
    });
  }
}
