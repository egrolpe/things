import { Construct } from "constructs";
import { Table, AttributeType, BillingMode } from "aws-cdk-lib/aws-dynamodb";
import { RemovalPolicy, CfnOutput } from "aws-cdk-lib";

export interface ConfigTableProps {
  prefix: string;
  tableName: string;
}

// config table for storing config values
export class ConfigTable extends Construct {
  public readonly table: Table;

  constructor(scope: Construct, id: string, props: ConfigTableProps) {
    super(scope, id);

    this.table = new Table(
      this,
      `${props.prefix}-${props.tableName}`,
      {
        tableName: `${props.prefix}-${props.tableName}`,
        partitionKey: {
          name: "Typing",
          type: AttributeType.STRING,
        },
        sortKey: {
          name: "Indexing",
          type: AttributeType.STRING,
        },
        billingMode: BillingMode.PAY_PER_REQUEST,
        pointInTimeRecoverySpecification: {
          pointInTimeRecoveryEnabled: true
        }
      }
    );

    this.table.applyRemovalPolicy(RemovalPolicy.DESTROY);

    const tableOutput = new CfnOutput(this, "arn-config-table", {
      value: this.table.tableArn,
      exportName: `${props.prefix}:arn-table-config-table`,
    });
    tableOutput.overrideLogicalId("arnTableConfigTable");
  }
}
