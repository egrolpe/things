const fs = require('fs');
const { parse } = require("csv-parse");
const yargs = require("yargs/yargs");

/**
 * CSV to JSON Converter for User Groups
 *
 * This script reads a CSV file containing User Group configurations and converts
 * it into a structured JSON format. It allows the user to specify the input
 * CSV file and the output JSON file through command-line arguments.
 *
 * The CSV file should have the following structure:
 * - Name: The name of the user group
 * - Level: The hierarchy level (number)
 * - ParentGroup: The parent group name (optional)
 *
 * The resulting JSON structure will include the following fields:
 * - Name: The name of the user group
 * - Level: The hierarchy level
 * - ParentGroup: The parent group name (if exists)
 *
 * Usage:
 *   node convertCsvToUserGroups.js --sourceFile path/to/input.csv --destinationFile path/to/output.json
 *
 * Command-line Arguments:
 * - --sourceFile: The path to the input CSV file (required).
 * - --destinationFile: The path to the output JSON file (required).
 *
 * Dependencies:
 * - fs: Node.js file system module for reading and writing files.
 * - csv-parse: A package to parse CSV files.
 * - yargs: A package to handle command-line arguments.
 *
 * Example:
 *   node convertCsvToUserGroups.js --sourceFile data/input/UserGroup.csv --destinationFile data/output/user-groups.json
 *
 * Author: Dan Dominguez, Henry Pizzo
 * Date: Sept 5, 2025
 */

// Get input and output file paths from command-line arguments
const argv = yargs(process.argv.slice(2))
    .usage("Usage: $0 --sourceFile [name] --destinationFile [name]")
    .demandOption(["sourceFile", "destinationFile"])
    .describe("sourceFile", "Specify CSV file to convert to JSON")
    .describe("destinationFile", "Specify a destination to write to")
    .argv;

const inputFilePath = argv.sourceFile;
const outputFilePath = argv.destinationFile;

const userGroups = {};

// Initialize levels 1-5 as empty arrays
for (let i = 1; i <= 5; i++) {
    userGroups[i.toString()] = [];
}

// Function to map CSV data to desired JSON structure
const mapToJsonFormat = (row) => {
    const [name, level, parentGroup] = row;
    const levelNumber = parseInt(level, 10);

    const groupObj = {
        Name: name,
        ...(parentGroup && { ParentGroupName: parentGroup })
    };

    userGroups[levelNumber.toString()].push(groupObj);
};

// Read and process the CSV file
fs.createReadStream(inputFilePath)
    .pipe(parse({ delimiter: ',', from_line: 2 }))
    .on('data', (row) => {
        mapToJsonFormat(row);
    })
    .on('end', () => {
        // Write the mapped data to a JSON file
        fs.writeFileSync(outputFilePath, JSON.stringify(userGroups, null, 2), 'utf8');
        console.log('CSV data has been successfully mapped and written to JSON file.');
    })
    .on('error', (error) => {
        console.error('Error reading the CSV file:', error);
    });
