const { execSync } = require('child_process');
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

/**
 * Full User Group and Hierarchy Workflow Script
 *
 * This script executes the complete user group and user hierarchy management workflow:
 * 1. Cache existing user hierarchy from AWS Connect
 * 2. Convert user hierarchy CSV to JSON format
 * 3. Deploy user hierarchy to AWS Connect
 * 4. Cache existing user groups from AWS Connect
 * 5. Convert user groups CSV to JSON format
 * 6. Deploy user groups to AWS Connect
 *
 * Usage:
 *   node full-user-group-workflow.js --region <region> --stage <stage> [--instanceId <instanceId>]
 *
 * Simple Example (using defaults):
 *   node full-user-group-workflow.js --region us-west-2 --stage dev --instanceId <instanceId>
 *
 * Advanced Example (custom file paths):
 *   node full-user-group-workflow.js --region <region> --stage <stage> --instanceId <instanceId> --userGroupSourceFile <userGroupCsvFile> --userGroupDestinationFile <userGroupJsonFile> --userHierarchySourceFile <userHierarchyCsvFile> --userHierarchyDestinationFile <userHierarchyJsonFile>
 *
 * Parameters:
 * - --region: AWS region (required)
 * - --stage: Deployment stage (required)
 * - --instanceId: Amazon Connect instance ID (optional)
 * - --userGroupSourceFile: Path to user groups input CSV file (default: data/input/UserGroup.csv)
 * - --userGroupDestinationFile: Path to user groups output JSON file (default: data/output/user-groups.json)
 * - --userHierarchySourceFile: Path to user hierarchy input CSV file (default: data/input/UserHierarchy.csv)
 * - --userHierarchyDestinationFile: Path to user hierarchy output JSON file (default: data/output/user-hierarchy-structure.json)
 * - --profile: AWS profile (optional)
 *
 * Author: Henry Pizzo
 * Date: Sept 5, 2025
 */

const argv = yargs(hideBin(process.argv))
  .usage("Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId]] [--userGroupSourceFile [sourceFile]] [--userGroupDestinationFile [destinationFile]] [--userHierarchySourceFile [sourceFile]] [--userHierarchyDestinationFile [destinationFile]]")
  .demandOption(["region", "stage"])
  .describe("region", "Specify AWS region")
  .describe("instanceId", "Specify Amazon Connect instance Id")
  .describe("stage", "Specify stage to target the deployment to")
  .describe("userGroupSourceFile", "Specify user groups CSV file to convert to JSON (default: data/input/UserGroup.csv)")
  .describe("userGroupDestinationFile", "Specify destination to write user groups JSON output (default: data/output/user-groups.json)")
  .describe("userHierarchySourceFile", "Specify user hierarchy CSV file to convert to JSON (default: data/input/UserHierarchy.csv)")
  .describe("userHierarchyDestinationFile", "Specify destination to write user hierarchy JSON output (default: data/output/user-hierarchy-structure.json)")
  .describe("profile", "Optionally specify AWS profile")
  .default("userGroupSourceFile", "data/input/UserGroup.csv")
  .default("userGroupDestinationFile", "data/output/user-groups.json")
  .default("userHierarchySourceFile", "data/input/UserHierarchy.csv")
  .default("userHierarchyDestinationFile", "data/output/user-hierarchy-structure.json")
  .argv;

const main = async () => {
  try {
    console.log("🚀 Starting Full User Group and Hierarchy Workflow...\n");

    // Step 1: Cache existing user hierarchy from AWS Connect
    console.log("📥 Step 1: Caching existing user hierarchy from AWS Connect...");
    const cacheUserHierarchyCommand = `node cache-user-hierarchy.js --region ${argv.region} --stage ${argv.stage}${argv.instanceId ? ` --instanceId ${argv.instanceId}`: ''}${argv.profile ? ` --profile ${argv.profile}` : ''}`;
    execSync(cacheUserHierarchyCommand, { stdio: 'inherit', cwd: __dirname });
    console.log("✅ User hierarchy cached successfully!\n");

    // Step 2: Convert user hierarchy CSV to JSON
    console.log("🔄 Step 2: Converting user hierarchy CSV to JSON format...");
    const convertUserHierarchyCommand = `node convertCsvToUserHierarchy.js --sourceFile ${argv.userHierarchySourceFile} --destinationFile ${argv.userHierarchyDestinationFile}`;
    execSync(convertUserHierarchyCommand, { stdio: 'inherit', cwd: __dirname });
    console.log("✅ User hierarchy CSV converted to JSON successfully!\n");

    // Step 3: Deploy user hierarchy to AWS Connect
    console.log("🚀 Step 3: Deploying user hierarchy to AWS Connect...");
    const deployUserHierarchyCommand = `node deploy-user-hierarchy.js --sourceFile ${argv.userHierarchyDestinationFile} --stage ${argv.stage} --region ${argv.region}${argv.instanceId ? ` --instanceId ${argv.instanceId}`: ''}${argv.profile ? ` --profile ${argv.profile}` : ''}`;
    execSync(deployUserHierarchyCommand, { stdio: 'inherit', cwd: __dirname });
    console.log("✅ User hierarchy deployed successfully!\n");

    // Step 4: Cache existing user groups from AWS Connect
    console.log("📥 Step 4: Caching existing user groups from AWS Connect...");
    const cacheUserGroupCommand = `node cache-user-group.js --region ${argv.region} --stage ${argv.stage}${argv.instanceId ? ` --instanceId ${argv.instanceId}`: ''}${argv.profile ? ` --profile ${argv.profile}` : ''}`;
    execSync(cacheUserGroupCommand, { stdio: 'inherit', cwd: __dirname });
    console.log("✅ User groups cached successfully!\n");

    // Step 5: Convert user groups CSV to JSON
    console.log("🔄 Step 5: Converting user groups CSV to JSON format...");
    const convertUserGroupCommand = `node convertCsvToUserGroups.js --sourceFile ${argv.userGroupSourceFile} --destinationFile ${argv.userGroupDestinationFile}`;
    execSync(convertUserGroupCommand, { stdio: 'inherit', cwd: __dirname });
    console.log("✅ User groups CSV converted to JSON successfully!\n");

    // Step 6: Deploy user groups to AWS Connect
    console.log("🚀 Step 6: Deploying user groups to AWS Connect...");
    const deployUserGroupCommand = `node deploy-user-group.js --sourceFile ${argv.userGroupDestinationFile} --stage ${argv.stage} --region ${argv.region}${argv.instanceId ? ` --instanceId ${argv.instanceId}`: ''}${argv.profile ? ` --profile ${argv.profile}` : ''}`;
    execSync(deployUserGroupCommand, { stdio: 'inherit', cwd: __dirname });
    console.log("✅ User groups deployed successfully!\n");

    console.log("🎉 Full User Group and Hierarchy Workflow completed successfully!");

  } catch (error) {
    console.error("❌ Error in workflow execution:", error.message);
    process.exit(1);
  }
};

main();
