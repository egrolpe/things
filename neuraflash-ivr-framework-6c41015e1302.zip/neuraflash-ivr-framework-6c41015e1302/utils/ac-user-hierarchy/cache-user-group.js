const {
  ConnectClient,
  SearchUserHierarchyGroupsCommand
} = require("@aws-sdk/client-connect");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const fs = require("fs");
const path = require("path");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId] --profile [profile]]"
  )
  .demandOption(["region", "stage"])
  .describe("region", "Specify AWS region")
  .describe("instanceId", "Specify Amazon Connect instance Id")
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv;
  
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);

const levelParentMap = {
    "1": null,
    "2": "LevelOne",
    "3": "LevelTwo",
    "4": "LevelThree",
    "5": "LevelFour"
  };

const userGroups = {
  "1": [],
  "2": [],
  "3": [],
  "4": [],
  "5": [],
}

async function searchUserGroup(connectClient) {
  let nextToken = null;
  do {
    const command = new SearchUserHierarchyGroupsCommand({
      InstanceId: instanceId,
      NextToken: nextToken
    });
    const response = await connectClient.send(command);
    nextToken = response.NextToken;
    for (const userGroup of response.UserHierarchyGroups) {
      // skip level 0 groups (default group, irrelevant)
      if (userGroup.LevelId == '0') {
        continue;
      }

      newGroup = {
        Name: userGroup.Name,
      }

      // level 1 has no parent
      if (userGroup.LevelId == '1') {
        userGroups[userGroup.LevelId].push(newGroup)
        continue;
      }

      userGroups[userGroup.LevelId].push({
        ...newGroup,
        ParentGroupName: userGroup.HierarchyPath[levelParentMap[userGroup.LevelId]].Name
      })
    }
  } while (nextToken);
}

const main = async () => {
  try {
    const dataDir = path.join(__dirname, "data");
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir); // Create the directory if it doesn't exist
    }

    const connectClient = new ConnectClient({ region: argv.region });
    await searchUserGroup(connectClient)

    // Write the groups into different files based on LevelId
    fs.writeFileSync(
      path.join(dataDir, "user-groups.json"),
      JSON.stringify(userGroups, null, 2)
    );

    console.log("✅ User Groups Download Complete");
  } catch (err) {
    console.error(`Failed to process: ${err.message}`);
  }
};

main();
