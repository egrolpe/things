# Amazon Connect User Hierarchy and User Groups Manager

This module helps manage user hierarchies and user groups in Amazon Connect by creating or updating them based on configuration files. It utilizes the AWS SDK for JavaScript and requires an AWS account with appropriate permissions.

## Features

- Create new user hierarchies in Amazon Connect.
- Update existing user hierarchies with new configurations.
- Create new user groups in Amazon Connect.
- Update existing user groups with new configurations.
- Manage hierarchy levels and parent group relationships.
- Handles command-line argument parsing for flexible execution.

## Installation

To use this module, ensure you have Node.js installed. Then, install the required packages:

```bash
npm install
```

## Usage

### Full Workflow (Recommended)

To run the complete workflow of caching existing hierarchies and groups, converting CSVs to JSON, and deploying to Amazon Connect, use the full workflow script:

```bash
node full-user-group-workflow.js --region us-west-2 --stage dev
```

This script will:
1. Cache existing user hierarchy from Amazon Connect
2. Convert your UserHierarchy.csv file to JSON format
3. Deploy the user hierarchy to Amazon Connect
4. Cache existing user groups from Amazon Connect
5. Convert your UserGroup.csv file to JSON format
6. Deploy the user groups to Amazon Connect

### Individual Scripts

#### Step 1: Set Up AWS Credentials

Ensure your AWS credentials are configured. You can use the AWS CLI to set up profiles or place your credentials in the `~/.aws/credentials` file.

#### Step 2: Cache Existing User Hierarchy

First, cache the existing user hierarchy:

```bash
node cache-user-hierarchy.js --region us-west-2 --stage dev
```

#### Step 3: Prepare User Hierarchy Configuration

Create a JSON file named `user-hierarchy-structure.json` in a `data/output` directory. The structure should look like this:
This can be achieved by using the `convertCsvToUserHierarchy.js` script with the following command

```bash
node convertCsvToUserHierarchy.js --sourceFile ./data/input/UserHierarchy.csv --destinationFile ./data/output/user-hierarchy-structure.json
```

#### Step 4: Deploy User Hierarchy

Use the command line to execute the deploy script. You must provide at least the AWS region and source file, and optionally, the instance ID, stage, and profile.

```bash
node deploy-user-hierarchy.js --region us-west-2 --sourceFile ./data/output/user-hierarchy-structure.json --stage dev
```

#### Step 5: Cache Existing User Groups

Cache the existing user groups:

```bash
node cache-user-group.js --region us-west-2 --stage dev
```

#### Step 6: Prepare User Groups Configuration

Create a JSON file named `user-groups.json` in a `data/output` directory. The structure should look like this:
This can be achieved by using the `convertCsvToUserGroups.js` script with the following command

```bash
node convertCsvToUserGroups.js --sourceFile ./data/input/UserGroup.csv --destinationFile ./data/output/user-groups.json
```

#### Step 7: Deploy User Groups

Use the command line to execute the deploy script. You must provide at least the AWS region and source file, and optionally, the instance ID, stage, and profile.

```bash
node deploy-user-group.js --region us-west-2 --sourceFile ./data/output/user-groups.json --stage dev
```

### CSV Structures

#### UserHierarchy.csv

The input CSV file should have the following columns:

- `Level`: The hierarchy level (number)
- `Name`: The name of the hierarchy group

Example CSV:

| Level | Name  |
|-------|-------|
| 1     | Admin |
| 2     | Agent |
| 3     | Worker|

Resulting JSON structure:

```json
{
  "LevelOne": {
    "Name": "Admin",
    "Level": 1
  },
  "LevelTwo": {
    "Name": "Agent",
    "Level": 2
  },
  "LevelThree": {
    "Name": "Worker",
    "Level": 3
  }
}
```

#### UserGroup.csv

The input CSV file should have the following columns:

- `Name`: The name of the user group
- `Level`: The hierarchy level (number)
- `ParentGroup`: The parent group name (optional)

Example CSV:

| Name    | Level | ParentGroup |
|---------|-------|-------------|
| Admin1  | 1     |             |
| Agent1  | 2     | Admin1      |
| Admin2  | 1     |             |
| Agent4  | 2     | Admin2      |
| Worker1 | 3     | Agent4      |

Resulting JSON structure:

```json
{
  "1": [
    {
      "Name": "Admin1"
    },
    {
      "Name": "Admin2"
    }
  ],
  "2": [
    {
      "Name": "Agent1",
      "ParentGroupName": "Admin1"
    },
    {
      "Name": "Agent2",
      "ParentGroupName": "Admin2"
    }
  ],
  "3": [
    {
      "Name": "Worker1",
      "ParentGroupName": "Agent2"
    }
  ]
}
```

### Command-Line Arguments

- `--region`: Required. Specify the AWS region (e.g., `us-west-2`).
- `--stage`: Required. Specify the deployment stage (used to fetch instance ID from a config file).
- `--instanceId`: Optional. Specify the Amazon Connect instance ID.
- `--profile`: Optional. Specify the AWS profile to use.
- `--sourceFile`: Required for convert and deploy scripts. Specify the input file path.
- `--destinationFile`: Required for convert scripts. Specify the output file path.

### Example Output

When you run the scripts, they will log the operations performed, such as creating or updating hierarchies/groups:

```
✅ created user hierarchy LevelOne
✅ updated user group Agent1
ℹ️  no updates for user group Worker1
```

## Error Handling

If there are issues with the provided configuration, such as missing hierarchy levels, the script will log an error message:

```
❌ Failed to update user hierarchy because level 6 does not exist.
```

## Dependencies

- `@aws-sdk/client-connect`: AWS SDK for interacting with Amazon Connect.
- `@aws-sdk/credential-providers`: AWS SDK for credential management.
- `csv-parse`: A package to parse CSV files.
- `lodash`: Utility library for JavaScript.
- `yargs`: Command-line argument parser.

## License

This project is licensed under the MIT License.
