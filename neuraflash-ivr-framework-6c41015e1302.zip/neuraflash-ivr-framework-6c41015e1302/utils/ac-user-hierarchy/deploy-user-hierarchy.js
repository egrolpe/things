const {
  ConnectClient,
  UpdateUserHierarchyStructureCommand
} = require("@aws-sdk/client-connect");
const { fromIni } = require("@aws-sdk/credential-provider-ini");
const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] --instanceId [instanceId] --profile [profile] --sourceFile [sourceFile]"
  )
  .demandOption(["region", "stage", "sourceFile"])
  .describe("region", "Specify AWS region")
  .describe("instanceId", "Specify Amazon Connect instance Id")
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile")
  .describe("sourceFile", "Specify the path to the user hierarchy structure JSON file").argv;

const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);
let config = { region: argv.region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) };
}
const client = new ConnectClient(config);

const deployAgentHierarchy = async () => {
  try {
    const data = fs.readFileSync(argv.sourceFile, "utf8");
    const userHierarchyStructure = JSON.parse(data);

    const updateParams = {
      InstanceId: instanceId,
      HierarchyStructure: {}
    };

    Object.keys(userHierarchyStructure).forEach((level) => {
      if (userHierarchyStructure[level] && userHierarchyStructure[level].Name) {
        updateParams.HierarchyStructure[level] = {
          Name: userHierarchyStructure[level].Name
        };
      }
    });

    if (Object.keys(updateParams.HierarchyStructure).length > 0) {
      const updateCommand = new UpdateUserHierarchyStructureCommand(
        updateParams
      );
      await client.send(updateCommand);
      console.log(`✅ Hierarchy updated successfully.`);
    } else {
      console.log("No valid hierarchy levels to update.");
    }
  } catch (err) {
    console.error("❌ Error while processing agent statuses:", err);
  }
};

deployAgentHierarchy();
