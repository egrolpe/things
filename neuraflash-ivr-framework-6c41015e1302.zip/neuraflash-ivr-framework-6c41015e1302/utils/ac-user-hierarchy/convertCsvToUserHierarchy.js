const fs = require('fs');
const { parse } = require("csv-parse");
const yargs = require("yargs/yargs");

/**
 * CSV to JSON Converter for User Hierarchy
 *
 * This script reads a CSV file containing User Hierarchy configurations and converts
 * it into a structured JSON format. It allows the user to specify the input
 * CSV file and the output JSON file through command-line arguments.
 *
 * The CSV file should have the following structure:
 * - Level: The hierarchy level (number)
 * - Name: The name of the hierarchy group
 *
 * The resulting JSON structure will include the following fields:
 * - Name: The name of the hierarchy group
 * - Level: The hierarchy level
 *
 * Usage:
 *   node convertCsvToUserHierarchy.js --sourceFile path/to/input.csv --destinationFile path/to/output.json
 *
 * Command-line Arguments:
 * - --sourceFile: The path to the input CSV file (required).
 * - --destinationFile: The path to the output JSON file (required).
 *
 * Dependencies:
 * - fs: Node.js file system module for reading and writing files.
 * - csv-parse: A package to parse CSV files.
 * - yargs: A package to handle command-line arguments.
 *
 * Example:
 *   node convertCsvToUserHierarchy.js --sourceFile data/input/UserHierarchy.csv --destinationFile data/output/user-hierarchy-structure.json
 *
 * Author: Dan Dominguez, Henry Pizzo
 * Date: Sept 3, 2025
 */

// Get input and output file paths from command-line arguments
const argv = yargs(process.argv.slice(2))
    .usage("Usage: $0 --sourceFile [name] --destinationFile [name]")
    .demandOption(["sourceFile", "destinationFile"])
    .describe("sourceFile", "Specify CSV file to convert to JSON") 
    .describe("destinationFile", "Specify a destination to write to")
    .argv; 

const inputFilePath = argv.sourceFile;
const outputFilePath = argv.destinationFile;

const userHierarchys = {};

// Function to map CSV data to desired JSON structure
const mapToJsonFormat = (row) => {
    const [level, name] = row;
    const levelNumber = parseInt(level, 10);

    // Convert level number to LevelOne, LevelTwo, etc.
    const levelNames = ['', 'One', 'Two', 'Three', 'Four', 'Five'];
    const levelName = 'Level' + levelNames[levelNumber];

    userHierarchys[levelName] = {
        Name: name,
        Level: levelNumber
    };
};

// Read and process the CSV file
fs.createReadStream(inputFilePath)
    .pipe(parse({ delimiter: ',', from_line: 2 }))
    .on('data', (row) => {
        mapToJsonFormat(row);
    })
    .on('end', () => {
        // Write the mapped data to a JSON file
        fs.writeFileSync(outputFilePath, JSON.stringify(userHierarchys, null, 2), 'utf8');
        console.log('CSV data has been successfully mapped and written to JSON file.');
    })
    .on('error', (error) => {
        console.error('Error reading the CSV file:', error);
    });
