const {
  ConnectClient,
  CreateUserHierarchyGroupCommand,
  UpdateUserHierarchyGroupNameCommand,
  ListUserHierarchyGroupsCommand
} = require("@aws-sdk/client-connect");
const { fromIni } = require("@aws-sdk/credential-provider-ini");
const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] --instanceId [instanceId] --profile [profile] --sourceFile [sourceFile]"
  )
  .demandOption(["region", "stage", "sourceFile"])
  .describe("region", "Specify AWS region")
  .describe("instanceId", "Specify Amazon Connect instance Id")
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile")
  .describe("sourceFile", "Specify the source file to read user groups from").argv;

const sourceFile = argv.sourceFile;
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);
let config = { region: argv.region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) };
}

const client = new ConnectClient(config);

const getParentGroupId = async (userGroup) => {
  let nextToken = null;
  do {
  const command = new ListUserHierarchyGroupsCommand({
      InstanceId: instanceId,
      NextToken: nextToken,
      MaxResults: 100,
    });

  const response = await client.send(command);

  const match = response.UserHierarchyGroupSummaryList?.find(
      (group) => group.Name === userGroup.ParentGroupName
    );

    if (match) {
      console.log(`✅ Found parent group: ${match.Name} (ID: ${match.Id})`);
      return match.Id;
    }

    nextToken = response.NextToken;
  } while (nextToken)

  console.log(`⚠️  Parent group not found: ${userGroup.ParentGroupName}`);
  return null;
}

const getExistingUserHierarchyGroups = async () => {
  let nextToken;
  let userHierarchyGroups = [];
  do {
    const command = new ListUserHierarchyGroupsCommand({
        InstanceId: instanceId,
        NextToken: nextToken,
        MaxResults: 100,
      });

    const response = await client.send(command);
    userHierarchyGroups.push(...response.UserHierarchyGroupSummaryList)

  } while (nextToken)
  return userHierarchyGroups;
};

const deployUserGroups = async () => {

  // get existing groups
  const existingUserHierarchyGroups = await getExistingUserHierarchyGroups();

  // TODO: get existing user groups, check if create or update
  try {
    const data = fs.readFileSync(sourceFile, "utf8");
    const userGroupLevels = JSON.parse(data);

    // Go throught each user group level, ensuring that parents are created before children
    for (let i = 1; i <= 5; i++) {
      const userGroups = userGroupLevels[i]

      if (userGroups && userGroups.length > 0) {
        console.log(`🔄 Processing level ${i} with ${userGroups.length} user groups...`);

        // for each user in this level, get the parent group ID and create
        for (const userGroup of userGroups) {
          const existingGroup = existingUserHierarchyGroups.find(
            (group) => group.Name === userGroup.Name
          );
          if (existingGroup) {
            // update
            try {
              const input = {
                Name: userGroup.Name,
                HierarchyGroupId: existingGroup.Id,
                InstanceId: instanceId
              };
              const command = new UpdateUserHierarchyGroupNameCommand(input);
              const response = await client.send(command);
              console.log(`✅ Updated existing user group: ${userGroup.Name}`);
            } catch (error) {
              console.error(`❌ Failed to update user group: ${userGroup.Name} - ${error.message}`);
            }
          } else {
            // create
            try {
              const parentGroupId = await getParentGroupId(userGroup)
              const input = {
                ...userGroup,
                ParentGroupId: parentGroupId,
                InstanceId: instanceId
              }
              const createCommand = new CreateUserHierarchyGroupCommand(input);
              const response = await client.send(createCommand);
              console.log(`✅ Created new user group: ${userGroup.Name}`);
            } catch (error) {
              console.error(`❌ Failed to create user group: ${userGroup.Name} - ${error.message}`);
            }
          }
        }
      }
    }

    console.log("🎉 User group deployment completed successfully!");
  } catch (err) {
      console.error("❌ Error while processing user groups:", err);
  }
}

deployUserGroups();
