const {
  ConnectClient,
  DescribeUserHierarchyStructureCommand
} = require("@aws-sdk/client-connect");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const fs = require("fs");
const path = require("path");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId] --profile [profile]]"
  )
  .demandOption(["region", "stage"])
  .describe("region", "Specify AWS region")
  .describe("instanceId", "Specify Amazon Connect instance Id")
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv;

const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);

async function searchUserHierarchy(connectClient) {
  const command = new DescribeUserHierarchyStructureCommand({
    InstanceId: instanceId
  });

  const response = await connectClient.send(command);
  const hierarchyStructure = response.HierarchyStructure;

  return hierarchyStructure;
}

const main = async () => {
  const connectClient = new ConnectClient({ region: argv.region });

  try {
    const userHierarchy = await searchUserHierarchy(connectClient);

    const dataDir = path.join(__dirname, "data");
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir); // Create the directory if it doesn't exist
    }

    fs.writeFileSync(
      path.join(dataDir, "user-hierarchy-structure.json"),
      JSON.stringify(userHierarchy, null, 2)
    );

    console.log("✅ User Hierarchy Download Complete");
  } catch (err) {
    console.error(`Failed to process: ${err.message}`);
  }
};

main();
