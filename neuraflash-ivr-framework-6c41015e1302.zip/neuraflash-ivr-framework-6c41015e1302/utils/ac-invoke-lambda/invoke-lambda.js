const { LambdaClient, InvokeCommand } = require("@aws-sdk/client-lambda");
const { fromIni } = require("@aws-sdk/credential-providers");

// parse command line arguments using yargs
const argv = require("yargs/yargs")(process.argv.slice(2))
  .usage(
    "Usage: $0 --region [region] --functionName [functionName] [--profile [profile]]"
  )
  .demandOption(["region", "functionName"])
  .describe("region", "Specify AWS region")
  .describe("functionName", "Specify function name to run")
  .describe("profile", "Optionally specify AWS profile").argv;

const region = argv.region;
const functionName = argv.functionName; //connect sync is like Neuraflash-dev-us-west-2-connect-sync
let config = { region: region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}

(async () => {
  const client = new LambdaClient(config);
  const command = new InvokeCommand({
    FunctionName: functionName,
  });
  const response = await client.send(command);

  if (response?.StatusCode === 200) {
    console.log(`✅ Lambda ${functionName} run in region: ${region}`);
  } else {
    console.log(response);
  }
})();
