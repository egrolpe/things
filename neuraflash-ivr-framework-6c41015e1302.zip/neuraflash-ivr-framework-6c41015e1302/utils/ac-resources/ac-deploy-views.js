const {
  ConnectClient,
  ListViewsCommand,
  CreateViewCommand,
  UpdateViewContentCommand
} = require("@aws-sdk/client-connect");

const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const path = require("path");

const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] --instanceId [instanceId] --profile [profile]]"
  )
  .demandOption(["region", "stage"]) // region argument required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("instanceId", "Specify Amazon Connect instance Id") // description for the instanceId argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

let config = { region: argv.region };
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);

if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}

// Set up the AWS SDK client
const client = new ConnectClient(config);

// Directory containing the saved view files
const viewsDir = path.join(__dirname, "views");

// Function to retrieve all existing views in the target instance
async function getAllViews() {
  let views = [];
  let nextToken;
  do {
    const listCommand = new ListViewsCommand({
      InstanceId: instanceId,
      NextToken: nextToken
    });
    const listResponse = await client.send(listCommand);
    views = views.concat(listResponse.ViewsSummaryList);
    nextToken = listResponse.NextToken;
  } while (nextToken);
  return views;
}

async function importViews() {
  try {
    // Get all existing views in the target instance
    const existingViews = await getAllViews();
    const existingViewsMap = new Map(
      existingViews.map((view) => [view.Name, view.Id])
    );

    // Read all files in the "views" directory
    const files = fs
      .readdirSync(viewsDir)
      .filter((file) => file.endsWith(".json"));

    for (const file of files) {
      try {
        // Read and parse each view file
        const viewData = JSON.parse(
          fs.readFileSync(path.join(viewsDir, file), "utf-8")
        );

        // Check if a view with the same name already exists in the map
        const existingViewId = existingViewsMap.get(viewData.Name);

        if (existingViewId) {
          // Update the existing view
          const updateCommand = new UpdateViewContentCommand({
            InstanceId: instanceId,
            ViewId: existingViewId,
            Status: viewData.Status,
            Description: viewData.Description,
            // Version: viewData.Version,
            Content: viewData.Content
          });
          await client.send(updateCommand);
          console.log(`✅ Updated existing view: ${viewData.Name}`);
        } else {
          // Create a new view
          const createCommand = new CreateViewCommand({
            InstanceId: instanceId,
            Name: viewData.Name,
            Description: viewData.Description,
            Version: viewData.Version,
            Content: viewData.Content,
            Status: viewData.Status
          });
          await client.send(createCommand);
          console.log(`✅ Created new view: ${viewData.Name}`);
        }
      } catch (viewError) {
        console.error(`❌ Error importing view from file ${file}:`, viewError);
      }
    }
  } catch (error) {
    console.error(
      "❌ Error retrieving existing views or reading views directory:",
      error
    );
  }
}

importViews();
