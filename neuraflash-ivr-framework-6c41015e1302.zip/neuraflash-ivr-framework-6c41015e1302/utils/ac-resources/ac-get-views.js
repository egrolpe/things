const {
  ConnectClient,
  ListViewsCommand,
  DescribeViewCommand
} = require("@aws-sdk/client-connect");

const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const path = require("path");

const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] --instanceId [instanceId] --profile [profile]]"
  )
  .demandOption(["region", "stage"]) // region argument required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("instanceId", "Specify Amazon Connect instance Id") // description for the instanceId argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

let config = { region: argv.region };
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);

if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}

// Set up the AWS SDK client
const client = new ConnectClient(config);

// Directory to save the views
const viewsDir = path.join(__dirname, "views");

// Ensure the "views" directory exists, and clear it if it does
if (!fs.existsSync(viewsDir)) {
  fs.mkdirSync(viewsDir);
} else {
  // Remove all files in the "views" folder
  fs.readdirSync(viewsDir).forEach((file) => {
    fs.unlinkSync(path.join(viewsDir, file));
  });
}

async function getAllViewsAndSave() {
  try {
    let views = [];
    let nextToken;

    // Fetch all view summaries using pagination
    do {
      const listCommand = new ListViewsCommand({
        InstanceId: instanceId,
        NextToken: nextToken
      });
      const listResponse = await client.send(listCommand);

      views = views.concat(listResponse.ViewsSummaryList);
      nextToken = listResponse.NextToken;
    } while (nextToken);

    // Get full details of each view and save each to a separate file
    for (const view of views) {
      try {
        if (view.Type === "AWS_MANAGED") {
          console.log(`ℹ️ Skipped AWS_MANAGED View - ${view.Name}`);
        } else {
          const describeCommand = new DescribeViewCommand({
            InstanceId: instanceId,
            ViewId: view.Arn
          });
          const describeResponse = await client.send(describeCommand);

          // Save each view to a separate JSON file in the "views" folder
          const filePath = path.join(viewsDir, `${view.Name}.json`);
          fs.writeFileSync(
            filePath,
            JSON.stringify(describeResponse.View, null, 2)
          );

          console.log(`✅ Saved View - ${view.Name}`);
        }
      } catch (viewError) {
        console.error(
          `❌ Error retrieving or saving view ${view.Name}:`,
          viewError
        );
      }
    }
  } catch (error) {
    console.error("❌  Error retrieving views:", error);
  }
}

getAllViewsAndSave();
