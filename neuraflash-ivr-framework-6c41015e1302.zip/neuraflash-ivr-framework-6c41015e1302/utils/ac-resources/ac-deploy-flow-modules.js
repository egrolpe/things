const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { fromIni } = require("@aws-sdk/credential-providers");
const { getConnectInstanceId, getConfigFromFile } = (require("ts-node/register"), require("../../config/config.ts"));

const {
  ConnectClient,
  CreateContactFlowModuleCommand,
  DescribeContactFlowModuleCommand,
  ListContactFlowsCommand,
  ListContactFlowModulesCommand,
  UpdateContactFlowModuleContentCommand,
  UpdateContactFlowModuleMetadataCommand,
  ListPromptsCommand,
  ListQueuesCommand
} = require("@aws-sdk/client-connect");

const {
  LexModelsV2Client,
  ListBotsCommand,
  ListBotAliasesCommand
} = require("@aws-sdk/client-lex-models-v2");

const { STSClient, GetCallerIdentityCommand } = require("@aws-sdk/client-sts");

// Parse command line arguments using yargs
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] [--instanceID [instanceID] --stage [stage] --s3PromptBucketName [s3PromptBucketName] --profile [profile]]"
  )
  .demandOption(["region", "stage"]) // region argument required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("instanceID", "Specify Amazon Connect instance ID") // description for the instanceID argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("s3PromptBucketName", "Optionally specify prompts s3 Bucket Name") // description for the s3PromptBucketName argument
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

const clientPrefix = getConfigFromFile(argv.stage).clientPrefix;
const region = argv.region;
const stage = argv.stage;

const instanceId = argv.instanceID || getConnectInstanceId(argv.stage, argv.region);

let connectClient;
let lexClient;
let stsClient;

async function initializeConfig() {
  // Set AWS SDK configuration
  let config = { region: argv.region };
  if (argv.profile) {
    config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  }
  connectClient = new ConnectClient(config);
  lexClient = new LexModelsV2Client(config);
  stsClient = new STSClient(config);
}
const errorMessages = [];

let AWS_ACCOUNT_ID;
// Function to get the AWS account number
async function getAccountId() {
  if (AWS_ACCOUNT_ID) {
    return AWS_ACCOUNT_ID;
  }
  try {
    const command = new GetCallerIdentityCommand({});
    const response = await stsClient.send(command);

    // AWS account number
    const accountId = response.Account;
    AWS_ACCOUNT_ID = accountId;
    console.log("AWS_ACCOUNT_ID",AWS_ACCOUNT_ID)
    return accountId;
  } catch (error) {
    console.error("Error fetching AWS Account ID:", error);
  }
}

function getS3PromptBucketName() {
  let s3PromptBucketName;
  if (argv.s3PromptBucketName) {
    s3PromptBucketName = argv.s3PromptBucketName;
  } else {
    // let accountNumber = AWS_ACCOUNT_ID;
    // let accountNumberLastFourDigits = accountNumber.substring(
    //   accountNumber.length - 4
    // );
    s3PromptBucketName = `${clientPrefix}-${argv.stage}-${region}-connect-prompts`;
  }
  return s3PromptBucketName;
}

let destinationContactFlows = {};
async function getDestinationContactFlows() {
  if (Object.keys(destinationContactFlows).length > 0) {
    return destinationContactFlows;
  } else {
    let nextToken = null;
    do {
      const command = new ListContactFlowsCommand({
        InstanceId: instanceId,
        NextToken: nextToken
      });
      const response = await connectClient.send(command);
      nextToken = response.NextToken;
      response.ContactFlowSummaryList.forEach((element) => {
        destinationContactFlows[element.Name] = element;
      });
    } while (nextToken);

    return destinationContactFlows;
  }
}

const destinationPrompts = {};
async function getDestinationPrompts() {
  if (Object.keys(destinationPrompts).length > 0) {
    return destinationPrompts;
  } else {
    let nextToken = null;
    do {
      const command = new ListPromptsCommand({
        InstanceId: instanceId,
        NextToken: nextToken
      });
      const response = await connectClient.send(command);
      nextToken = response.NextToken;
      response.PromptSummaryList.forEach((element) => {
        destinationPrompts[element.Name] = element;
      });
    } while (nextToken);
  }

  return destinationPrompts;
}

const destinationContactFlowModules = {};
async function getDestinationContactFlowModules() {
  if (Object.keys(destinationContactFlowModules).length > 0) {
    return destinationContactFlowModules;
  } else {
    let nextToken = null;
    do {
      const command = new ListContactFlowModulesCommand({
        InstanceId: instanceId,
        NextToken: nextToken
      });
      const response = await connectClient.send(command);
      nextToken = response.NextToken;
      response.ContactFlowModulesSummaryList.forEach((element) => {
        destinationContactFlowModules[element.Name] = element;
      });
    } while (nextToken);

    return destinationContactFlowModules;
  }
}



let destinationQueues = {};
// Function to list all queues
async function getDestinationQueues() {
  if (Object.keys(destinationQueues).length > 0) {
    return destinationQueues;
  }

  let nextToken = null;
  try {
    do {
      // Command to list queues, using NextToken for pagination
      const command = new ListQueuesCommand({
        InstanceId: instanceId,
        NextToken: nextToken // Pass NextToken if there is more data
      });
      const response = await connectClient.send(command);

      // Populate the destinationQueues Map with queue names and their corresponding ARNs
      if (response.QueueSummaryList) {
        response.QueueSummaryList.forEach((queue) => {
          destinationQueues[queue.Name] = queue.Arn;
        });
      }

      // Update NextToken if there are more results to fetch
      nextToken = response.NextToken;
    } while (nextToken); // Continue until there's no more NextToken

    return destinationQueues;
  } catch (error) {
    console.error("Error fetching queues: ", error);
    return {};
  }
}

const destinationLexBots = {};
// Function to list all Lex bots and their aliases
async function getDestinationLexBots() {
  if (Object.keys(destinationLexBots).length > 0) {
    return destinationLexBots;
  }
  let nextToken = null;
  try {
    // Fetch all bots
    do {
      const botCommand = new ListBotsCommand({ NextToken: nextToken });
      const botResponse = await lexClient.send(botCommand);
      const accountId = AWS_ACCOUNT_ID;

      // For each bot, fetch its aliases
      for (const bot of botResponse.botSummaries) {
        const botId = bot.botId;
        const botName = bot.botName;

        // Fetch aliases for each bot
        const aliasCommand = new ListBotAliasesCommand({ botId });
        const aliasResponse = await lexClient.send(aliasCommand);

        aliasResponse.botAliasSummaries.forEach((alias) => {
          const aliasName = alias.botAliasName;
          const aliasArn = `arn:aws:lex:${region}:${accountId}:bot-alias/${bot.botId}/${alias.botAliasId}`;
          // Map the combination of bot name and alias name to the ARN
          destinationLexBots[`${botName}:${aliasName}`] = aliasArn;
        });
      }

      // Update NextToken if there are more results to fetch
      nextToken = botResponse.nextToken;
    } while (nextToken); // Continue until there's no more NextToken

    return destinationLexBots;
  } catch (error) {
    console.error("Error fetching Lex bots and aliases: ", error);
    return {};
  }
}

async function getDestinationContactFlowModule(flowModuleName) {
  const destinationContactFlowModulesRef =
    await getDestinationContactFlowModules();
  if (!destinationContactFlowModulesRef?.[flowModuleName]?.Content) {
    //api call
    const command = new DescribeContactFlowModuleCommand({
      InstanceId: instanceId,
      ContactFlowModuleId: destinationContactFlowModulesRef[flowModuleName].Id
    });
    const response = await connectClient.send(command);
    destinationContactFlowModulesRef[flowModuleName] = {
      ...destinationContactFlowModulesRef[flowModuleName],
      ...response.ContactFlowModule
    };
  }

  return destinationContactFlowModulesRef[flowModuleName];
}

// Fetch contact flow module definition by file path
async function fetchContactFlowModuleDefinition(filePath) {
  try {
    const fileContent = fs.readFileSync(filePath, "utf8");
    return JSON.parse(fileContent);
  } catch (error) {
    console.error(
      `❌ Error fetching contact flow module definition for file "${filePath}":`,
      error
    );
    throw error;
  }
}

function replaceResourceNamesWithARN(flowModuleData) {
  let lambdaRegex = /"<lambda:::(.+?(?=>"))>"/g;
  flowModuleData.Content = flowModuleData.Content.replace(
    lambdaRegex,
    function (wholeMatch, lambdaIndexing) {
      let lambdaName = lambdaIndexing.replace(
        "{clientPrefix}-{stage}-{region}",
        `${clientPrefix}-${stage}-${region}`
      );
      lambdaName = lambdaName.replace(
        "{instanceId}",
        `${instanceId.slice(-12)}`
      );
      let lambdaArn = `arn:aws:lambda:${region}:${AWS_ACCOUNT_ID}:function:${lambdaName}`
      return `"${lambdaArn}"`;
    }
  );

  const lambdaDisplayNameRegex =
    /"LambdaFunctionARN":\{"displayName":"([^"]+)"\}/g;
  flowModuleData.Content = flowModuleData.Content.replace(
    lambdaDisplayNameRegex,
    function (wholeMatch, lambdaName) {
      lambdaName = lambdaName.replace(
        "{clientPrefix}-{stage}-{region}",
        `${clientPrefix}-${stage}-${region}`
      );
      lambdaName = lambdaName.replace(
        "{instanceId}",
        `${instanceId.slice(-12)}`
      );

      return `"LambdaFunctionARN":{"displayName":"${lambdaName}"}`;
    }
  );

  let promptRegex = /"PromptId":"<prompt:::(.+?(?=>"))>"/g;
  flowModuleData.Content = flowModuleData.Content.replace(
    promptRegex,
    function (wholeMatch, promptName) {
      let promptArn = destinationPrompts[promptName]?.Arn;
      if (!promptArn) {
        console.log(`🟡 Error: Prompt ${promptName} not found in Connect`);
      }
      return `"PromptId":"${promptArn}"`;
    }
  );

  let s3PromptBucketName = getS3PromptBucketName();
  const s3PromptRegex =
    /https:\/\/([^.]+)\.s3\.([^\/]+)\.amazonaws\.com\/([^"]+\.wav)/g;
  flowModuleData.Content = flowModuleData.Content.replace(
    s3PromptRegex,
    (match, bucketName, s3Region, promptName) => {
      return `https://${s3PromptBucketName}.s3.${region}.amazonaws.com/${promptName}`;
    }
  );

  // Regular expression to match the queue placeholder
  const queueRegex = /<queue:::(.*?)>/g;
  // Replace each placeholder with the corresponding ARN
  flowModuleData.Content = flowModuleData.Content.replace(
    queueRegex,
    (match, queueName) => {
      if (destinationQueues[queueName]) {
        return destinationQueues[queueName]; // Replace with ARN if queue name is found
      } else {
        console.warn(`Queue ${queueName} not found`);
        return match; // Keep the original placeholder if no match is found
      }
    }
  );

  // Regular expression to match the lex bot and alias placeholder
  const lexRegex = /<lex:::(.*?):(.*?)>/g;
  // Replace each placeholder with the corresponding ARN
  flowModuleData.Content = flowModuleData.Content.replace(
    lexRegex,
    (match, botName, aliasName) => {
      botName = botName.replace(
        "{clientPrefix}-{stage}-{region}",
        `${clientPrefix}-${stage}-${region}`
      );
      const key = `${botName}:${aliasName}`;
      if (destinationLexBots[key]) {
        return destinationLexBots[key]; // Replace with ARN if bot and alias combination is found
      } else {
        console.warn(`Lex bot/alias ${botName}:${aliasName} not found`);
        return match; // Keep the original placeholder if no match is found
      }
    }
  );

  const lexDisplayNameRegex = /"lexV2BotName":"([^"]+)"/g;
  flowModuleData.Content = flowModuleData.Content.replace(
    lexDisplayNameRegex,
    function (wholeMatch, lexBotName) {
      // Replace the specific prefix in the lexBotName
      lexBotName = lexBotName.replace(
        "{clientPrefix}-{stage}-{region}",
        `${clientPrefix}-${stage}-${region}`
      );
      return `"lexV2BotName":"${lexBotName}"`;
    }
  );

  // Regular expression to match the contact flow placeholder
  const flowPlaceholderRegex = /<flow:::(.*?)>/g;
  // Replace each placeholder with the corresponding flow ARN
  flowModuleData.Content = flowModuleData.Content.replace(
    flowPlaceholderRegex,
    (match, flowName) => {
      if (destinationContactFlows[flowName]) {
        return destinationContactFlows[flowName]["Arn"]; // Replace with ARN if flow name is found
      } else {
        console.warn(`Contact flow ${flowName} not found`);
        return match; // Keep the original placeholder if no match is found
      }
    }
  );
}

// Deploy contact flow module definition
async function deployContactFlowModuleDefinition(flowModuleData) {
  try {
    replaceResourceNamesWithARN(flowModuleData);

    if (!(flowModuleData.Name in destinationContactFlowModules)) {
      //create
      const command = new CreateContactFlowModuleCommand({
        Content: flowModuleData.Content,
        Description: flowModuleData.Description,
        InstanceId: instanceId,
        Name: flowModuleData.Name
      });
      const response = await connectClient.send(command);
      console.log(
        `✅ Contact flow module "${flowModuleData.Name}" definition created`
      );
    } else if (
      flowModuleData.Content !==
      (await getDestinationContactFlowModule(flowModuleData.Name)).Content
    ) {
      //update content
      const command = new UpdateContactFlowModuleContentCommand({
        Content: flowModuleData.Content,
        InstanceId: instanceId,
        ContactFlowModuleId:
        destinationContactFlowModules[flowModuleData.Name]?.Id
      });
      const response = await connectClient.send(command);
      console.log(
        `✅ Contact flow module "${flowModuleData.Name}" content updated`
      );
    } else if (
      flowModuleData.Description !=
      (await getDestinationContactFlowModule(flowModuleData.Name)).Description
    ) {
      //update description
      const command = new UpdateContactFlowModuleMetadataCommand({
        Description: flowModuleData.Description,
        InstanceId: instanceId,
        ContactFlowModuleId:
        destinationContactFlowModules[flowModuleData.Name]?.Id
      });
      const response = await connectClient.send(command);
      console.log(
        `✅ Contact flow module "${flowModuleData.Name}" description updated`
      );
    } else {
      //no update
      console.log(`ℹ️  ${flowModuleData.Name} already up to date`);
    }
  } catch (error) {
    if (error.name === "DuplicateResourceException") {
      console.error(
        `❌ Error deploying contact flow module definition for module "${flowModuleData.Name}": Resource already exists`
      );
      errorMessages.push(
        `❌ Error deploying contact flow module definition for module "${flowModuleData.Name}": Resource already exists`
      );
    } else if (error.name === "InvalidContactFlowModuleException") {
      console.error(
        `❌ Error deploying contact flow module definition for module "${flowModuleData.Name}": Invalid resource definition:`,
        error.Problems.map((item) => item.message)
      );
      errorMessages.push(
        `❌ Error deploying contact flow module definition for module "${flowModuleData.Name}": Invalid resource definition:`
      );
    } else {
      console.error(
        `❌ Error deploying contact flow module definition for module "${flowModuleData.Name}":`,
        error
      );
      errorMessages.push(
        `❌ Error deploying contact flow module definition for module "${flowModuleData.Name}":`
      );
    }
  }
}

// Fetch and store contact flow module definitions
async function fetchAndDeployContactFlowModuleDefinitions() {
  try {
    if (fs.existsSync("modules")) {
      const fileNames = fs.readdirSync("modules");
      for (const fileName of fileNames) {
        const flowModuleData = await fetchContactFlowModuleDefinition(
          `modules/${fileName}`
        );
        deployContactFlowModuleDefinition(flowModuleData);
      }
    }
  } catch (error) {
    console.error(
      "❌ Error fetching and deploying contact flow module definitions:",
      error
    );
  }
}

async function cacheDestinationResourcesData(){
  await getAccountId();
  await getDestinationContactFlowModules();
  await getDestinationPrompts();
  await getDestinationQueues();
  await getDestinationLexBots();
  await getDestinationContactFlows();
}

async function main() {
  try {
    await initializeConfig();
    await cacheDestinationResourcesData();
    await fetchAndDeployContactFlowModuleDefinitions();
  } catch (error) {
    console.error("❌ An error occurred:", error);
  }
}

main();
