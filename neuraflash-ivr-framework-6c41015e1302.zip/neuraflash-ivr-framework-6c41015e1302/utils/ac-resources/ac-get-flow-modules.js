const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { fromIni } = require("@aws-sdk/credential-providers");

const { getConnectInstanceId, getConfigFromFile } = (require("ts-node/register"), require("../../config/config.ts"));

const {
  LambdaClient,
  ListFunctionsCommand,
  ListAliasesCommand
} = require("@aws-sdk/client-lambda");

const {
  ConnectClient,
  ListQueuesCommand,
  ListContactFlowsCommand,
  ListPromptsCommand,
  DescribeContactFlowModuleCommand,
  ListContactFlowModulesCommand
} = require("@aws-sdk/client-connect");

const {
  LexModelsV2Client,
  ListBotsCommand,
  ListBotAliasesCommand
} = require("@aws-sdk/client-lex-models-v2");

// Parse command line arguments using yargs
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] --instanceId [instanceId] [--profile [profile]]"
  )
  .demandOption(["region", "stage"]) // region and stage arguments required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("instanceId", "Specify Amazon Connect instance ID") // description for the instanceId argument
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

const region = argv.region;
const stage = argv.stage;
const clientPrefix = getConfigFromFile(stage).clientPrefix;
const instanceId = argv.instanceId || getConnectInstanceId(stage, region);
// Set AWS SDK configuration
let config = { region: region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}
// AWS.config.update(config);

console.log(instanceId, clientPrefix)

const SKIP_MODULE_PREFIXES = ["sample", "y", "z", "_z", "_test"]; // Array of prefixes to skip
const PROMPTS_CACHE = {};
const LAMBDA_CACHE = {};
const QUEUES_CACHE = {};
const LEX_CACHE = {};
const CONTACT_FLOWS_CACHE = {};
const contactFlows = [];

const connectClient = new ConnectClient({ ...config });

// Clear the "modules" directory
function clearModulesDirectory() {
  try {
    if (fs.existsSync("modules")) {
      const files = fs.readdirSync("modules");
      for (const file of files) {
        const filePath = `modules/${file}`;
        fs.unlinkSync(filePath); // Remove each file
      }
      fs.rmdirSync("modules"); // Remove the directory
    }
  } catch (error) {
    console.error("❌ Error clearing the 'modules' directory:", error);
    throw error;
  }
}

async function populatePromptCache() {
  let nextToken;
  do {
    const params = {
      InstanceId: instanceId,
      NextToken: nextToken
    };
    const command = new ListPromptsCommand(params);
    const response = await connectClient.send(command);
    response.PromptSummaryList.forEach((connectPrompt) => {
      PROMPTS_CACHE[connectPrompt.Arn] = connectPrompt.Name;
    });
    nextToken = response.NextToken;
  } while (nextToken);

  return PROMPTS_CACHE;
}

async function populateLambdaCache() {
  // Set up the Lambda client
  const lambdaClient = new LambdaClient(config);

  let functions = [];
  let nextMarker;

  // Retrieve all Lambda functions
  do {
    const listFunctionsCommand = new ListFunctionsCommand({
      Marker: nextMarker
    });
    const functionData = await lambdaClient.send(listFunctionsCommand);
    functions = functions.concat(functionData.Functions);
    nextMarker = functionData.NextMarker;
  } while (nextMarker);

  // For each function, retrieve its aliases
  for (const func of functions) {
    let functionName = func.FunctionName;
    let aliases = [];
    let nextAliasMarker;

    do {
      const listAliasesCommand = new ListAliasesCommand({
        FunctionName: functionName,
        Marker: nextAliasMarker
      });
      const aliasData = await lambdaClient.send(listAliasesCommand);
      aliases = aliases.concat(aliasData.Aliases);
      nextAliasMarker = aliasData.NextMarker;
    } while (nextAliasMarker);

    if (functionName.includes(`${clientPrefix}-${stage}-${region}`)) {
      functionName = functionName.replace(
        `${clientPrefix}-${stage}-${region}`,
        "{clientPrefix}-{stage}-{region}"
      );
    }

    if (functionName.includes(`${instanceId.slice(-12)}`)) {
      functionName = functionName.replace(
        `${instanceId.slice(-12)}`,
        "{instanceId}"
      );
    }

    LAMBDA_CACHE[func.FunctionArn] = functionName;

    aliases.forEach((alias) => {
      LAMBDA_CACHE[alias.AliasArn] = `${functionName}:${alias.Name}`;
    });
  }
}

async function populateQueuesCache() {
  const queues = [];
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      QueueTypes: ["STANDARD"],
      NextToken: nextToken
    };
    const command = new ListQueuesCommand(input);
    const response = await connectClient.send(command);
    queues.push(...response.QueueSummaryList);
    nextToken = response.NextToken;
  } while (nextToken);

  for (const queue of queues) {
    QUEUES_CACHE[queue.Arn] = queue.Name;
  }
}

async function populateLexBotsCache() {
  try {
    // Initialize Lex client
    const client = new LexModelsV2Client({ region });

    // List all Lex bots
    const botsResponse = await client.send(new ListBotsCommand({}));
    const bots = botsResponse.botSummaries;

    if (!bots || bots.length === 0) {
      console.log("No Lex bots found.");
      return;
    }

    // For each bot, list the aliases and construct the cache
    for (const bot of bots) {
      const botId = bot.botId;
      let botName = bot.botName;

      if (botName.includes(`${clientPrefix}-${stage}-${region}`)) {
        botName = botName.replace(
          `${clientPrefix}-${stage}-${region}`,
          "{clientPrefix}-{stage}-{region}"
        );
      }

      // Fetch aliases for the current bot
      const aliasesResponse = await client.send(
        new ListBotAliasesCommand({ botId })
      );
      const aliases = aliasesResponse.botAliasSummaries;

      // If the bot has aliases, add them to the LEX_CACHE array
      if (aliases && aliases.length > 0) {
        aliases.forEach((alias) => {
          const aliasArn = `bot-alias/${bot.botId}/${alias.botAliasId}`;

          const aliasName = alias.botAliasName;

          LEX_CACHE[aliasArn] = `${botName}:${aliasName}`;
        });
      }
    }
  } catch (error) {
    console.error("Error fetching Lex aliases:", error);
  }
}

async function populateContactFlowsCache() {
  // const contactFlows = [];
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      NextToken: nextToken
    };
    const command = new ListContactFlowsCommand(input);
    const response = await connectClient.send(command);
    contactFlows.push(...response.ContactFlowSummaryList);
    nextToken = response.NextToken;
  } while (nextToken);

  for (const contactFlow of contactFlows) {
    CONTACT_FLOWS_CACHE[contactFlow.Arn] = contactFlow.Name;
  }
}

// Fetch contact flow module definition by ID
async function fetchContactFlowModule(moduleId) {
  try {
    const params = {
      InstanceId: instanceId,
      ContactFlowModuleId: moduleId
    };
    const command = new DescribeContactFlowModuleCommand(params);
    const response = await connectClient.send(command);
    return response.ContactFlowModule;
  } catch (error) {
    console.error(
      `❌ Error fetching contact flow module definition for ID "${moduleId}":`,
      error
    );
    throw error;
  }
}

// Store contact flow module definition locally
function storeContactFlowModule(moduleName, definition) {
  try {
    // Create the "modules" directory if it doesn't exist
    if (!fs.existsSync("modules")) {
      fs.mkdirSync("modules");
    }

    const filePath = `modules/${moduleName}.json`;
    fs.writeFileSync(filePath, JSON.stringify(definition), "utf-8");
    console.log(
      `✅ Contact flow module "${moduleName}" definition stored locally at ${filePath}`
    );
  } catch (error) {
    console.error(
      `❌ Error storing contact flow module definition for module "${moduleName}":`,
      error
    );
    throw error;
  }
}

function replaceARNWithName(moduleData) {
  let lambdaRegex = /"(arn:aws:lambda:.+?(?="))/g;
  moduleData.Content = moduleData.Content.replace(
    lambdaRegex,
    function (wholeMatch, lambdaArn) {
      if (!LAMBDA_CACHE[lambdaArn]) {
        console.log(`🟡 Error: Lambda ${lambdaArn} not found in DynamoDB`);
        return lambdaArn;
      }
      return `"<lambda:::` + LAMBDA_CACHE[lambdaArn] + ">";
    }
  );

  const lambdaDisplayNameRegex =
    /"LambdaFunctionARN":\{"displayName":"([^"]+)"\}/g;
  moduleData.Content = moduleData.Content.replace(
    lambdaDisplayNameRegex,
    function (wholeMatch, lambdaName) {
      lambdaName = lambdaName.replace(
        `${clientPrefix}-${stage}-${region}`,
        "{clientPrefix}-{stage}-{region}"
      );

      lambdaName = lambdaName.replace(
        `${instanceId.slice(-12)}`,
        "{instanceId}"
      );

      return `"LambdaFunctionARN":{"displayName":"${lambdaName}"}`;
    }
  );

  let promptRegex = /"PromptId":"(arn:aws:.+?(?="))/g;
  moduleData.Content = moduleData.Content.replace(
    promptRegex,
    function (wholeMatch, promptArn) {
      if (!PROMPTS_CACHE[promptArn]) {
        console.log(`🟡 Error: Prompt ${promptArn} not found in Connect`);
      }
      return `"PromptId":"<prompt:::` + PROMPTS_CACHE[promptArn] + ">";
    }
  );

  // Regular expression to match Lex bot-alias ARNs
  const lexArnRegex = /arn:aws:lex:[^:]+:[^:]+:bot-alias\/([^\/]+)\/([^\/"]+)/g;

  moduleData.Content = moduleData.Content.replace(
    lexArnRegex,
    (match, botId, aliasId) => {
      const key = `bot-alias/${botId}/${aliasId}`;
      if (LEX_CACHE[key]) {
        return `<lex:::${LEX_CACHE[key]}>`;
      } else {
        console.warn(
          `No match found in LEX_CACHE for botId: ${botId}, aliasId: ${aliasId}`
        );
        return match; // Keep original ARN if no match found in LEX_CACHE
      }
    }
  );

  const lexDisplayNameRegex = /"lexV2BotName":"([^"]+)"/g;
  moduleData.Content = moduleData.Content.replace(
    lexDisplayNameRegex,
    function (wholeMatch, lexBotName) {
      // Replace the specific prefix in the lexBotName
      lexBotName = lexBotName.replace(
        `${clientPrefix}-${stage}-${region}`,
        "{clientPrefix}-{stage}-{region}"
      );

      return `"lexV2BotName":"${lexBotName}"`;
    }
  );

  // Regular expression to match Amazon Connect queue ARNs
  const queueArnRegex =
    /arn:aws:connect:[^:]+:[^:]+:instance\/[^\/]+\/queue\/[^\/"]+/g;

  moduleData.Content = moduleData.Content.replace(queueArnRegex, (match) => {
    if (QUEUES_CACHE[match]) {
      return `<queue:::${QUEUES_CACHE[match]}>`;
    } else {
      console.warn(`No match found in QUEUES_CACHE for ARN: ${match}`);
      return match; // Keep original ARN if no match found in QUEUE_CACHE
    }
  });

  // Regular expression to match Amazon Connect flow ARNs
  const flowArnRegex =
    /arn:aws:connect:[^:]+:[^:]+:instance\/[^\/]+\/contact-flow\/[^\/"]+/g;

  moduleData.Content = moduleData.Content.replace(flowArnRegex, (match) => {
    if (CONTACT_FLOWS_CACHE[match]) {
      return `<flow:::${CONTACT_FLOWS_CACHE[match]}>`;
    } else {
      console.warn(`No match found in CONTACT_FLOWS_CACHE for ARN: ${match}`);
      return match; // Keep original ARN if no match found in CONTACT_FLOWS_CACHE
    }
  });
}

// Fetch and store contact flow module definitions
async function fetchAndStoreContactFlowModule(nextToken = null) {
  try {
    const params = {
      InstanceId: instanceId, // Use the provided instanceId
      NextToken: nextToken
    };
    const command = new ListContactFlowModulesCommand(params);
    const response = await connectClient.send(command);

    if (!response.ContactFlowModulesSummaryList.length) {
      console.log("❌ No contact flow modules found.");
      return;
    }

    // Fetch and store contact flow module definitions
    for (const module of response.ContactFlowModulesSummaryList) {
      const moduleId = module.Id;
      const moduleData = await fetchContactFlowModule(moduleId);
      const moduleName = module.Name;

      // Check if moduleName starts with any of the specified prefixes
      const shouldSkip = SKIP_MODULE_PREFIXES.some((prefix) =>
        moduleName.toLowerCase().startsWith(prefix.toLowerCase())
      );

      if (shouldSkip) {
        console.log(
          `ℹ️ Skipping module "${moduleName}" as it starts with a specified prefix.`
        );
      } else {
        replaceARNWithName(moduleData);
        storeContactFlowModule(moduleName, moduleData);
      }
    }

    // If there's a NextToken, fetch the next page of contact flow modules
    if (response.NextToken) {
      await fetchAndStoreContactFlowModule(response.NextToken);
    }
  } catch (error) {
    console.error(
      "❌ Error fetching and storing contact flow module definitions:",
      error
    );
    throw error;
  }
}

// Execute the script
async function main() {
  clearModulesDirectory();

  try {
    await populatePromptCache();
    await populateLambdaCache();
    await populateQueuesCache();
    await populateLexBotsCache();
    await populateContactFlowsCache();

    await fetchAndStoreContactFlowModule();
  } catch (error) {
    console.error("❌ An error occurred:", error);
  }
}

main();
