const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { fromIni } = require("@aws-sdk/credential-providers");

const { getConnectInstanceId, getConfigFromFile } = (require("ts-node/register"), require("../../config/config.ts"));

const {
  LambdaClient,
  ListFunctionsCommand,
  ListAliasesCommand
} = require("@aws-sdk/client-lambda");
const {
  ConnectClient,
  ListQueuesCommand,
  ListContactFlowsCommand,
  ListContactFlowModulesCommand,
  ListViewsCommand,
  ListPromptsCommand,
  DescribeContactFlowCommand
} = require("@aws-sdk/client-connect");

const {
  LexModelsV2Client,
  ListBotsCommand,
  ListBotAliasesCommand
} = require("@aws-sdk/client-lex-models-v2");

const SKIP_FLOW_PREFIXES = ["sample", "y", "z", "_z", "Default"]; // Array of prefixes to skip
const PROMPTS_CACHE = {};
const LAMBDA_CACHE = {};
const CONTACT_FLOWS_CACHE = {};
const CONTACT_FLOW_MODULES_CACHE = {};
const QUEUES_CACHE = {};
const LEX_CACHE = {};
const VIEWS_CACHE = {};
const contactFlows = [];

// Parse command line arguments using yargs
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] --instanceId [instanceId] [--profile [profile]]"
  )
  .demandOption(["region", "stage"]) // arguments required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("stage", "AWS env argument : dev|preprod|prod") // description for the stage argument
  .describe("instanceId", "Specify Amazon Connect instance ID") // description for the instanceId argument
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

// Set AWS SDK configuration
const region = argv.region;
const stage = argv.stage;
let config = { region: argv.region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}
const clientPrefix = getConfigFromFile(stage).clientPrefix;
const instanceId = argv.instanceId || getConnectInstanceId(stage, region);

const connectClient = new ConnectClient({ ...config });

// Clear the "flows" directory
function clearFlowsDirectory() {
  try {
    if (fs.existsSync("flows")) {
      const files = fs.readdirSync("flows");
      for (const file of files) {
        const filePath = `flows/${file}`;
        fs.unlinkSync(filePath); // Remove each file
      }
      fs.rmdirSync("flows"); // Remove the directory
    }
  } catch (error) {
    console.error("❌ Error clearing the 'flows' directory:", error);
    throw error;
  }
}

async function populatePromptCache() {
  let nextToken;
  do {
    const params = {
      InstanceId: instanceId,
      NextToken: nextToken
    };
    const command = new ListPromptsCommand(params);
    const response = await connectClient.send(command);

    response.PromptSummaryList.forEach((connectPrompt) => {
      PROMPTS_CACHE[connectPrompt.Arn] = connectPrompt.Name;
    });
    nextToken = response.NextToken;
  } while (nextToken);

  return PROMPTS_CACHE;
}

async function populateLambdaCache() {
  // Set up the Lambda client
  const lambdaClient = new LambdaClient({ region });

  let functions = [];
  let nextMarker;

  // Retrieve all Lambda functions
  do {
    const listFunctionsCommand = new ListFunctionsCommand({
      Marker: nextMarker
    });
    const functionData = await lambdaClient.send(listFunctionsCommand);
    functions = functions.concat(functionData.Functions);
    nextMarker = functionData.NextMarker;
  } while (nextMarker);

  // For each function, retrieve its aliases
  for (const func of functions) {
    let functionName = func.FunctionName;
    let aliases = [];
    let nextAliasMarker;

    do {
      const listAliasesCommand = new ListAliasesCommand({
        FunctionName: functionName,
        Marker: nextAliasMarker
      });
      const aliasData = await lambdaClient.send(listAliasesCommand);
      aliases = aliases.concat(aliasData.Aliases);
      nextAliasMarker = aliasData.NextMarker;
    } while (nextAliasMarker);

    if (functionName.includes(`${clientPrefix}-${stage}-${region}`)) {
      functionName = functionName.replace(
        `${clientPrefix}-${stage}-${region}`,
        "{clientPrefix}-{stage}-{region}"
      );
    }

    if (functionName.includes(`${instanceId.slice(-12)}`)) {
      functionName = functionName.replace(
        `${instanceId.slice(-12)}`,
        "{instanceId}"
      );
    }

    LAMBDA_CACHE[func.FunctionArn] = functionName;

    aliases.forEach((alias) => {
      LAMBDA_CACHE[alias.AliasArn] = `${functionName}:${alias.Name}`;
    });
  }
}

async function populateContactFlowsCache() {
  // const contactFlows = [];
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      NextToken: nextToken
    };
    const command = new ListContactFlowsCommand(input);
    const response = await connectClient.send(command);
    contactFlows.push(...response.ContactFlowSummaryList);
    nextToken = response.NextToken;
  } while (nextToken);

  for (const contactFlow of contactFlows) {
    CONTACT_FLOWS_CACHE[contactFlow.Arn] = contactFlow.Name;
  }
}

async function populateContactFlowModulesCache() {
  const contactFlowModules = [];
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      NextToken: nextToken
    };
    const command = new ListContactFlowModulesCommand(input);
    const response = await connectClient.send(command);
    contactFlowModules.push(...response.ContactFlowModulesSummaryList);
    nextToken = response.NextToken;
  } while (nextToken);

  for (const contactFlowModule of contactFlowModules) {
    CONTACT_FLOW_MODULES_CACHE[contactFlowModule.Id] = contactFlowModule.Name;
  }
}

async function populateQueuesCache() {
  const queues = [];
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      QueueTypes: ["STANDARD"],
      NextToken: nextToken
    };
    const command = new ListQueuesCommand(input);
    const response = await connectClient.send(command);
    queues.push(...response.QueueSummaryList);
    nextToken = response.NextToken;
  } while (nextToken);

  for (const queue of queues) {
    QUEUES_CACHE[queue.Arn] = queue.Name;
  }
}

async function populateViewsCache() {
  let nextToken;
  try {
    do {
      // Prepare the command to list views
      const command = new ListViewsCommand({
        InstanceId: instanceId,
        NextToken: nextToken,
      });

      // Send the command to AWS
      const response = await connectClient.send(command);

      // Process each view in the response
      response.ViewsSummaryList.forEach((view) => {
        VIEWS_CACHE[view.Arn] = view.Name;
      });
      // Update the nextToken for pagination
      nextToken = response.NextToken;
    } while (nextToken); // Continue if there's a next token
  } catch (error) {
    console.error("Error retrieving views:", error);
    throw error;
  }
}

async function populateLexBotsCache() {
  try {
    // Initialize Lex client
    const client = new LexModelsV2Client({ region });

    // List all Lex bots
    const botsResponse = await client.send(new ListBotsCommand({}));
    const bots = botsResponse.botSummaries;

    if (!bots || bots.length === 0) {
      console.log("No Lex bots found.");
      return;
    }

    // For each bot, list the aliases and construct the cache
    for (const bot of bots) {
      const botId = bot.botId;
      let botName = bot.botName;

      if (botName.includes(`${clientPrefix}-${stage}-${region}`)) {
        botName = botName.replace(
          `${clientPrefix}-${stage}-${region}`,
          "{clientPrefix}-{stage}-{region}"
        );
      }

      // Fetch aliases for the current bot
      const aliasesResponse = await client.send(
        new ListBotAliasesCommand({ botId })
      );
      const aliases = aliasesResponse.botAliasSummaries;

      // If the bot has aliases, add them to the LEX_CACHE array
      if (aliases && aliases.length > 0) {
        aliases.forEach((alias) => {
          const aliasArn = `bot-alias/${bot.botId}/${alias.botAliasId}`;

          const aliasName = alias.botAliasName;

          LEX_CACHE[aliasArn] = `${botName}:${aliasName}`;
        });
      }
    }
  } catch (error) {
    console.error("Error fetching Lex aliases:", error);
  }
}

// Fetch contact flow definition by ID
async function fetchContactFlow(flowId) {
  try {
    const params = {
      InstanceId: instanceId,
      ContactFlowId: flowId
    };
    const command = new DescribeContactFlowCommand(params);
    const response = await connectClient.send(command);
    return response.ContactFlow;
  } catch (error) {
    if (error.code === "ContactFlowNotPublishedException") {
      throw error;
    } else {
      console.error(
        `❌ Error fetching contact flow definition for ID "${flowId}":`,
        error
      );
      throw error;
    }
  }
}

// Store contact flow definition locally
function storeContactFlow(flowName, definition) {
  try {
    // Create the "flows" directory if it doesn't exist
    if (!fs.existsSync("flows")) {
      fs.mkdirSync("flows");
    }
    const filePath = `flows/${flowName}.json`;
    fs.writeFileSync(filePath, JSON.stringify(definition), "utf-8");
    console.log(
      `✅ Contact flow "${flowName}" definition stored locally at ${filePath}`
    );
  } catch (error) {
    console.error(
      `❌ Error storing contact flow definition for flow "${flowName}":`,
      error
    );
    throw error;
  }
}

// Fetch and store contact flow definitions
async function fetchAndStoreContactFlow() {
  try {
    // Fetch and store contact flow definitions
    for (const flow of contactFlows) {
      const flowId = flow.Id;
      try {
        const flowName = flow.Name;
        // Check if flowName starts with any of the specified prefixes
        const shouldSkip = SKIP_FLOW_PREFIXES.some((prefix) =>
          flowName.toLowerCase().startsWith(prefix.toLowerCase())
        );
        if (shouldSkip) {
          console.log(
            `ℹ️ Skipping flow "${flowName}" as it starts with a specified prefix.`
          );
        } else {
          const flowData = await fetchContactFlow(flowId);

          let lambdaRegex = /"(arn:aws:lambda:.+?(?="))/g;
          flowData.Content = flowData.Content.replace(
            lambdaRegex,
            function (wholeMatch, lambdaArn) {
              // lambdaArn = lambdaArn.replace(/:active$/, ""); //remove :active suffix
              if (!LAMBDA_CACHE[lambdaArn]) {
                console.log(
                  `🟡 Error: Lambda ${lambdaArn} not found in DynamoDB`
                );
                return lambdaArn;
              }
              return `"<lambda:::` + LAMBDA_CACHE[lambdaArn] + ">";
            }
          );

          const lambdaDisplayNameRegex =
            /"LambdaFunctionARN":\{"displayName":"([^"]+)"\}/g;
          flowData.Content = flowData.Content.replace(
            lambdaDisplayNameRegex,
            function (wholeMatch, lambdaName) {
              lambdaName = lambdaName.replace(
                `${clientPrefix}-${stage}-${region}`,
                "{clientPrefix}-{stage}-{region}"
              );

              lambdaName = lambdaName.replace(
                `${instanceId.slice(-12)}`,
                "{instanceId}"
              );

              return `"LambdaFunctionARN":{"displayName":"${lambdaName}"}`;
            }
          );

          let promptRegex = /"PromptId":"(arn:aws:.+?(?="))/g;
          flowData.Content = flowData.Content.replace(
            promptRegex,
            function (wholeMatch, promptArn) {
              if (!PROMPTS_CACHE[promptArn]) {
                console.log(
                  `🟡 Error: Prompt ${promptArn} not found in Connect`
                );
              }
              return `"PromptId":"<prompt:::` + PROMPTS_CACHE[promptArn] + ">";
            }
          );

          // Regular expression to match Lex bot-alias ARNs
          const lexArnRegex =
            /arn:aws:lex:[^:]+:[^:]+:bot-alias\/([^\/]+)\/([^\/"]+)/g;

          flowData.Content = flowData.Content.replace(
            lexArnRegex,
            (match, botId, aliasId) => {
              const key = `bot-alias/${botId}/${aliasId}`;
              if (LEX_CACHE[key]) {
                return `<lex:::${LEX_CACHE[key]}>`;
              } else {
                console.warn(
                  `No match found in LEX_CACHE for botId: ${botId}, aliasId: ${aliasId}`
                );
                return match; // Keep original ARN if no match found in LEX_CACHE
              }
            }
          );

          const lexDisplayNameRegex = /"lexV2BotName":"([^"]+)"/g;
          flowData.Content = flowData.Content.replace(
            lexDisplayNameRegex,
            function (wholeMatch, lexBotName) {
              // Replace the specific prefix in the lexBotName
              lexBotName = lexBotName.replace(
                `${clientPrefix}-${stage}-${region}`,
                "{clientPrefix}-{stage}-{region}"
              );

              return `"lexV2BotName":"${lexBotName}"`;
            }
          );

          // Regular expression to match Amazon Connect queue ARNs
          const queueArnRegex =
            /arn:aws:connect:[^:]+:[^:]+:instance\/[^\/]+\/queue\/[^\/"]+/g;

          flowData.Content = flowData.Content.replace(
            queueArnRegex,
            (match) => {
              if (QUEUES_CACHE[match]) {
                return `<queue:::${QUEUES_CACHE[match]}>`;
              } else {
                console.warn(
                  `No match found in QUEUES_CACHE for ARN: ${match}`
                );
                return match; // Keep original ARN if no match found in QUEUE_CACHE
              }
            }
          );

          // Regular expression to match Amazon Connect flow ARNs
          const flowArnRegex =
            /arn:aws:connect:[^:]+:[^:]+:instance\/[^\/]+\/contact-flow\/[^\/"]+/g;

          flowData.Content = flowData.Content.replace(flowArnRegex, (match) => {
            if (CONTACT_FLOWS_CACHE[match]) {
              return `<flow:::${CONTACT_FLOWS_CACHE[match]}>`;
            } else {
              console.warn(
                `No match found in CONTACT_FLOWS_CACHE for ARN: ${match}`
              );
              return match; // Keep original ARN if no match found in CONTACT_FLOWS_CACHE
            }
          });

          // Regular expression to match Flow Module IDs (UUID format)
          const flowModuleIdRegex = /"FlowModuleId":"([0-9a-fA-F-]+)"/g;

          flowData.Content = flowData.Content.replace(
            flowModuleIdRegex,
            (match, flowModuleId) => {
              if (CONTACT_FLOW_MODULES_CACHE[flowModuleId]) {
                const flowModuleName = CONTACT_FLOW_MODULES_CACHE[flowModuleId];
                return `"FlowModuleId":"<flowModule:::${flowModuleName}>"`;
              } else {
                console.warn(
                  `No match found in CONTACT_FLOW_MODULES_CACHE for ID: ${flowModuleId}`
                );
                return match; // Keep original ID if no match found in CONTACT_FLOW_MODULES_CACHE
              }
            }
          );

          // Regular expression to match Amazon Connect views ARNs
          const viewArnRegex =
            /(arn:aws:connect:[^:]+:\d+:instance\/[^/]+\/view\/[^:]+)(:[^"]+)?/g
          flowData.Content = flowData.Content.replace(
            viewArnRegex,
            (match, baseArn, aliasOrVersion) => {
              const viewName = VIEWS_CACHE[baseArn];
              if (VIEWS_CACHE[baseArn]) {
                return `<view:::${viewName}${aliasOrVersion}>`;
              } else {
                console.warn(`No match found in VIEWS_CACHE for ARN: ${match}`);
                return match; // Keep original ARN if no match found in VIEWS_CACHE
              }
            }
          );

          flowData.Content = flowData.Content.replace(
            /arn:aws:connect:[^:]+:aws:view\/[^:]+:\d+/g,
            (match) => {
              return match.replace(
                /arn:aws:connect:[^:]+/,
                "arn:aws:connect:{region}"
              );
            }
          );
          
          storeContactFlow(flowName, flowData);
        }
      } catch (error) {
        if (error.code === "ContactFlowNotPublishedException") {
          console.log(
            `❌ Contact flow "${flowId}" is not published, skipping.`
          );
        } else {
          throw error; // Rethrow other errors
        }
      }
    }
  } catch (error) {
    console.error(
      "❌ Error fetching and storing contact flow definitions:",
      error
    );
    throw error;
  }
}

// Execute the script
async function main() {
  clearFlowsDirectory();

  try {
    await populatePromptCache();
    await populateLambdaCache();
    await populateContactFlowsCache();
    await populateContactFlowModulesCache();
    await populateQueuesCache();
    await populateLexBotsCache();
    await populateViewsCache();

    await fetchAndStoreContactFlow();
  } catch (error) {
    console.error("❌ An error occurred:", error);
  }
}

main();
