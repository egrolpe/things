# AC Resources

A Node.js utility for managing Amazon Connect resources including contact flows, flow modules, and views. This tool enables version control and deployment of Connect resources across different environments using placeholder-based configuration.

## Features

- **Deploy Resources**: Deploy contact flows, flow modules, and views to Amazon Connect
- **Retrieve Resources**: Export existing Connect resources with placeholder substitution
- **Environment Agnostic**: Uses placeholders to make resources portable across environments
- **AWS Integration**: Leverages AWS SDK for seamless integration with Connect services

## Installation

1. Navigate to the ac-resources directory:
   ```bash
   cd utils/ac-resources
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

## Usage

### Retrieve Contact Flows

Export contact flows from Amazon Connect to local JSON files:

```bash
node ac-get-flows.js --region us-west-2 --stage dev --tableName your-config-table [--instanceID your-instance-id] [--profile your-aws-profile]
```

**Parameters:**
- `--region`: AWS region (required)
- `--stage`: Environment stage (dev/preprod/prod) (required)
- `--tableName`: DynamoDB config table name (required)
- `--instanceID`: Amazon Connect instance ID (optional, can be derived from config)
- `--profile`: AWS profile name (optional)

### Deploy Contact Flows

Deploy contact flows from JSON files in the `flows/` directory:

```bash
node ac-deploy-flows.js --region us-west-2 --stage dev --tableName your-config-table [--instanceID your-instance-id] [--profile your-aws-profile]
```

**Parameters:**
- `--region`: AWS region (required)
- `--stage`: Environment stage (dev/preprod/prod) (required)
- `--tableName`: DynamoDB config table name (required)
- `--instanceID`: Amazon Connect instance ID (optional, can be derived from config)
- `--profile`: AWS profile name (optional)
- `--inputDir`: Custom input directory for flow files (optional, defaults to "flows")

### Retrieve Flow Modules

Export flow modules from Amazon Connect:

```bash
node ac-get-flow-modules.js --region us-west-2 --stage dev --tableName your-config-table [--instanceID your-instance-id] [--profile your-aws-profile]
```

### Deploy Flow Modules

Deploy flow modules from JSON files in the `modules/` directory:

```bash
node ac-deploy-flow-modules.js --region us-west-2 --stage dev --tableName your-config-table [--instanceID your-instance-id] [--profile your-aws-profile]
```

### Retrieve Views

Export views from Amazon Connect:

```bash
node ac-get-views.js --region us-west-2 --stage dev --tableName your-config-table [--instanceID your-instance-id] [--profile your-aws-profile]
```

### Deploy Views

Deploy views from JSON files:

```bash
node ac-deploy-views.js --region us-west-2 --stage dev --tableName your-config-table [--instanceID your-instance-id] [--profile your-aws-profile]
```

### Example Flow JSON

```json
{
  "Name": "Sample Flow",
  "Type": "CONTACT_FLOW",
  "Content": "{\"Version\":\"2019-10-30\",\"Actions\":[{\"Parameters\":{\"LambdaFunctionARN\":\"<lambda:::{clientPrefix}-{stage}-{region}-config-retrieval>\",\"QueueId\":\"<queue:::BasicQueue>\"},\"Identifier\":\"action1\",\"Type\":\"InvokeLambdaFunction\"}]}"
}
```

## Directory Structure

```
utils/ac-resources/
├── flows/              # Contact flow JSON files
├── modules/            # Flow module JSON files
├── ac-deploy-flows.js  # Deploy contact flows
├── ac-get-flows.js     # Retrieve contact flows
├── ac-deploy-flow-modules.js  # Deploy flow modules
├── ac-get-flow-modules.js     # Retrieve flow modules
├── ac-deploy-views.js  # Deploy views
├── ac-get-views.js     # Retrieve views
├── package.json        # Dependencies
└── README.md          # This file
```

## Workflow

### Development Workflow

1. **Retrieve** existing resources from production/dev environment:
   ```bash
   node ac-get-flows.js --region us-west-2 --stage prod --tableName config-table
   ```

2. **Modify** the JSON files in `flows/`, `modules/`, or `views/` directories

3. **Deploy** to target environment:
   ```bash
   node ac-deploy-flows.js --region us-west-2 --stage dev --tableName config-table
   ```
