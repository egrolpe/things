# AWS DynamoDB Config Convert CSV to DynamoDB

This directory contains one node.js script. This script takes a cloudwatch dashboard name and dashboard json config file and creates a Cloudwatch dashboard.

## Prerequisites

- node.js (version: `node -v` | install: `brew install node`)
- node package manager (version: `npm -v` | install: `brew install npm`)

## How to use the scripts

Before running the script:

1. Open a terminal and navigate to the directory where the script is saved.
2. Execute `npm i` to install necessary modules

To use the script, run the following command:

`node put-dashboard.js --region <region> --dashboardName <dashboardName> --dashboardFilePath <dashboardFilePath>`

Optionally, include the profile name:

`node put-dashboard.js --region <region> --dashboardName <dashboardName> --dashboardFilePath <dashboardFilePath> --profile <profile>`

example -
`node put-dashboard.js --region us-west-2 --dashboardName NF-DEV-LexBotAnalysisDashboard --dashboardFilePath lex-dashboard-config.json --profile lt-dev`
