const {
  CloudWatchClient,
  PutDashboardCommand
} = require("@aws-sdk/client-cloudwatch");
const fs = require("fs");
const path = require("path");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { fromIni } = require("@aws-sdk/credential-providers");

// Parse command line arguments using yargs
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --dashboardName [dashboardName] --dashboardFilePath [dashboardFilePath] --profile [profile]"
  )
  .demandOption(["region", "dashboardName", "dashboardFilePath"]) // arguments required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("dashboardName", "Specify dashboard name") // description for the dashboardName
  .describe("dashboardFilePath", "Specify dashboard config file path")
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

let config = { region: argv.region };
if (argv.profile) {
  config = {
    ...config,
    credentials: fromIni({ profile: argv.profile })
  };
}

// Initialize the CloudWatch client
const client = new CloudWatchClient(config);

// Define your dashboard name
const dashboardName = argv.dashboardName;

// Read the dashboard configuration from the JSON file
const dashboardFilePath = path.join(__dirname, argv.dashboardFilePath);
const dashboardBody = fs.readFileSync(dashboardFilePath, "utf-8");

async function createOrUpdateDashboard() {
  try {
    // Create or update the dashboard
    const command = new PutDashboardCommand({
      DashboardName: dashboardName,
      DashboardBody: dashboardBody
    });

    const response = await client.send(command);
    console.log("✅ Dashboard created or updated successfully:", response);
  } catch (error) {
    console.error("❌ Error creating or updating dashboard:", error);
  }
}

// Run the function
createOrUpdateDashboard();
