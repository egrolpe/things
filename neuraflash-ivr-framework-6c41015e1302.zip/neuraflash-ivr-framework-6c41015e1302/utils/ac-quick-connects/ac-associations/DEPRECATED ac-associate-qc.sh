#!/bin/bash

# Update the following variables with your own values:
REGION="us-west-2" # Replace with your desired AWS region
INSTANCE_ID="arn:aws:connect:us-west-2:162798700688:instance/2035f76c-ec9e-4819-8edc-a8b4df501747" # Replace with your Amazon Connect instance ID
QUEUE_NAME="ERS QC" # Replace with the name for the QuickConnects queue
QUEUE_DESCRIPTION="Queue for ERS Quick Connects" # Replace with the description for the QuickConnects queue
PROFILE="aws-dev" # Replace with the AWS CLI profile name to use
CSV_FILE="quick-connects.csv"  # Path to the CSV file containing QuickConnect names
RP_PREFIX="" # Prefix for Routing Profile names (Associates to all Routing Profiles when defined as empty string)

# Check if the queue already exists
QUEUE_INFO=$(aws connect list-queues --instance-id "$INSTANCE_ID" --queue-types "STANDARD" --region "$REGION" --profile "$PROFILE" --query "QueueSummaryList[?Name=='$QUEUE_NAME']" --output json)

if [ -n "$QUEUE_INFO" ] && [ "$QUEUE_INFO" != "[]" ]; then
  echo "Queue already exists."

  # Get the QUEUE_ID for the QuickConnects Queue
  QUEUE_ID=$(echo "$QUEUE_INFO" | jq -r '.[].Id')

  if [ -z "$QUEUE_ID" ]; then
    echo "Failed to retrieve the Queue ID for the QuickConnects Queue."
    exit 1
  fi

  echo "Retrieved Queue ID: $QUEUE_ID"
else
  echo "Queue does not exist. Creating the queue..."

  # Get the Hours of Operations ID for 'Basic Hours'
  HOURS_OF_OPERATION_ID=$(aws connect list-hours-of-operations --instance-id "$INSTANCE_ID" --region "$REGION" --profile "$PROFILE" --query 'HoursOfOperationSummaryList[?Name==`Basic Hours`].Id' --output text)

  if [ -z "$HOURS_OF_OPERATION_ID" ]; then
    echo "Failed to retrieve the Hours of Operations ID for 'Basic Hours'."
    exit 1
  fi

  # Create the queue and retrieve the QueueId
  QUEUE_ID=$(aws connect create-queue --instance-id "$INSTANCE_ID" --region "$REGION" --profile "$PROFILE" --name "$QUEUE_NAME" --description "$QUEUE_DESCRIPTION" --hours-of-operation-id "$HOURS_OF_OPERATION_ID" --query 'QueueId' --output text)

  if [ -z "$QUEUE_ID" ]; then
    echo "Failed to create the queue."
    exit 1
  fi

  echo "Created the QuickConnects queue with ID: $QUEUE_ID"
fi

# Read the QuickConnect names from the CSV file into an array
IFS=$'\n' read -d '' -r -a QC_NAMES < <(tail -n +2 "$CSV_FILE" | cut -d',' -f1)

# Convert the QuickConnect names array to a JSON array
QC_NAMES_JSON=$(printf '%s\n' "${QC_NAMES[@]}" | jq -R . | jq -s .)

# Retrieve the QuickConnects for the instance with pagination handling
QUICK_CONNECT_IDS=()
NEXT_TOKEN=""
while true; do
  if [ -n "$NEXT_TOKEN" ]; then
    QUICK_CONNECTS=$(aws connect list-quick-connects --instance-id "$INSTANCE_ID" --region "$REGION" --profile "$PROFILE" --output json --starting-token "$NEXT_TOKEN")
  else
    QUICK_CONNECTS=$(aws connect list-quick-connects --instance-id "$INSTANCE_ID" --region "$REGION" --profile "$PROFILE" --output json)
  fi
  
  if [ -z "$QUICK_CONNECTS" ] || [ "$QUICK_CONNECTS" = "[]" ]; then
    echo "No QuickConnects found for the instance."
    break
  fi

  # Extract the QuickConnect IDs and names from the current page
  PAGE_QUICK_CONNECT_IDS=$(echo "$QUICK_CONNECTS" | jq -r --argjson names "$QC_NAMES_JSON" '.QuickConnectSummaryList[] | select(.Name | IN($names[])) | .Id')
  PAGE_QUICK_CONNECT_NAMES=$(echo "$QUICK_CONNECTS" | jq -r --argjson names "$QC_NAMES_JSON" '.QuickConnectSummaryList[] | select(.Name | IN($names[])) | .Name')
  
  # Append the QuickConnect IDs to the list
  QUICK_CONNECT_IDS+=($PAGE_QUICK_CONNECT_IDS)
  
  # Check if there are more pages
  NEXT_TOKEN=$(echo "$QUICK_CONNECTS" | jq -r '.NextToken')
  if [ "$NEXT_TOKEN" = "null" ]; then
    break
  fi
done

# Associate each QuickConnect with the QuickConnects queue
for QUICK_CONNECT_ID in "${QUICK_CONNECT_IDS[@]}"; do
  echo "Associating QuickConnect $QUICK_CONNECT_ID with the queue $QUEUE_ID..."

  # Associate the QuickConnect with the queue
  aws connect associate-queue-quick-connects --instance-id "$INSTANCE_ID" --region "$REGION" --profile "$PROFILE" --quick-connect-ids "$QUICK_CONNECT_ID" --queue-id "$QUEUE_ID"

  if [ $? -eq 0 ]; then
    echo "Associated QuickConnect $QUICK_CONNECT_ID with the queue $QUEUE_ID successfully."
  else
    echo "Failed to associate QuickConnect $QUICK_CONNECT_ID with the queue $QUEUE_ID."
  fi
done

echo "QuickConnects associated with the QuickConnects queue."

# Retrieve the Routing Profiles with pagination handling
ROUTING_PROFILE_IDS=()
NEXT_TOKEN=""
while true; do
  if [ -n "$NEXT_TOKEN" ]; then
    ROUTING_PROFILES=$(aws connect list-routing-profiles --instance-id "$INSTANCE_ID" --region "$REGION" --profile "$PROFILE" --output json --starting-token "$NEXT_TOKEN")
  else
    ROUTING_PROFILES=$(aws connect list-routing-profiles --instance-id "$INSTANCE_ID" --region "$REGION" --profile "$PROFILE" --output json)
  fi
  
  if [ -z "$ROUTING_PROFILES" ] || [ "$ROUTING_PROFILES" = "[]" ]; then
    echo "No Routing Profiles found for the instance."
    break
  fi

  # Extract the Routing Profile IDs from the current page
  PAGE_ROUTING_PROFILE_IDS=$(echo "$ROUTING_PROFILES" | jq -r --arg prefix "$RP_PREFIX" '.RoutingProfileSummaryList[] | select(.Name | startswith($prefix)) | .Id')
  
  # Append the Routing Profile IDs to the list
  ROUTING_PROFILE_IDS+=($PAGE_ROUTING_PROFILE_IDS)
  
  # Check if there are more pages
  NEXT_TOKEN=$(echo "$ROUTING_PROFILES" | jq -r '.NextToken')
  if [ "$NEXT_TOKEN" = "null" ]; then
    break
  fi
done

# Associate each Routing Profile with the QuickConnects queue
for ROUTING_PROFILE_ID in "${ROUTING_PROFILE_IDS[@]}"; do
  echo "Associating Routing Profile $ROUTING_PROFILE_ID with the queue $QUEUE_ID..."

  # Associate the Routing Profile with the queue
  QUEUE_CONFIGS='[{"QueueReference": {"QueueId": "'"$QUEUE_ID"'", "Channel": "VOICE"}, "Priority": 1, "Delay": 0}]'
  aws connect associate-routing-profile-queues --instance-id "$INSTANCE_ID" --region "$REGION" --profile "$PROFILE" --routing-profile-id "$ROUTING_PROFILE_ID" --queue-configs "$QUEUE_CONFIGS"

  if [ $? -eq 0 ]; then
    echo "Associated Routing Profile $ROUTING_PROFILE_ID with the queue $QUEUE_ID successfully."
  else
    echo "Failed to associate Routing Profile $ROUTING_PROFILE_ID with the queue $QUEUE_ID."
  fi
done

echo "Routing Profiles associated with the QuickConnects queue."