// Run this script to associate quick connects with queues and routing profiles
// Run npm i to install required modules
// Run 'node ac-associate-qc.js --stage [stage] --region [region] [--profile [profile]]' to associate quick connects
// Run 'node ac-associate-qc.js --help' to see the options for running the script
// Run 'node ac-associate-qc.js --stage dev --region us-east-1 --profile exampleProfile' to associate quick connects using the adminuser profile

// Update configuration before executing the script
let queueName = "Quick Connect Queue"; // Replace with the name for the QuickConnects queue

// import required modules
const { fromIni } = require("@aws-sdk/credential-provider-ini");
const {
  ConnectClient,
  ListQueuesCommand,
  ListHoursOfOperationsCommand,
  ListQuickConnectsCommand,
  ListRoutingProfilesCommand,
  AssociateQueueQuickConnectsCommand,
  AssociateRoutingProfileQueuesCommand,
  CreateQueueCommand,
  ListRoutingProfileQueuesCommand,
  DisassociateRoutingProfileQueuesCommand
} = require("@aws-sdk/client-connect");
const csv = require("csv-parser");
const fs = require("fs");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

// parse command line arguments using yargs
const argv = require("yargs/yargs")(process.argv.slice(2))
  .usage("Usage: $0 --stage [stage] --region [region] [--profile [profile]] [--instanceId [instanceId]] [--queueName [queueName]] [--queueDescription [queueDescription]] [--qcCsv [qcCsv]] [--rpPrefix [rpPrefix]]")
  .demandOption(["stage", "region"])
  .describe("region", "Specify the region to associate quick connects")
  .describe("stage", "Specify stage to target the deployment to")
  .describe(
    "instanceId",
    "Specify the connect instance Arn to associate quick connects"
  )
  .describe(
    "queueName",
    "Specify the queue name to contain all the quick connects"
  )
  .describe(
    "queueDescription",
    "Specify the queue description for the queue that contains all the quick connects"
  )
  .describe(
    "qcCsv",
    "Specify the csv file containing a column with the header 'qcName' and filled with the names of the quick connects to add to the queue"
  )
  .describe(
    "rpPrefix",
    "Specify the routing profile prefix. All routing profiles with this prefix will be assigned the queue containing the quick connects"
  )
  .describe("profile", "Optionally specify AWS profile").argv;

// set AWS SDK configuration
const region = argv.region;
const stage = argv.stage;
let config = { region, maxAttempts: 15 };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}

const queueDescription = argv.queueDescription || "Queue used to collect all Quick Connects to assign to a Routing Profile.";
const qcCsv = argv.qcCsv || "./ac-associations.csv";
const rpPrefix = argv.rpPrefix || "";
const instanceId = argv.instanceId || getConnectInstanceId(stage, region)

// Helper function to read and parse a CSV file
function readCsvFile(filePath) {
  return new Promise((resolve, reject) => {
    const results = [];
    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (data) => results.push(data))
      .on("end", () => resolve(results))
      .on("error", (error) => reject(error));
  });
}

const destinationHoursOfOperation = {};
async function getDestinationHoursOfOperation() {
  if (Object.keys(destinationHoursOfOperation).length > 0) {
    return destinationHoursOfOperation;
  }
  const client = new ConnectClient({ ...config, region });
  let nextToken = null;
  do {
    const command = new ListHoursOfOperationsCommand({
      InstanceId: instanceId,
      NextToken: nextToken
    });
    const response = await client.send(command);
    nextToken = response.NextToken;
    response.HoursOfOperationSummaryList.forEach((element) => {
      destinationHoursOfOperation[element.Name] = element;
    });
  } while (nextToken);
  return destinationHoursOfOperation;
}

const destinationQueues = {};
async function getConnectQueues(config, region, instanceId) {
  if (Object.keys(destinationQueues).length > 0) {
    return destinationQueues;
  }
  const client = new ConnectClient({ ...config, region });
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      // QueueTypes: ["STANDARD"],
      NextToken: nextToken
    };
    const command = new ListQueuesCommand(input);
    const response = await client.send(command);
    nextToken = response.NextToken;
    response.QueueSummaryList.forEach((element) => {
      destinationQueues[element.Name] = element;
    });
  } while (nextToken);
  return destinationQueues;
}

const destinationQuickConnects = {};
async function getConnectQuickConnects(config, region, instanceId) {
  if (Object.keys(destinationQuickConnects).length > 0) {
    return destinationQuickConnects;
  }
  const client = new ConnectClient({ ...config, region });
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      NextToken: nextToken
    };
    const command = new ListQuickConnectsCommand(input);
    const response = await client.send(command);
    nextToken = response.NextToken;
    response.QuickConnectSummaryList.forEach((element) => {
      destinationQuickConnects[element.Name] = element;
    });
  } while (nextToken);
  return destinationQuickConnects;
}

const destinationRoutingProfiles = [];
async function getConnectRoutingProfiles(config, region, instanceId) {
  if (destinationRoutingProfiles.length > 0) {
    return destinationRoutingProfiles;
  }
  const client = new ConnectClient({ ...config, region });
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      NextToken: nextToken
    };
    const command = new ListRoutingProfilesCommand(input);
    const response = await client.send(command);
    nextToken = response.NextToken;
    destinationRoutingProfiles.push(...response.RoutingProfileSummaryList);
  } while (nextToken);
  return destinationRoutingProfiles;
}

// Main script logic
async function main() {
  const connectClient = new ConnectClient({ ...config, region });

  let queueInfo = (await getConnectQueues(config, region, instanceId))?.[
    queueName
  ];
  let queueId = "";
  if (!queueInfo) {
    // queue does not exist, create queue
    logMessage(`Queue '${queueName}' does not exist, creating queue`, "info");
    let basicHoursOfOperationInfo =
      (await getDestinationHoursOfOperation())?.["Basic Hours"] ||
      (await getDestinationHoursOfOperation())?.[0];
    const command = new CreateQueueCommand({
      HoursOfOperationId: basicHoursOfOperationInfo.Id,
      InstanceId: instanceId,
      Name: queueName,
      Description: queueDescription
    });

    const response = await connectClient.send(command);
    queueId = response.QueueId;
  } else {
    // queue exists
    logMessage(
      `Queue '${queueName}' already exists, adding Quick Connects to this existing queue`,
      "info"
    );
    queueId = queueInfo.Id;
  }

  //get qc from csv
  logMessage("Reading CSV", "info");
  const quickConnectsCsv = await readCsvFile(qcCsv);
  console.log(quickConnectsCsv);
  let quickConnects = [];
  for (const quickConnect of quickConnectsCsv) {
    const { qcName } = quickConnect;
    quickConnects.push(qcName);
  }

  // get qc from connect
  logMessage("Getting Quick Connects in Amazon Connect", "info");
  const connectQuickConnects = await getConnectQuickConnects(
    config,
    region,
    instanceId
  );

  //filter with qc from csv to the queue
  let quickConnectIds = quickConnects.map((element) => {
    if (!connectQuickConnects[element]?.Id) {
      console.log(
        `Quick Connect '${element}' does not exist in Amazon Connect`
      );
    }
    return connectQuickConnects[element]?.Id;
  });

  // associate qcs,
  logMessage(`Associating Quick Connects to Queue '${queueName}'`, "info");
  do {
    const command = new AssociateQueueQuickConnectsCommand({
      InstanceId: instanceId,
      QueueId: queueId,
      QuickConnectIds: quickConnectIds.slice(0, 50)
    });
    await connectClient.send(command);

    quickConnectIds = quickConnectIds.slice(50);
  } while (quickConnectIds.length > 0);

  // get rp from connect
  logMessage("Getting Routing Profiles in Amazon Connect", "info");
  const connectRoutingProfiles = await getConnectRoutingProfiles(
    config,
    region,
    instanceId
  );
  //if rpPrefix specified, filter so that we only grab routing profile ids who match the prefix
  let filteredConnectRoutingProfileIds = connectRoutingProfiles.reduce(
    (accumulator, element) => {
      if (!rpPrefix || element.Name.startsWith(rpPrefix)) {
        accumulator.push(element.Id);
      }
      return accumulator;
    },
    []
  );

  //associate each RP with the queue
  let routingProfileId = "";
  logMessage(`Associating Queue '${queueName}' to Routing Profiles`, "info");
  for (routingProfileId of filteredConnectRoutingProfileIds) {
    // #region disassociate any queues with an incorrect priority or delay
    let nextToken;
    let hasIncorectQueueConfig = false;
    do {
      const command = new ListRoutingProfileQueuesCommand({
        InstanceId: instanceId,
        RoutingProfileId: routingProfileId,
        NextToken: nextToken
      });
      const response = await connectClient.send(command);
      response.RoutingProfileQueueConfigSummaryList.forEach((element) => {
        if (
          element.QueueId === queueId &&
          (element.Priority !== 99 || element.Delay !== 0)
        ) {
          //if config doesn't match, need to disassociate the queue from the routing profile
          logMessage(
            `Found incorrect Queue Config on Routing Profile '${routingProfileId}'`,
            "info"
          );
          hasIncorectQueueConfig = true;
        }
      });
      nextToken = response.NextToken;
    } while (nextToken && !hasIncorectQueueConfig);

    if (hasIncorectQueueConfig) {
      //dissassociate
      logMessage(
        `Disassociating Incorrect Queue '${queueName}' Config on Routing Profile '${routingProfileId}'`,
        "info"
      );
      const command = new DisassociateRoutingProfileQueuesCommand({
        InstanceId: instanceId,
        RoutingProfileId: routingProfileId,
        QueueReferences: [
          {
            QueueId: queueId,
            Channel: "VOICE"
          }
        ]
      });
      await connectClient.send(command);
    }
    // #endregion

    logMessage(`Associate to Routing Profile '${routingProfileId}'`, "info");
    const command = new AssociateRoutingProfileQueuesCommand({
      InstanceId: instanceId,
      RoutingProfileId: routingProfileId,
      QueueConfigs: [
        {
          Delay: 0,
          Priority: 99,
          QueueReference: {
            QueueId: queueId,
            Channel: "VOICE"
          }
        }
      ]
    });
    await connectClient.send(command);
  }
  logMessage("Success", "success");
}

// Function to log messages with different log levels
function logMessage(message, level, params) {
  const levels = {
    error: "\x1b[31m[ERROR]\x1b[0m",
    success: "\x1b[32m[SUCCESS]\x1b[0m",
    info: "\x1b[34m[INFO]\x1b[0m"
  };

  let logLevel = levels[level] || levels.info;
  let logMsg = message;
  // Replace placeholders in the log message
  if (params) {
    for (const key in params) {
      if (Object.prototype.hasOwnProperty.call(params, key)) {
        const value = params[key];
        logMsg = logMsg.replace(`{${key}}`, value);
      }
    }
  }

  console.log(`${logLevel} ${logMsg}`);
}

// Run the script
main().catch((error) => {
  logMessage("An error occurred:", "error", error);
  console.log(error);
});
