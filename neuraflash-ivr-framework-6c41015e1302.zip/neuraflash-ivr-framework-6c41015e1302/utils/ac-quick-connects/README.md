# AWS Quick Connects by Type

This directory contains a node.js script for creating Quick Connects in Amazon Connect.

[Confluence](https://neuraflash.atlassian.net/wiki/spaces/ACP/pages/2594603009)

## Prerequisites

- AWS CLI (version: `aws --version`) | install: (`brew install awscli`)
- AWS CLI Profile configured (`aws configure list`)
- node.js (version: `node -v` | install: `brew install node`)
- node package manager (version: `npm -v` | install: `brew install npm`)

## How to use the script

Update the agents, external, and/or queues folders .csv's with the appropriate details.
Install module dependencies within the directory `cd ac-quick-connects`, `npm i`
Update the configurations for Region and Instance Id, then execute the script with the appropriate type for the Quick Connects to be created.

## CSV File Formats

### Agents CSV

The `agents/agents.csv` file should have the following columns:

- **Username**: The username or email of the agent.
- **ContactFlowName**: The name of the contact flow to associate with the quick connect.
- **QCName**: The name of the quick connect.

Example:

| Username                              | ContactFlowName | QCName    |
|---------------------------------------|-----------------|-----------|
| ntest@005O10000056wxo@00D6t000000nsC5 | _Agent_Transfer | NF Tester |

### External CSV

The `external/external.csv` file should have the following columns:

- **QCName**: The name of the quick connect.
- **ExternalNumber**: The external phone number in international format (e.g., +1xxxxxxxxxx).
- **External Phone Number**: The external phone number in local format (e.g., xxx-xxx-xxxx).

Example:

| QCName                    | ExternalNumber | External Phone Number |
|---------------------------|----------------|-----------------------|
| Language line/Interpreter | +18888743972   | +1(888)-874-3972      |

### Queues CSV

The `queues/queues.csv` file should have the following columns:

- **Queues**: The queue identifier or name.
- **Comment**: Optional comment for the queue.
- **Requires Quick Connect to Queue?**: Yes/No flag indicating if a quick connect is required.
- **QueueName**: The name of the queue.
- **ContactFlowName**: The name of the contact flow associated with the queue.

Example:

| Queues       | Comment | Requires Quick Connect to Queue? | QueueName    | ContactFlowName |
|--------------|---------|----------------------------------|--------------|-----------------|
| ExampleQueue |         | Yes                              | ExampleQueue | _Queue_Transfer |

### Executing the script:

Before running the script:

1. Open a terminal and navigate to the directory where the script is saved.
2. Execute `npm i` to install necessary modules
3. Udpate any parameters of the script such as Region & Instance Id.
4. Update the relevant folder .csv's (agent | external | queue)
5. Execute using the below

To use the script, run the following command with the specified qcType and [optionally] AWS CLI profile:

```shell
node ac-quick-connects.js --qcType [agent | external | queue] --region [us-east-1 | us-west-2 | ...] --instanceId [000181ba-d526-400f-8002-4ec3ec91e00f] [--profile [profile]] [--agentCsvFile ["path/to/file.csv"]] [--queueCsvFile ["path/to/file.csv"]] [--externalCsvFile ["path/to/file.csv"]]
```

node ac-quick-connects.js --qcType agent --region eu-central-1 --instanceId 55476061-6e6d-41f4-b05b-f7263eaf598d

```shell
node ac-associate-qc.js [--region [us-east-1 | us-west-2 | ...]] [--instanceId [000181ba-d526-400f-8002-4ec3ec91e00f]] [--profile [profile]] [--queueName ["test"]] [--queueDescription ["test"]] [--qcCsv ["test/file/path.csv"]] [--rpPrefix ["test"]]
```

### Example:

```shell
node ac-associate-qc.js --region eu-central-1 --instanceId 55476061-6e6d-41f4-b05b-f7263eaf598d --queueCsvFile queue.csv
```

```shell
node ac-quick-connects.js --qcType queue --region eu-central-1 --instanceId 55476061-6e6d-41f4-b05b-f7263eaf598d
```
