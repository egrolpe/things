// Run this script to create quick connects for agents, external connections, or queues
// Run npm i to install required modules
// Run 'node ac-quick-connects.js --qcType [agent | external | queue] --stage [stage] --region [region] [--profile [profile]]' to create quick connects
// Run 'node ac-quick-connects.js --help' to see the options for running the script
// Run 'node ac-quick-connects.js --qcType agent --stage dev --region us-east-1 --profile exampleProfile' to create agent quick connects using the adminuser profile

// import required modules
const { fromIni } = require("@aws-sdk/credential-provider-ini");
const {
  ConnectClient,
  ListUsersCommand,
  ListQueuesCommand,
  CreateQuickConnectCommand,
  ListContactFlowsCommand,
  UpdateQuickConnectConfigCommand,
  ListQuickConnectsCommand
} = require("@aws-sdk/client-connect");
const csv = require("csv-parser");
const fs = require("fs");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

// parse command line arguments using yargs
const argv = require("yargs/yargs")(process.argv.slice(2))
  .usage("Usage: $0 --qcType [type] --stage [stage] --region [region] [--profile [profile]]")
  .demandOption(["qcType", "stage", "region"]) // qcType, stage, region arguments required
  .describe("qcType", "Specify the type to create (agent | external | queue)")
  .choices("qcType", ["agent", "external", "queue"]) // qcType must be one of these
  .describe("region", "Specify the region to create quick connects")
  .describe("stage", "Specify stage to target the deployment to")
  .describe(
    "instanceId",
    "Specify the connect instance Arn to create quick connects"
  )
  .describe("profile", "Optionally specify AWS profile").argv;

// set AWS SDK configuration
const region = argv.region;
const stage = argv.stage;
let config = { region, maxAttempts: 15 };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}
// Set the CSV file path based on qcType
const csvFile = `./${argv.qcType}/${argv.qcType}.csv`;
const instanceId = argv.instanceId || getConnectInstanceId(stage, region)

// Create the ConnectClient using the config
const connect = new ConnectClient(config);

// cache for AgentId and QueueId lookups
let objCache = {};

let error = "";

// Function to create quick connects for agents
async function createAgentQuickConnects() {
  try {
    // Read and process the CSV file for agents
    const agents = await readCsvFile(csvFile);

    // Create quick connects for each agent
    for (const agent of agents) {
      const { Username, ContactFlowName, QCName } = agent;

      if (!Username) {
        console.error();
        logMessage(`Invalid agent entry: ${agent}`, "error", error);
        continue;
      }

      // Look up the AgentId by username
      const agentId = await getAgentIdByUsername(Username);
      if (!agentId) {
        logMessage(`Agent not found for username: ${Username}`, "error", error);
      }

      const ContactFlowId = (await getContactFlow(ContactFlowName))?.Id;

      // Create the agent quick connect using AWS SDK
      const params = {
        InstanceId: instanceId,
        Name: `${QCName}`,
        QuickConnectConfig: {
          QuickConnectType: "USER",
          UserConfig: {
            UserId: agentId,
            ContactFlowId: ContactFlowId
          }
        },
        Description: `Agent Quick Connect - ${QCName}`
      };

      // Call the AWS SDK to create the agent quick connect with retry logic
      const dupe = await createQuickConnectWithRetry(params);
      if (!dupe) {
        logMessage(`Created agent quick connect, Name: ${QCName}`, "success");
      } else {
        logMessage(
          `Skipping creation of quick connect due to DuplicateResourceException: ${QCName}`,
          "warning"
        );
      }
    }
    logMessage(`Agent quick connects created successfully!`, "success");
  } catch (error) {
    logMessage("Failed to create agent quick connects:", "error", error);
  }
}

// Helper function to get AgentId by username
async function getAgentIdByUsername(username) {
  try {
    if (Object.keys(objCache).length === 0) {
      const users = [];
      let nextToken = null;

      do {
        const command = new ListUsersCommand({
          InstanceId: instanceId,
          NextToken: nextToken
        });
        const { UserSummaryList, NextToken } = await connect.send(command);

        users.push(...UserSummaryList);
        nextToken = NextToken;
      } while (nextToken);

      for (const user of users) {
        objCache[user.Username.split("@")[0].toLowerCase()] = user.Id;
      }
    }

    const agentId = objCache[username.split("@")[0].toLowerCase()];
    if (agentId) {
      return agentId;
    }

    logMessage(`Agent not found: ${username}`, "warning");
    return null;
  } catch (error) {
    logMessage("Error executing ListUsersCommand:", "error", error);
    throw error;
  }
}

const connectContactFlowData = {};
async function getContactFlow(contactFlowName) {
  if (Object.keys(connectContactFlowData).length > 0) {
    return connectContactFlowData[contactFlowName];
  }

  let nextToken = null;
  do {
    const command = new ListContactFlowsCommand({
      InstanceId: instanceId,
      NextToken: nextToken
    });
    const response = await connect.send(command);
    nextToken = response.NextToken;
    response.ContactFlowSummaryList.forEach((element) => {
      connectContactFlowData[element.Name] = element;
    });
  } while (nextToken);

  return connectContactFlowData[contactFlowName];
}

// Function to create quick connects for queues
async function createQueueQuickConnects() {
  try {
    // Read and process the CSV file for queues
    const queues = await readCsvFile(csvFile);

    // Create quick connects for each queue
    for (const queue of queues) {
      const { QCName, QueueName, ContactFlowName } = queue;

      const contactFlowId = (await getContactFlow(ContactFlowName))?.Id;
      if (QueueName && contactFlowId) {
        // Get the QueueId by QueueName
        const queueId = await getQueueIdByQueueName(QueueName);
        if (!queueId) {
          logMessage(`Queue not found for QueueName: ${QueueName}`, "error");
          continue;
        }

        // Create the queue quick connect using AWS SDK
        const params = {
          InstanceId: instanceId,
          Name: QCName,
          QuickConnectConfig: {
            QuickConnectType: "QUEUE",
            QueueConfig: {
              ContactFlowId: contactFlowId,
              QueueId: queueId
            }
          },
          Description: `Queue Quick Connect - ${QueueName}`
        };

        // Call the AWS SDK to create the queue quick connect with retry logic
        const dupe = await createQuickConnectWithRetry(params);
        if (!dupe) {
          console.log(
            `✅ Created queue quick connect, Name: ${QCName}`,
          );
        } else {
          logMessage(
            `Skipping creation of quick connect due to DuplicateResourceException: ${QueueName}`,
            "warning"
          );
        }
      } else {
        logMessage(
          `Skipping creation of quick connect "${QueueName}" due to missing data`,
          "warning"
        );
      }
    }

    logMessage(`Queue quick connects created successfully!`, "success");
  } catch (error) {
    logMessage("Failed to create queue quick connects:", "error", error);
  }
}

// Helper function to get QueueId by QueueName
async function getQueueIdByQueueName(queueName) {
  try {
    if (Object.keys(objCache).length === 0) {
      const queues = [];
      let nextToken = null;

      do {
        const command = new ListQueuesCommand({
          InstanceId: instanceId,
          QueueTypes: ["STANDARD"],
          NextToken: nextToken
        });
        const { QueueSummaryList, NextToken } = await connect.send(command);

        queues.push(...QueueSummaryList);
        nextToken = NextToken;
      } while (nextToken);

      // Process the list of queues
      for (const queue of queues) {
        objCache[`${queue.Name.toLowerCase()}`] = queue.Id;
      }
    }

    const queueId = objCache[queueName.trim().toLowerCase()];
    if (queueId) {
      return queueId;
    }

    logMessage(`Queue not found: ${queueName}`, "warning");
    return null;
  } catch (error) {
    logMessage("Error executing ListQueuesCommand:", "error", error);
    throw error;
  }
}

// Function to create quick connects for external connections
async function createExternalQuickConnects() {
  try {
    // Read and process the CSV file for external connections
    const externalConnections = await readCsvFile(csvFile);

    // Create quick connects for each external connection
    for (const connection of externalConnections) {
      const { QCName, ExternalNumber } = connection;

      // Create the external connection quick connect using AWS SDK
      const params = {
        InstanceId: instanceId,
        Name: QCName,
        QuickConnectConfig: {
          QuickConnectType: "PHONE_NUMBER",
          PhoneConfig: {
            PhoneNumber: ExternalNumber
          }
        },
        Description: `External Quick Connect - ${QCName}`
      };

      // Call the AWS SDK to create the queue quick connect with retry logic
      const dupe = await createQuickConnectWithRetry(params);
      if (!dupe) {
        logMessage(`Created queue quick connect, Name: ${QCName}`, "success");
      } else {
        logMessage(
          `Skipping creation of quick connect due to DuplicateResourceException: ${QCName}`,
          "warning"
        );
      }
    }

    logMessage(
      `External connection quick connects created successfully!`,
      "success"
    );
  } catch (error) {
    logMessage(
      "Failed to create external connection quick connects:",
      "error",
      error
    );
  }
}

// Helper function to read and parse a CSV file
function readCsvFile(filePath) {
  return new Promise((resolve, reject) => {
    const results = [];
    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (data) => results.push(data))
      .on("end", () => resolve(results))
      .on("error", (error) => reject(error));
  });
}

// Function to create a quick connect using the AWS SDK with retry logic
async function createQuickConnectWithRetry(params, retries = 3, delay = 180) {
  for (let i = 0; i < retries; i++) {
    try {
      // Call the AWS SDK to create the quick connect
      await createQuickConnect(params);
      return;
    } catch (error) {
      if (error.name === "DuplicateResourceException") {
        await updateQuickConnect(params);
        const dupe = true;
        return dupe; // Move to the next iteration
      } else {
        console.error(
          `Failed to create quick connect. Retries left: ${retries - i - 1}`
        );
        console.log(error);
        logMessage("Error creating quick connect:", "error", error);
        if (i < retries - 1) {
          await sleep(delay);
          delay *= 2; // Double the delay for exponential backoff
        } else {
          throw error; // Throw the caught error after reaching maximum retries
        }
      }
    }
  }
  throw new Error("Failed to create quick connect after maximum retries.");
}

// Function to create a quick connect using the AWS SDK
async function createQuickConnect(params) {
  const command = new CreateQuickConnectCommand(params);
  return connect.send(command);
}

async function updateQuickConnect(params) {
  const quickConnectId = await getQuickConnectIdByName(params.InstanceId, params.Name);

    if (!quickConnectId) {
      throw new Error(`Quick Connect '${params.Name}' not found. Cannot update.`);
    }
  try {
    const updateParams = {
      InstanceId: params.InstanceId,
      QuickConnectId: await getQuickConnectIdByName(params.InstanceId, params.Name),
      Name: params.Name,
      Description: params.Description,
      QuickConnectConfig: params.QuickConnectConfig
    };
    
    const command = new UpdateQuickConnectConfigCommand(updateParams);
    await connect.send(command);
    console.log(
      `✅ Updated quick connect: ${params.Name}`,
    );
  } catch (error) {
    console.log(
      `❌ Failed to update quick connect: ${params.Name}`,
      error
    );
    throw error;
  }
}

async function getQuickConnectIdByName(instanceId, quickConnectName) {
  try {
    let nextToken = null;
    do {
      const command = new ListQuickConnectsCommand({
        InstanceId: instanceId,
        NextToken: nextToken
      });
      const response = await connect.send(command);
      const quickConnect = response.QuickConnectSummaryList.find(
        (qc) => qc.Name === quickConnectName
      );
      if (quickConnect) {
        return quickConnect.Id;
      }
      nextToken = response.NextToken;
    } while (nextToken);

    logMessage(`Quick connect not found: ${quickConnectName}`, "warning");
    throw new Error("Quick connect not found.");
  } catch (error) {
    logMessage("Error listing quick connects:", "error", error);
    throw error;
  }
}

// Helper function to sleep for a specified duration
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Main script logic
async function main() {
  const qcType = argv.qcType.toLowerCase();

  switch (qcType) {
    case "agent":
      await createAgentQuickConnects();
      break;
    case "external":
      await createExternalQuickConnects();
      break;
    case "queue":
      await createQueueQuickConnects();
      break;
    default:
      logMessage(
        `Invalid --qcType: ${qcType}. Supported types are agent, external, and queue.`,
        "error"
      );
  }
}

// Function to log messages with different log levels
function logMessage(message, level, params) {
  const levels = {
    error: "\x1b[31m[ERROR]\x1b[0m",
    success: "\x1b[32m[SUCCESS]\x1b[0m",
    info: "\x1b[34m[INFO]\x1b[0m"
  };

  let logLevel = levels[level] || levels.info;
  let logMsg = message;

  // Replace placeholders in the log message
  if (params) {
    for (const key in params) {
      if (Object.prototype.hasOwnProperty.call(params, key)) {
        const value = params[key];
        logMsg = logMsg.replace(`{${key}}`, value);
      }
    }
  }

  console.log(`${logLevel} ${logMsg}`);
}

// Run the script
main().catch((error) => {
  logMessage("An error occurred:", "error", error);
});
