const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { fromIni } = require("@aws-sdk/credential-providers");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

const {
  ConnectClient,
  UpdateInstanceAttributeCommand
} = require("@aws-sdk/client-connect");

// Parse command line arguments using yargs
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId] --profile [profile] ]"
  )
  .demandOption(["region", "stage"]) // arguments required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("instanceId", "Specify Amazon Connect instance ID") // description for the instanceId argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);
let config = { region: argv.region };
if (argv.profile) {
  config = {
    ...config,
    credentials: fromIni({ profile: argv.profile })
  };
}
const client = new ConnectClient(config);

// Function to Enable Multi Party Call And Enhanced Monitoring
async function enableMultiPartyCallAndEnhancedMonitoring() {
  try {
    try {
      const input = {
        InstanceId: instanceId,
        AttributeType: "MULTI_PARTY_CONFERENCE",
        Value: "true"
      };
      const command = new UpdateInstanceAttributeCommand(input);
      const response = await client.send(command);
      console.log(response);
      if (response["$metadata"]["httpStatusCode"] == 200) {
        console.log(
          "✅ Enabled Multi Party Call And Enhanced Monitoring Successfully"
        );
      } else {
        console.log(
          "❌ Failed to Enable Multi Party Call And Enhanced Monitoring"
        );
      }
    } catch (err) {
      console.log(
        "❌ Failed to Enable Multi Party Call And Enhanced Monitoring"
      );
      console.log(err);
    }
  } catch (error) {
    console.error(
      "Error enabling Multi Party Call And Enhanced Monitoring",
      error
    );
  }
}

enableMultiPartyCallAndEnhancedMonitoring();
