# Enable Multi Party Call And Enhanced Monitoring

This directory contains a node.js script. This script takes the amazon connect Instance ID or the Stage name and the amazon region and enables Multi Party Call And Enhanced Monitoring.

## Prerequisites

- node.js (version: `node -v` | install: `brew install node`)
- node package manager (version: `npm -v` | install: `brew install npm`)

## How to use the scripts

Before running the script:

1. Open a terminal and navigate to the directory where the script is saved.
2. Execute `npm i` to install necessary modules

To use the script, run one of the following command:

`node enable-multi-party-calls.js --region <region> --instanceId <instanceId> --profile <profile>`

`node enable-multi-party-calls.js --region <region> --stage <stage> --profile <profile>`

If the instanceId isn't provided, we'll use the instance ID for the specified stage from the config files in the config directory.

Profile name is optional

example -

`node enable-multi-party-calls.js --region us-west-2 --instanceId <instanceId> --profile dev`

`node enable-multi-party-calls.js --region us-west-2 --stage dev --profile dev`

