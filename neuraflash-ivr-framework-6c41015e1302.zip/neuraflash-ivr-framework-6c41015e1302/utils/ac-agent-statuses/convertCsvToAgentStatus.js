const fs = require('fs');
const { parse } = require("csv-parse");
const yargs = require("yargs/yargs");

/**
 * CSV to JSON Converter
 * 
 * This script reads a CSV file containing Agent Status configurations and converts 
 * it into a structured JSON format. It allows the user to specify the input 
 * CSV file and the output JSON file through command-line arguments.
 *
 * The CSV file should have the following structure:
 * - Name
 * - Description
 * - State
 * - DisplayOrder
 *
 * The resulting JSON structure will include the following fields:
 * - Name: The name of the Agent Status
 * - Description: A description of the Agent Status
 * - State: ENABLED|DISABLED
 * - DisplayOrder: number, order displayed in status menu
 *
 * Usage:
 *   node convertCsvToAgentStatus.js --sourceFile path/to/input.csv --destinationFile path/to/output.json
 *
 * Command-line Arguments:
 * - --sourceFile: The path to the input CSV file (required).
 * - --destinationFile: The path to the output JSON file (required).
 *
 * Dependencies:
 * - fs: Node.js file system module for reading and writing files.
 * - csv-parse: A package to parse CSV files.
 * - yargs: A package to handle command-line arguments.
 *
 * Example:
 *   node convertCsvToAgentStatus.js --sourceFile data/input/AgentStatuses.csv --destinationFile data/output/agentstatuses.json
 * 
 * Author: Dan Dominguez, Henry Pizzo
 * Date: Sept 3, 2025
 */

// Get input and output file paths from command-line arguments
const argv = yargs(process.argv.slice(2))
    .usage("Usage: $0 --sourceFile [name] --destinationFile [name]")
    .demandOption(["sourceFile", "destinationFile"])
    .describe("sourceFile", "Specify CSV file to convert to JSON") 
    .describe("destinationFile", "Specify a destination to write to")
    .argv; 

const inputFilePath = argv.sourceFile;
const outputFilePath = argv.destinationFile;

const agentStatuses = {};

// Function to map CSV data to desired JSON structure
const mapToJsonFormat = (row) => {
    const agentStatus = {};

    for (const [key, value] of Object.entries(row)) {
        // ignore empty cells
        if (value.trim() !== '') {
            agentStatus[key] = value;
        }
    }
    return agentStatus;
};

// Read and process the CSV file
fs.createReadStream(inputFilePath)
    .pipe(parse({ columns: header => header.map(col => col.replace(/\s+/g, '')) }))
    .on('data', (row) => {
        const agentStatus = mapToJsonFormat(row);
        agentStatuses[agentStatus.Name] = agentStatus
    })
    .on('end', () => {
        // Write the mapped data to a JSON file
        fs.writeFileSync(outputFilePath, JSON.stringify(agentStatuses, null, 2), 'utf8');
        console.log('CSV data has been successfully mapped and written to JSON file.');
    })
    .on('error', (error) => {
        console.error('Error reading the CSV file:', error);
    });
