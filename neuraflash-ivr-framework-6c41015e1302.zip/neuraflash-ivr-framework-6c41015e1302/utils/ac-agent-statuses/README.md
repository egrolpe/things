# Amazon Connect Agent Status Manager

This module helps manage agent statuses in Amazon Connect by creating or updating them based on a configuration file. It utilizes the AWS SDK for JavaScript and requires an AWS account with appropriate permissions.

## Features

- Create new agent statuses in Amazon Connect.
- Update existing agent statuses with new configurations.
- Manage agent status states (ENABLED/DISABLED).
- Handles command-line argument parsing for flexible execution.

## Installation

To use this module, ensure you have Node.js installed. Then, install the required packages:

```bash
npm install
```

## Usage

### Full Workflow (Recommended)

To run the complete workflow of caching existing agent statuses, converting CSV to JSON, and deploying agent statuses, use the full workflow script:

```bash
node full-agent-status-workflow.js --region <region> --stage <stage>
```

Or with explicit instance ID and/or profile:

```bash
node full-agent-status-workflow.js --region <region> --stage <stage> --instanceId <instanceId> --profile <profile>
```

This script will:
1. Cache existing agent statuses from Amazon Connect
2. Convert your CSV file to JSON format
3. Deploy the agent statuses to Amazon Connect

### Individual Scripts

#### Step 1: Set Up AWS Credentials

Ensure your AWS credentials are configured. You can use the AWS CLI to set up profiles or place your credentials in the `~/.aws/credentials` file.

#### Step 2: Cache Existing Agent Statuses

First, cache the existing agent statuses:

```bash
node cache-agent-statuses.js --region us-west-2 --stage dev --profile dev
```

Or with explicit instance ID:

```bash
node cache-agent-statuses.js --region us-west-2 --instanceId YOUR_INSTANCE_ID --stage dev --profile dev
```

#### Step 3: Prepare Agent Status Configuration

Create a JSON file named `agentstatuses.json` in a `data` directory. The structure should look like this:
This can be achieved by using the `convertCsvToAgentStatus.js` script with the following command

```bash
node convertCsvToAgentStatus.js --sourceFile ./data/input/AgentStatuses.csv --destinationFile ./data/output/agentstatuses.json
```

### CSV Structure

The input CSV file should have the following columns:

- `Name`: The name of the agent status
- `Description`: A description of the agent status
- `State`: ENABLED or DISABLED
- `DisplayOrder`: The order displayed in the status menu (number)

### Example CSV

You can find an example CSV at `./data/input/AgentStatuses.csv`:

| Name          | Description                      | State    | DisplayOrder |
|---------------|----------------------------------|----------|--------------|
| Available     | Available state                  | ENABLED  | 1            |
| Offline       | Offline state                    | ENABLED  | 2            |

The resulting JSON structure will be:

```json
{
    "Available": {
        "Name": "Available",
        "Description": "Available state",
        "State": "ENABLED",
        "DisplayOrder": "1"
    },
    "Offline": {
        "Name": "Offline",
        "Description": "Offline state",
        "State": "ENABLED",
        "DisplayOrder": "2"
    }
}
```

#### Step 4: Deploy Agent Statuses

Use the command line to execute the deploy script. You must provide at least the AWS region and source file, and optionally, the instance ID, stage, and profile.

```bash
node deploy-agent-stauses.js --region us-west-2 --sourceFile ./data/agentstatuses.json --stage dev --profile dev
```

Or with explicit instance ID:

```bash
node deploy-agent-stauses.js --region us-west-2 --sourceFile ./data/agentstatuses.json --instanceId YOUR_INSTANCE_ID --stage dev --profile dev
```

### Command-Line Arguments

- `--region`: Required. Specify the AWS region (e.g., `us-west-2`).
- `--instanceId`: Optional. Specify the Amazon Connect instance ID. If not provided, will be fetched from config using the stage.
- `--stage`: Required. Specify the deployment stage (used to fetch instance ID from a config file when instanceId is not provided).
- `--profile`: Optional. Specify the AWS profile to use.

### Example Output

When you run the script, it will log the operations performed, such as creating or updating agent statuses:

```
✅ created agent status Available
✅ updated agent status Offline
```

## Error Handling

If there are issues with the provided configuration, such as invalid state values, the script will log an error message:

```
❌ Failed to update agent status InvalidStatus because state INVALID is not valid.
```

## Dependencies

- `@aws-sdk/client-connect`: AWS SDK for interacting with Amazon Connect.
- `lodash`: Utility library for JavaScript.
- `yargs`: Command-line argument parser.
- `csv-parse`: Package to parse CSV files.
