const {
  ConnectClient,
  CreateAgentStatusCommand,
  UpdateAgentStatusCommand,
  ListAgentStatusesCommand
} = require("@aws-sdk/client-connect");
const { fromIni } = require("@aws-sdk/credential-provider-ini");
const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] --sourceFile [sourceFile] [--instanceId [instanceId] --profile [profile]]"
  )
  .demandOption(["region", "stage", "sourceFile"])
  .describe("region", "Specify AWS region")
  .describe("instanceId", "Specify Amazon Connect instance Id")
  .describe("sourceFile", "JSON file to deploy from")
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv;

let config = { region: argv.region };
const sourceFile = argv.sourceFile;
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);

if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) };
}

const client = new ConnectClient(config);
const getExistingAgentStatuses = async () => {
  const command = new ListAgentStatusesCommand({
    InstanceId: instanceId
  });
  const response = await client.send(command);
  return response.AgentStatusSummaryList.reduce((acc, status) => {
    acc[status.Name] = status;
    return acc;
  }, {});
};

const deployAgentStatuses = async () => {
  try {
    const data = fs.readFileSync(sourceFile, "utf8");
    const agentStatuses = JSON.parse(data);

    // Get existing statuses from your system
    const existingStatuses = await getExistingAgentStatuses();

    for (const statusName of Object.keys(agentStatuses)) {
      const status = agentStatuses[statusName];

      const params = {
          InstanceId: instanceId,
          Name: status.Name,
          Description: status.Description,
          State: status.State,
          DisplayOrder: Number(status.DisplayOrder)
        };

      if (existingStatuses[statusName]) {

        // InvalidRequestException: State of agent status type routable or offline cannot be updated
        const type = existingStatuses[statusName].Type;
        if (type == "ROUTABLE" || type == "OFFLINE"){
          console.log(`ℹ️  Skipping "${statusName}": Statuses of Type ${type} cannot be updated`);
          continue;
        }
        // Prepare the update parameters, but skip the State field for ROUTABLE and OFFLINE types
        const updateParams = {
          ...params,
          AgentStatusId: existingStatuses[statusName],
        };
        console.log(updateParams)
        const updateCommand = new UpdateAgentStatusCommand(updateParams);
        await client.send(updateCommand);
        console.log(`✅ Agent Status "${statusName}" updated successfully`);
      } else {
        const createCommand = new CreateAgentStatusCommand(params);
        await client.send(createCommand);
        console.log(`✅ Agent Status "${statusName}" created successfully`);
      }
    }
  } catch (err) {
    console.error("❌ Error while processing agent statuses:", err);
  }
};

deployAgentStatuses();
