const {
  ConnectClient,
  SearchAgentStatusesCommand
} = require("@aws-sdk/client-connect");

const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const fs = require("fs");
const path = require("path");

const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId] --profile [profile]]"
  )
  .demandOption(["region", "stage"])
  .describe("region", "Specify AWS region")
  .describe("instanceId", "Specify Amazon Connect instance Id")
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv;

const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);

async function searchAgentStatuses(connectClient) {
  const agentStatuses = {};
  let nextToken = null;
  do {
    const command = new SearchAgentStatusesCommand({
      InstanceId: instanceId,
      NextToken: nextToken
    });
    const response = await connectClient.send(command);
    nextToken = response.NextToken;
    response.AgentStatuses.forEach((element) => {
      agentStatuses[element.Name] = element;
    });
  } while (nextToken);

  return agentStatuses;
}

// Function to download the file
const main = async () => {
  const connectClient = new ConnectClient({ region: argv.region });
  try {
    const agentStatuses = await searchAgentStatuses(connectClient);
    // Ensure 'data' directory exists
    const dataDir = path.join(__dirname, "data");
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir); // Create the directory if it doesn't exist
    }

    // Proceed with writing the agent statuses to a file
    fs.writeFileSync(
      path.join(dataDir, "agentstatuses.json"),
      JSON.stringify(agentStatuses, null, 2)
    );
    console.log("✅ Agent Status Download Complete");
  } catch (err) {
    console.error(`Failed to process: ${err.message}`);
  }
};

main();
