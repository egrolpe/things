const { execSync } = require('child_process');
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");

/**
 * Full Agent Status Workflow Script
 *
 * This script executes the complete agent status management workflow:
 * 1. Cache existing agent statuses from AWS Connect
 * 2. Convert agent status CSV to JSON format
 * 3. Deploy agent statuses to AWS Connect
 *
 * Usage:
 *   node full-agent-status-workflow.js --region <region> --stage <stage> [--instanceId <instanceId>]
 *
 * Simple Example (using defaults):
 *   node full-agent-status-workflow.js --region us-west-2 --stage dev
 *
 * Advanced Example (custom file paths):
 *   node full-agent-status-workflow.js --region <region> --stage <stage> --instanceId <instanceId> --sourceFile <csvFile> --destinationFile <jsonFile>
 *
 * Parameters:
 * - --region: AWS region (required)
 * - --stage: Deployment stage (required)
 * - --instanceId: Amazon Connect instance ID (optional - will use config if not provided)
 * - --sourceFile: Path to agent status input CSV file (default: data/input/AgentStatuses.csv)
 * - --destinationFile: Path to agent status output JSON file (default: data/output/agentstatuses.json)
 * - --profile: AWS profile (optional)
 *
 * Author: Henry Pizzo
 * Date: Sept 5, 2025
 */

const argv = yargs(hideBin(process.argv))
  .usage("Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId] --sourceFile [sourceFile]] [--destinationFile [destinationFile]]")
  .demandOption(["region", "stage"])
  .describe("region", "Specify AWS region")
  .describe("instanceId", "Specify Amazon Connect instance Id (optional - will use config if not provided)")
  .describe("stage", "Specify stage to target the deployment to")
  .describe("sourceFile", "Specify agent status CSV file to convert to JSON (default: data/input/AgentStatuses.csv)")
  .describe("destinationFile", "Specify destination to write agent status output (default: data/output/agentstatuses.json)")
  .describe("profile", "Optionally specify AWS profile")
  .default("sourceFile", "data/input/AgentStatuses.csv")
  .default("destinationFile", "data/output/agentstatuses.json")
  .argv;

const main = async () => {
  try {
    console.log("🚀 Starting Full Agent Status Workflow...\n");

    // Step 1: Cache existing agent statuses from AWS Connect
    console.log("📥 Step 1: Caching existing agent statuses from AWS Connect...");
    const cacheCommand = `node cache-agent-statuses.js --region ${argv.region} --stage ${argv.stage}${argv.instanceId ? ` --instanceId ${argv.instanceId}` : ''}${argv.profile ? ` --profile ${argv.profile}` : ''}`;
    execSync(cacheCommand, { stdio: 'inherit', cwd: __dirname });
    console.log("✅ Agent statuses cached successfully!\n");

    // Step 2: Convert agent status CSV to JSON
    console.log("🔄 Step 2: Converting agent status CSV to JSON format...");
    const convertCommand = `node convertCsvToAgentStatus.js --sourceFile ${argv.sourceFile} --destinationFile ${argv.destinationFile}`;
    execSync(convertCommand, { stdio: 'inherit', cwd: __dirname });
    console.log("✅ Agent status CSV converted to JSON successfully!\n");

    // Step 3: Deploy agent statuses to AWS Connect
    console.log("🚀 Step 3: Deploying agent statuses to AWS Connect...");
    const deployCommand = `node deploy-agent-stauses.js --sourceFile ${argv.destinationFile} --stage ${argv.stage} --region ${argv.region}${argv.instanceId ? ` --instanceId ${argv.instanceId}` : ''}${argv.profile ? ` --profile ${argv.profile}` : ''}`;
    execSync(deployCommand, { stdio: 'inherit', cwd: __dirname });
    console.log("✅ Agent statuses deployed successfully!\n");

    console.log("🎉 Full Agent Status Workflow completed successfully!");

  } catch (error) {
    console.error("❌ Error in workflow execution:", error.message);
    process.exit(1);
  }
};

main();
