// import { LexModelsV2Client, UntagResourceCommand } from "@aws-sdk/client-lex-models-v2"; // ES Modules import
const {
  LexModelsV2Client,
  UntagResourceCommand
} = require("@aws-sdk/client-lex-models-v2"); // CommonJS import

// parse command line arguments using yargs
const argv = require("yargs/yargs")(process.argv.slice(2))
  .usage("Usage: $0 --region [region] --lexArn [lexArn] --profile [profile]")
  .demandOption(["region", "lexArn"])
  .describe("region", "specify AWS region")
  .describe("lexArn", "specify lex arn")
  .describe("profile", "optionally specify AWS profile").argv;

let region = argv.region;
let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

// Function to remove tags from an AWS resource
async function removeLexBotTags() {
  try {
    const client = new LexModelsV2Client(config);

    const input = {
      // UntagResourceRequest
      resourceARN: argv.lexArn, // required
      tagKeys: [
        "AlternateContactEmail",
        "ApplicationID",
        "ITSMServiceName",
        "ProductOwnerEmail",
        "DataClassification",
        "OwnerGroup",
        "RechargeDepartment",
        "RegulatedSystem",
        "ApplicationName"
      ]
    };
    const command = new UntagResourceCommand(input);
    const response = await client.send(command);

    if (response.$metadata.httpStatusCode === 200) {
      console.log("✅ Tags removed successfully.", response);
    } else {
      console.log("❌ Failed to remove tags", response);
    }
  } catch (error) {
    console.log("❌ Error removing tags:", error);
  }
}

removeLexBotTags();
