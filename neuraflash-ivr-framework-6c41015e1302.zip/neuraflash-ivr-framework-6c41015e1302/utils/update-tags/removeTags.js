const {
  ResourceGroupsTaggingAPIClient,
  UntagResourcesCommand
} = require("@aws-sdk/client-resource-groups-tagging-api");
const fsPromises = require("fs").promises;

// parse command line arguments using yargs
const argv = require("yargs/yargs")(process.argv.slice(2))
  .usage("Usage: $0 --region [region] [--profile [profile]]")
  .demandOption(["region"])
  .describe("region", " specify AWS region")
  .describe("sourceFile", "optionally override the source filename")
  .describe("profile", "optionally specify AWS profile").argv;

let region = argv.region;
let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

// Set the path to the input JSON file
let removeTagsInputFilePath = `removeTagsInput.json`;
// Set the path to the input JSON file
if (argv.sourceFile) {
  removeTagsInputFilePath = argv.sourceFile;
}
// Function to remove tags from an AWS resource
async function removeTags() {
  let input = JSON.parse(await fsPromises.readFile(removeTagsInputFilePath));
  const client = new ResourceGroupsTaggingAPIClient(config);

  const command = new UntagResourcesCommand({
    ResourceARNList: input.ResourceARNList,
    TagKeys: input.TagNamesList
  });

  try {
    const response = await client.send(command);

    if (response.$metadata.httpStatusCode === 200) {
      console.log("✅ Tags removed successfully.", response);
    } else {
      console.log("❌ Failed to remove tags", response);
    }
  } catch (error) {
    console.log("❌ Error removing tags:", error);
  }
}

removeTags();
