const {
  ResourceGroupsTaggingAPIClient,
  TagResourcesCommand,
} = require("@aws-sdk/client-resource-groups-tagging-api");

const { fromIni } = require("@aws-sdk/credential-providers");
const fsPromises = require("fs").promises;

// parse command line arguments using yargs
const argv = require("yargs/yargs")(process.argv.slice(2))
  .usage("Usage: $0 --region [region] [--profile [profile]]")
  .demandOption(["region"])
  .describe("region", "specify AWS region")
  .describe("sourceFile", "optionally override the source filename")
  .describe("profile", "optionally specify AWS profile").argv;

let region = argv.region;
let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

// Set the path to the input JSON file
let addTagsInputFilePath = `addTagsInput.json`;
if (argv.sourceFile) {
  addTagsInputFilePath = argv.sourceFile;
}

// Function to add or update tags for an AWS resource
async function addOrUpdateTags() {
  let input = JSON.parse(await fsPromises.readFile(addTagsInputFilePath));
  const client = new ResourceGroupsTaggingAPIClient(config);
  const command = new TagResourcesCommand({
    ResourceARNList: input.ResourceARNList,
    Tags: input.Tags,
  });

  try {
    const response = await client.send(command);
    if (response.$metadata.httpStatusCode === 200) {
      console.log("✅ Tags added or updated successfully.", response);
    } else {
      console.log("❌ Failed to add or update tags.", response);
    }
  } catch (error) {
    console.log("❌ Error adding or updating tags:", error);
  }
}

addOrUpdateTags();
