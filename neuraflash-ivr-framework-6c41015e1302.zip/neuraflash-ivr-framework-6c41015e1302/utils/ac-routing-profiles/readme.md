node script.js --sourceFile input.csv --destinationFile output.json
# CSV to JSON Routing Profile Converter
### Author:
Daniel Dominguez

### Date: 
Nov 12, 2024

## About
This script processes a CSV file containing routing profile data and converts it to a JSON format. It reads a CSV file, extracts the necessary fields, and maps them to a predefined JSON structure to be saved into a destination file.

## Usage

```bash
node script.js --sourceFile <input_csv_file_path> --destinationFile <output_json_file_path>
```
## Options:
- --sourceFile <input_csv_file_path>: The path to the CSV file to process (required).
- --destinationFile <output_json_file_path>: The path to the JSON file to write (required).

## Functions
createHeaderMap(inputFilePath)
Creates a mapping of header names to their respective column indices in the CSV.

createQueueReferences(row)
Creates a list of queue objects for each queue defined in a row, extracting the queue name, priority, and delay based on the headers in the CSV.

mapToRoutingProfile(row)
Maps a CSV row to a routing profile object, including media concurrency, outbound queue, and other routing profile-specific fields. It also uses createQueueReferences() to extract queue data.

## Example CSV Structure
The CSV data is expected to start at line 2 with headers, and data starts from line 5 onwards. The CSV will be processed, and a JSON file will be created with an array of routing profile objects.
```csv
| Routing Profile Name | Description | Default Outbound Queue | Quick Connects Queue | Queue 1 Name | Queue 1 Priority | Queue 1 Delay | ... |
|----------------------|-------------|------------------------|----------------------|--------------|------------------|---------------|-----|
| Profile 1            | Desc 1      |                        |                      | QueueA       | 1                | 30            | ... |
| Profile 2            | Desc 2      |                        |                      | QueueB       | 2                | 60            | ... |
```

## Example Output JSON Structure
```json
{
  "Name": "Profile 1",
  "Description": "Description of Profile 1",
  "MediaConcurrencies": [
    {
      "Channel": "VOICE",
      "Concurrency": 1,
      "CrossChannelBehavior": {
        "BehaviorType": "ROUTE_CURRENT_CHANNEL_ONLY"
      }
    }
  ],
  "Queues": [
    {
      "QueueName": "QueueA",
      "Priority": 1,
      "Delay": 30,
      "Channel": "VOICE"
    }
  ]
}
```

## Example Command
```bash
node script.js --sourceFile input.csv --destinationFile output.json
```

## Dependencies
- csv-parse: To parse the CSV data.
- yargs: To handle command-line arguments.
- fs: To read and write files.