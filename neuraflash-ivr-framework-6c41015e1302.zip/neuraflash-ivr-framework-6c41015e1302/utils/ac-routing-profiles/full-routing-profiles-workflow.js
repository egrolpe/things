const { spawn } = require('child_process');
const yargs = require('yargs/yargs');
const { hideBin } = require('yargs/helpers');
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

/**
 * Master script to manage Amazon Connect Routing Profiles workflow:
 * 1. Cache existing routing profiles from AWS
 * 2. Convert CSV to JSON format
 * 3. Deploy routing profiles to AWS
 *
 * Usage:
 *   node full-routing-profiles-workflow.js --region us-east-1 --stage dev --profile myprofile
 *
 * Required arguments:
 * - --region: AWS region
 * - --stage: Environment stage (dev, qa, prod)
 *
 * Optional arguments:
 * - --profile: AWS profile name
 * - --instanceId: Amazon Connect instance ID (if not using config file)
 * - --csvFile: Path to input CSV file (default: input/RoutingProfiles.csv)
 * - --jsonFile: Path to output JSON file (default: output/routingProfiles.json)
 */

const argv = yargs(hideBin(process.argv))
  .usage('Usage: $0 --region [region] --stage [stage] --profile [profile]')
  .demandOption(['region', 'stage'])
  .describe('region', 'AWS region')
  .describe('stage', 'Environment stage (dev, qa, prod)')
  .describe('profile', 'AWS profile name')
  .describe('instanceId', 'Amazon Connect instance ID')
  .describe('csvFile', 'Path to input CSV file')
  .describe('jsonFile', 'Path to output JSON file')
  .argv;

const region = argv.region;
const stage = argv.stage;
const profile = argv.profile;
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);
const csvFile = argv.csvFile || 'input/RoutingProfiles.csv';
const jsonFile = argv.jsonFile || 'output/routingProfiles.json';

// Helper function to run a command and return a promise
const runCommand = (command, args) => {
  return new Promise((resolve, reject) => {
    console.log(`\n🔄 Running: ${command} ${args.join(' ')}`);

    const child = spawn(command, args, {
      stdio: 'inherit',
      shell: true
    });

    child.on('close', (code) => {
      if (code === 0) {
        console.log(`✅ Command completed successfully`);
        resolve();
      } else {
        reject(new Error(`Command failed with exit code ${code}`));
      }
    });

    child.on('error', (error) => {
      reject(error);
    });
  });
};

// Main workflow function
const manageRoutingProfiles = async () => {
  try {
    console.log('🚀 Starting Routing Profiles Management Workflow\n');

    // Step 1: Cache existing routing profiles
    console.log('📥 Step 1: Caching existing routing profiles...');
    const cacheArgs = ['cache-routing-profiles.js', '--region', region, '--stage', stage];
    if (profile) cacheArgs.push('--profile', profile);
    if (instanceId) cacheArgs.push('--instanceId', instanceId);
    await runCommand('node', cacheArgs);

    // Step 2: Convert CSV to JSON
    console.log('🔄 Step 2: Converting CSV to JSON...');
    const convertArgs = ['convertCsvToRoutingProfile.js', '--sourceFile', csvFile, '--destinationFile', jsonFile];
    await runCommand('node', convertArgs);

    // Step 3: Deploy routing profiles
    console.log('🚀 Step 3: Deploying routing profiles to AWS...');
    const deployArgs = ['deploy-routing-profiles.js', '--region', region, '--stage', stage, '--sourceFile', jsonFile];
    if (profile) deployArgs.push('--profile', profile);
    if (instanceId) deployArgs.push('--instanceId', instanceId);
    await runCommand('node', deployArgs);

    console.log('\n🎉 Routing Profiles Management Workflow completed successfully!');

  } catch (error) {
    console.error('\n❌ Error in workflow:', error.message);
    process.exit(1);
  }
};

// Execute the workflow
manageRoutingProfiles();
