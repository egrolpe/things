const fs = require("fs");
const {
  ConnectClient,
} = require("@aws-sdk/client-connect");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { fromIni } = require("@aws-sdk/credential-providers");
const { getRoutingProfilesList } = require("./routing-profiles");
const { getQueuesById } = require("./queues");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));
// Parse command line arguments using yargs
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId] --profile [profile]]"
  )
  .demandOption(["region", "stage"]) // region and stage arguments required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("instanceId", "Specify Amazon Connect instance ID") // description for the instanceID argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

let config = { region: argv.region };
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);

if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}

const main = async () => {
  const connect = new ConnectClient(config);
  const routingProfiles = await getRoutingProfilesList(connect, instanceId);
  const queues = await getQueuesById(connect, instanceId);
  const result = [];
  // need to get name, description, mediaConcurrencies, queueConfigs
  for (const rp of routingProfiles) {
    const {
      Name,
      Description,
      MediaConcurrencies,
      Queues,
      AgentAvailabilityTimer,
      DefaultOutboundQueueId,
    } = rp;
    const DefaultOutboundQueueName = queues[DefaultOutboundQueueId]?.Name;

    const rpQueues = [];
    for (const q of Queues) {
      const { QueueName, Priority, Delay, Channel } = q;
      rpQueues.push({ QueueName, Priority, Delay, Channel });
    }
    result.push({
      Name,
      Description,
      MediaConcurrencies,
      AgentAvailabilityTimer,
      DefaultOutboundQueueName,
      Queues: rpQueues,
    });
  }
  fs.writeFileSync(
    "data/routing-profiles.json",
    JSON.stringify(result, null, 2),
    "utf8"
  );
};

main();
