const fs = require("fs");
const {
  paginateListRoutingProfiles,
  paginateListRoutingProfileQueues,
  DescribeRoutingProfileCommand
} = require("@aws-sdk/client-connect");

const getRoutingProfilesList = async (connect, instanceId) => {
  const paginator = paginateListRoutingProfiles(
    { client: connect },
    { InstanceId: instanceId }
  );
  const routingProfilesList = [];
  for await (const response of paginator) {
    // process each page of results
    routingProfilesList.push(...response.RoutingProfileSummaryList);
  }
  const routingProfiles = [];
  for await (const rp of routingProfilesList) {
    const resp = await connect.send(
      new DescribeRoutingProfileCommand({
        InstanceId: instanceId,
        RoutingProfileId: rp.Id
      })
    );
    const paginator = paginateListRoutingProfileQueues(
      { client: connect },
      { InstanceId: instanceId, RoutingProfileId: rp.Id }
    );
    const queueList = [];
    for await (const q of paginator) {
      queueList.push(...q.RoutingProfileQueueConfigSummaryList);
    }
    queueList.sort((a, b) => a.QueueName.localeCompare(b.QueueName));
    routingProfiles.push({ ...resp.RoutingProfile, Queues: queueList });
  }
  routingProfiles.sort((a, b) => a.Name.localeCompare(b.Name));
  return routingProfiles;
};

const getRoutingProfilesObject = async (connect, instanceId) => {
  const routingProfilesList = await getRoutingProfilesList(connect, instanceId);
  const routingProfiles = routingProfilesList.reduce((acc, rp) => {
    acc[rp.Name] = rp;
    return acc;
  }, {});
  return routingProfiles;
};

module.exports = { getRoutingProfilesList, getRoutingProfilesObject };
