const fs = require("fs");
const { fromIni } = require("@aws-sdk/credential-providers");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const {
  ConnectClient,
  DeleteRoutingProfileCommand,
  CreateRoutingProfileCommand,
  UpdateRoutingProfileAgentAvailabilityTimerCommand,
  UpdateRoutingProfileConcurrencyCommand,
  UpdateRoutingProfileDefaultOutboundQueueCommand,
  UpdateRoutingProfileNameCommand,
  UpdateRoutingProfileQueuesCommand,
  DisassociateRoutingProfileQueuesCommand,
  AssociateRoutingProfileQueuesCommand,
  DescribeRoutingProfileCommand,
} = require("@aws-sdk/client-connect");
const { getRoutingProfilesList } = require("./routing-profiles");
const { getQueues } = require("./queues");
const _ = require("lodash");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

// Parse command line arguments using yargs
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId] --profile [profile] --sourceFile [sourceFile]]"
  )
  .demandOption(["region", "stage"]) // region and stage arguments required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("instanceId", "Specify Amazon Connect instance ID") // description for the instanceID argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile") // description for the profile argument
  .describe("sourceFile", "Path to the source JSON file").argv; // description for the sourceFile argument

let config = { region: argv.region };
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);

if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}

const createRoutingProfile = async (
  connect,
  InstanceId,
  routingProfile,
  queues
) => {
  const input = {
    InstanceId: instanceId,
    Name: routingProfile.Name,
    DefaultOutboundQueueId:
      queues[routingProfile.DefaultOutboundQueueName].QueueId,
    Description: routingProfile.Description,
    MediaConcurrencies: routingProfile.MediaConcurrencies,
    QueueConfigs: [],
    AgentAvailabilityTimeout: routingProfile.AgentAvailabilityTimer,
  };
  const response = await connect.send(new CreateRoutingProfileCommand(input));
  await connect.send(
    new DescribeRoutingProfileCommand({
      InstanceId,
      RoutingProfileId: response.RoutingProfileId,
    })
  );
  console.log(`✅ ${routingProfile.Name} created.`);
  await updateRoutingProfile(
    connect,
    instanceId,
    {...routingProfile, RoutingProfileId: response.RoutingProfileId, RoutingProfileArn: response.RoutingProfileArn},
    routingProfile,
    queues
  );
};

const updateRoutingProfile = async (
  connect,
  InstanceId,
  routingProfile,
  rpConfig,
  queues
) => {
  console.log(`Updating ${routingProfile.Name}`);
  const { RoutingProfileId } = routingProfile;
  if (routingProfile.Description !== rpConfig.Description) {
    await connect.send(
      new UpdateRoutingProfileNameCommand({
        InstanceId,
        RoutingProfileId,
        Description: rpConfig.Description,
      })
    );
  }
  if (
    !_.isEqual(routingProfile.MediaConcurrencies, rpConfig.MediaConcurrencies)
  )
    await connect.send(
      new UpdateRoutingProfileConcurrencyCommand({
        InstanceId,
        RoutingProfileId,
        MediaConcurrencies: rpConfig.MediaConcurrencies,
      })
    );
  if (
    routingProfile.AgentAvailabilityTimeout !== rpConfig.AgentAvailabilityTimer
  ) {
    await connect.send(
      new UpdateRoutingProfileAgentAvailabilityTimerCommand({
        InstanceId,
        RoutingProfileId,
        AgentAvailabilityTimer: rpConfig.AgentAvailabilityTimer,
      })
    );
  }
  const outboundQueueId = queues[rpConfig.DefaultOutboundQueueName].QueueId;
  if (routingProfile.DefaultOutboundQueueId !== outboundQueueId)
    await connect.send(
      new UpdateRoutingProfileDefaultOutboundQueueCommand({
        InstanceId,
        RoutingProfileId,
        DefaultOutboundQueueId: outboundQueueId,
      })
    );
  const currentQueueConfigs = routingProfile.Queues.reduce((acc, queue) => {
    const name = `${queue.QueueName}-${queue.Channel}`;
    acc[name] = queue;
    return acc;
  }, {});
  const queuesToAdd = [];
  const queuesToRemove = [];
  const queuesToUpdate = [];
  for (const queue of rpConfig.Queues) {
    const name = `${queue.QueueName}-${queue.Channel}`;
    if (name in currentQueueConfigs) {
      const currentQueue = currentQueueConfigs[name];
      if (
        currentQueue.Priority !== queue.Priority ||
        currentQueue.Delay !== queue.Delay
      ) {
        queuesToUpdate.push(queue);
      }
    } else {
      queuesToAdd.push(queue);
    }
  }
  const configQueueNames = new Set(
    rpConfig.Queues.map((q) => {
      return `${q.QueueName}-${q.Channel}`;
    })
  );
  for (const queue of routingProfile.Queues) {
    const name = `${queue.QueueName}-${queue.Channel}`;
    console.log(name);
    if (!configQueueNames.has(name)) {
      queuesToRemove.push(queue);
    }
  }

  if (queuesToRemove.length > 0) {
    // only remove up to 10 queues at a time
    const queueChunks = _.chunk(queuesToRemove, 10);
    for (const chunk of queueChunks) {
      await connect.send(
        new DisassociateRoutingProfileQueuesCommand({
          InstanceId,
          RoutingProfileId,
          QueueReferences: chunk.map((q) => {
            return {
              Channel: q.Channel,
              QueueId: queues[q.QueueName].QueueId,
            };
          }),
        })
      );
    }
  }
  if (queuesToAdd.length > 0) {
    // only add up to 10 queues at a time
    const queueChunks = _.chunk(queuesToAdd, 10);
    for (const chunk of queueChunks) {
      await connect.send(
        new AssociateRoutingProfileQueuesCommand({
          InstanceId,
          RoutingProfileId,
          QueueConfigs: chunk.map((q) => {
            return {
              Priority: q.Priority,
              Delay: q.Delay,
              QueueReference: {
                Channel: q.Channel,
                QueueId: queues[q.QueueName].QueueId,
              },
            };
          }),
        })
      );
    }
  }
  if (queuesToUpdate.length > 0) {
    // only update up to 10 queues at a time
    const queueChunks = _.chunk(queuesToUpdate, 10);
    for (const chunk of queueChunks) {
      await connect.send(
        new UpdateRoutingProfileQueuesCommand({
          InstanceId,
          RoutingProfileId,
          QueueConfigs: chunk.map((q) => {
            return {
              Priority: q.Priority,
              Delay: q.Delay,
              QueueReference: {
                Channel: q.Channel,
                QueueId: queues[q.QueueName].QueueId,
              },
            };
          }),
        })
      );
    }
  }
};

const deployRoutingProfiles = async () => {
  const connect = new ConnectClient({ ...config, maxAttempts: 15 });
  const errors = [];
  try {
    const routingProfiles = await getRoutingProfilesList(connect, instanceId);
    const routingProfilesObject = routingProfiles.reduce((acc, item) => {
      acc[item.Name] = item;
      return acc;
    }, {});
    const queues = await getQueues(connect, instanceId);
    const rpConfigs = JSON.parse(
      fs.readFileSync(argv.sourceFile || "data/routing-profiles.json", "utf8")
    );
    for await (const rpConfig of rpConfigs) {
      const { Name } = rpConfig;
      if (Name in routingProfilesObject) {
        const currentRp = routingProfilesObject[Name];
        try {
          await updateRoutingProfile(
            connect,
            instanceId,
            currentRp,
            rpConfig,
            queues
          );
        }
        catch (error) {
          errors.push(`❌ An error occurred while updating ${Name}: ${error}`);
        }

      } else {
        try {
          await createRoutingProfile(connect, instanceId, rpConfig, queues);
        } catch(error) {
          errors.push(`❌ An error occurred while Creating ${Name}: ${error}`);
        }
      }
    }

    for (const rp of routingProfiles) {
      if (!(rp.Name in routingProfilesObject)) {
        const input = {
          InstanceId: instanceId,
          RoutingProfileId: rp.Id,
        };
        const command = new DeleteRoutingProfileCommand(input);
        await connect.send(command);
        console.log(`✅ ${rp.Name} deleted.`);
      }
    }

    errors.forEach(error => {
      console.log(`${error}`)
    });

    console.log("✅ Routing Profiles deployed/updated.");
  } catch (error) {
    console.error("❌ An error occurred:", error);
  }
};

async function main() {
  await deployRoutingProfiles();
}

main();
