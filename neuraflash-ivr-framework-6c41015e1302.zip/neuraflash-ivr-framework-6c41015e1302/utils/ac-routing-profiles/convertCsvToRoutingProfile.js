const fs = require('fs');
const { parse } = require("csv-parse");
const yargs = require("yargs/yargs");

/**
 * This script processes a CSV file containing routing profile data and converts it to a JSON format.
 * It reads a CSV file, extracts the necessary fields, and maps them to a predefined JSON structure
 * to be saved into a destination file.
 *
 * Usage:
 *   node script.js --sourceFile <input_csv_file_path> --destinationFile <output_json_file_path>
 * 
 * Options:
 *   --sourceFile <input_csv_file_path>      The path to the CSV file to process (required).
 *   --destinationFile <output_json_file_path> The path to the JSON file to write (required).
 *
 * Functions:
 *   - `createHeaderMap(inputFilePath)`:
 *     Creates a mapping of header names to their respective column indices in the CSV.
 *     
 *   - `createQueueReferences(row)`:
 *     Creates a list of queue objects for each queue defined in a row, extracting the queue name,
 *     priority, and delay based on the headers in the CSV.
 *
 *   - `mapToRoutingProfile(row)`:
 *     Maps a CSV row to a routing profile object, including media concurrency, outbound queue, and
 *     other routing profile-specific fields. It also uses `createQueueReferences()` to extract queue data.
 * 
 * Example CSV Structure:
 *   | Routing Profile Name | Description | Queue 1 | Queue 1 Priority | Queue 1 Delay | ... |
 *   |----------------------|-------------|---------|------------------|---------------|-----|
 *   | Profile 1            | Desc 1      | QueueA  | 1                | 30            | ... |
 *   | Profile 2            | Desc 2      | QueueB  | 2                | 60            | ... |
 * 
 * The CSV data is expected to start at line 2 with headers, and data starts from line 5 onwards.
 * The CSV will be processed, and a JSON file will be created with an array of routing profile objects.
 *
 * The final JSON file will have the following structure:
 *   {
 *     "Name": "Profile 1",
 *     "Description": "Description of Profile 1",
 *     "MediaConcurrencies": [
 *       {
 *         "Channel": "VOICE",
 *         "Concurrency": 1,
 *         "CrossChannelBehavior": {
 *           "BehaviorType": "ROUTE_CURRENT_CHANNEL_ONLY"
 *         }
 *       }
 *     ],
 *     "Queues": [
 *       {
 *         "QueueName": "QueueA",
 *         "Priority": 1,
 *         "Delay": 30,
 *         "Channel": "VOICE"
 *       }
 *     ],
 *     ...
 *   }
 * 
 * Example:
 *   $ node script.js --sourceFile input.csv --destinationFile output.json
 * 
 * Dependencies:
 *   - `csv-parse`: To parse the CSV data.
 *   - `yargs`: To handle command-line arguments.
 *   - `fs`: To read and write files.
 * 
 * Author: Daniel Dominguez
 * Date: Nov 12, 2024
 */

// Get input and output file paths from command-line arguments
const argv = yargs(process.argv.slice(2))
    .usage("Usage: $0 --sourceFile [name] --destinationFile [name]")
    .demandOption(["sourceFile", "destinationFile"]) // Both arguments are required
    .describe("sourceFile", "Specify CSV file to convert to JSON") 
    .describe("destinationFile", "Specify a destination to write to")
    .argv; 

const inputFilePath = argv.sourceFile;
const outputFilePath = argv.destinationFile; // Fixed variable name
let HEADER_MAP = {};
const routingProfiles = [];

const createHeaderMap = (inputFilePath) => {
    fs.createReadStream(inputFilePath)
    .pipe(parse({ delimiter: ",", from_line: 1, to_line: 1 })) // Start from line 2 to skip headers
    .on('data', (row) => {
        for (let index = 0; index < row.length; index++) {
            const element = row[index];
            HEADER_MAP[element] = index;
        }
    })
    .on('error', (error) => {
        console.error('Error reading the CSV file:', error);
    });
}

const createQueueReferences = (row) => {
    const queues = [];
    // CSV Template Supports 9 Possible Queues
    for (let index = 1; index < 9; index++) {
        let queueNameIndex = HEADER_MAP[`Queue ${index}`];
        let queueName = row[queueNameIndex];
        if(queueName.trim().length!==0) {
            let queuePriority = row[queueNameIndex+1];
            let queueDelay = row[queueNameIndex+2];
            console.log(`\tQueue: ${queueName}`);
            console.log(`\t\tPriority: ${queuePriority} Delay: ${queueDelay}`);
            let queue = {
                "QueueName": queueName,
                "Priority": queuePriority ? parseInt(queuePriority) : 1,
                "Delay": queueDelay ? parseInt(queueDelay): 0,
                "Channel": "VOICE"
            }
            queues.push(queue);
        }
    }
    return queues;
}

// Function to map CSV data to desired JSON structure
const mapToRoutingProfile = (row) => {
    const ROUTING_PROFILE_NAME_INDEX = HEADER_MAP['Routing Profile Name'];
    const ROUTING_PROFILE_DESCRIPTION_INDEX = HEADER_MAP['Description'];
    const OUTBOUND_QUEUE_INDEX = HEADER_MAP['Default Outbound Queue'];
    const QUICK_CONNECT_INDEX = HEADER_MAP['Quick Connects Queue'];

    const ROUTING_ROFILE_NAME = row[ROUTING_PROFILE_NAME_INDEX];
    const ROUTING_PROFILE_DESCRIPTION = row[ROUTING_PROFILE_DESCRIPTION_INDEX];
    const OUTBOUND_QUEUE = row[OUTBOUND_QUEUE_INDEX];
    const QUICK_CONNECT = row[QUICK_CONNECT_INDEX];

    if(ROUTING_ROFILE_NAME.trim().length === 0) {
        return;
    }

    const queues = createQueueReferences(row);

    if (QUICK_CONNECT) {
        console.log(`\tQueue: ${QUICK_CONNECT}`);
        let queue = {
            "QueueName": QUICK_CONNECT,
            "Priority": 99,
            "Delay": 0,
            "Channel": "VOICE"
        }
        queues.push(queue);
    }

    console.log(`Routing Profile: ${ROUTING_ROFILE_NAME}`);
    return  {
        "Name": ROUTING_ROFILE_NAME,
        "Description": ROUTING_PROFILE_DESCRIPTION !== '' ? ROUTING_PROFILE_DESCRIPTION : ROUTING_ROFILE_NAME,
        "MediaConcurrencies": [
          {
            "Channel": "VOICE",
            "Concurrency": 1,
            "CrossChannelBehavior": {
              "BehaviorType": "ROUTE_CURRENT_CHANNEL_ONLY"
            }
          },
          {
            "Channel": "CHAT",
            "Concurrency": 2,
            "CrossChannelBehavior": {
              "BehaviorType": "ROUTE_CURRENT_CHANNEL_ONLY"
            }
          },
          {
            "Channel": "TASK",
            "Concurrency": 1,
            "CrossChannelBehavior": {
              "BehaviorType": "ROUTE_CURRENT_CHANNEL_ONLY"
            }
          }
        ],
        "AgentAvailabilityTimer": "TIME_SINCE_LAST_ACTIVITY",
        "DefaultOutboundQueueName": OUTBOUND_QUEUE === '' ? 'BasicQueue' : OUTBOUND_QUEUE,
        "Queues": queues
      }
};

createHeaderMap(inputFilePath);

// Read and process the CSV file
fs.createReadStream(inputFilePath)
    .pipe(parse({ delimiter: ",", from_line: 3 })) // Start from line 3 to skip headers
    .on('data', (row) => {
        const routingProfile = mapToRoutingProfile(row);
        if (routingProfile !== undefined) {
            routingProfiles.push(routingProfile);
        }
    })
    .on('end', () => {
        // Write the mapped data to a JSON file
        fs.writeFileSync(outputFilePath, JSON.stringify(routingProfiles, null, 2), 'utf8');
        console.log('CSV data has been successfully mapped and written to JSON file.');
    })
    .on('error', (error) => {
        console.error('Error reading the CSV file:', error);
    });
