# ac-prompts

A utility tool for managing Amazon Connect prompts in the IVR Framework. This tool allows you to cache (download) prompts from an S3 bucket to your local machine and deploy (upload) local prompts to an S3 bucket.

## Features

- **Cache Prompts**: Download all prompt files from a specified S3 bucket to a local `prompts` directory.
- **Deploy Prompts**: Upload all prompt files from the local `prompts` directory to a specified S3 bucket.
- Supports multiple environments (dev, qa, prod, etc.) with automatic bucket name resolution.
- Uses AWS SDK for secure and efficient S3 operations.

## Installation

1. Ensure you have Node.js installed (version 14 or higher recommended).
2. Navigate to the `utils/ac-prompts` directory.
3. Install dependencies:
   ```bash
   npm install
   ```

## Prerequisites

- AWS credentials configured (via AWS CLI, environment variables, or IAM roles).
- Access to the S3 bucket containing the prompts.
- The S3 bucket should follow the naming convention: `{clientPrefix}-{stage}-{region}-connect-prompts`.

## Usage

### Cache Prompts

Download prompts from S3 to your local `prompts` directory:

```bash
node cache-prompts.js --region <region> --stage <stage> [options]
```

**Required Arguments:**
- `--region`: AWS region (e.g., us-east-1)
- `--stage or --bucketName`: Used to specify bucket

**Optional Arguments:**
- `--stage`: Environment stage (dev, qa, prod, etc.)
- `--bucketName`: Specific S3 bucket name (if not provided, will be auto-generated based on stage and config)
- `--outputFolderPath`: Local folder to save prompts (default: `prompts`)
- `--profile`: AWS profile to use

**Example:**
```bash
node cache-prompts.js --region us-east-1 --stage dev
```

This will download all prompts from the bucket `yourprefix-dev-us-east-1-connect-prompts` to the local `prompts` directory.

**Example:**
```bash
node cache-prompts.js --region us-east-1 --bucketName henry-qa-us-west-2-connect-prompts
```

This will download all prompts from the bucket `henry-qa-us-west-2-connect-prompts` to the local `prompts` directory.

### Deploy Prompts

Upload prompts from your local `prompts` directory to S3:

```bash
node deploy-prompts.js --region <region> --stage <stage> [options]
```

**Required Arguments:**
- `--region`: AWS region (e.g., us-east-1)
- `--stage or --bucketName`: Used to specify bucket

**Optional Arguments:**
- `--stage`: Environment stage (dev, qa, prod, etc.)
- `--bucketName`: Specific S3 bucket name (if not provided, will be auto-generated based on stage and config)
- `--inputFolderPath`: Local folder containing prompts to upload (default: `prompts`)
- `--profile`: AWS profile to use

**Example:**
```bash
node deploy-prompts.js --region us-east-1 --stage prod
```

This will upload all files from the local `prompts` directory to the bucket `yourprefix-prod-us-east-1-connect-prompts`.

## Configuration

The tool uses configuration files located in the `../../config/` directory relative to this utility. These files contain:
- `clientPrefix`: Your organization's prefix
- `accountNumber`: AWS account number

Supported stages: dev, int, perf, prod, qa, test, preprod.

## Dependencies

- `@aws-sdk/client-s3`: AWS S3 client
- `@aws-sdk/credential-providers`: AWS credential management
- `yargs`: Command-line argument parsing
- `fs`: File system operations
