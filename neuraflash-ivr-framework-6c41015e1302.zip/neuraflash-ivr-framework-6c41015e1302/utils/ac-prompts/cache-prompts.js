const {
  S3Client,
  ListObjectsCommand,
  GetObjectCommand
} = require("@aws-sdk/client-s3");

const {
  createWriteStream,
  unlinkSync,
  existsSync,
  mkdirSync
} = require("fs");

const { join } = require("path");

const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const fs = require("fs");
const { getConfigFromFile } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] (--stage [stage] | --bucketName [bucketName] | --stage [stage] --bucketName [bucketName]) --outputFolderPath [outputFolderPath] --profile [profile]"
  )
  .demandOption(["region"]) // region argument required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("stage", "Specify stage") // description for the stage
  .describe("bucketName", "Specify S3 Bucket Name") // description for the bucketName
  .describe("outputFolderPath", "Optionally specify output Folder Path") // description for the output Folder Path argument
  .describe("profile", "Optionally specify AWS profile") // description for the profile argument
  .check((argv) => {
    if (!argv.stage && !argv.bucketName) {
      throw new Error('Either --stage or --bucketName (or both) must be provided');
    }
    return true;
  }).argv;

let config = { region: argv.region };
let stage = argv.stage;
let region = argv.region;
// Create an S3 client
const s3Client = new S3Client({ config });

// Specify the bucket name
let bucketName = argv.bucketName;
if (!bucketName) {
  const baseConfig = getConfigFromFile(stage);
  const clientPrefix = baseConfig.clientPrefix;
  bucketName = `${clientPrefix}-${stage}-${region}-connect-prompts`;
}

// Specify the folder to save the objects
let folderPath = "prompts";
if (argv.outputFolderPath) {
  folderPath = argv.outputFolderPath;
}

// Function to create the folder if it doesn't exist
function createFolderIfNotExists(folderPath) {
  if (!existsSync(folderPath)) {
    mkdirSync(folderPath);
    console.log(`Folder '${folderPath}' created.`);
  }
}

// Function to download all objects from the bucket
async function downloadAllObjects() {
  try {
    // Create the folder if it doesn't exist
    createFolderIfNotExists(folderPath);

    // List all objects in the bucket
    const data = await s3Client.send(
      new ListObjectsCommand({ Bucket: bucketName })
    );
    const objects = data.Contents;

    // Iterate through each object and download it
    for (const object of objects) {
      const params = {
        Bucket: bucketName,
        Key: object.Key
      };

      // Check if the file exists locally
      const localFilePath = join(folderPath, object.Key);
      if (existsSync(localFilePath)) {
        console.log(`File ${object.Key} already exists locally. Replacing...`);
        unlinkSync(localFilePath); // Delete the existing file
      }

      // Download the object
      const response = await s3Client.send(new GetObjectCommand(params));
      const fileStream = createWriteStream(localFilePath);
      response.Body.pipe(fileStream);

      console.log(`✅ File ${object.Key} downloaded successfully.`);
    }

    console.log("All objects downloaded successfully.");
  } catch (err) {
    console.error("Error:", err);
  }
}

// Call the function to download all objects
downloadAllObjects();
