const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { readdirSync, statSync } = require("fs");
const fs = require("fs");
const { join } = require("path");

const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { getConfigFromFile } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] (--stage [stage] | --bucketName [bucketName] | --stage [stage] --bucketName [bucketName]) --inputFolderPath [inputFolderPath] --profile [profile]"
  )
  .demandOption(["region"]) // region argument required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("stage", "Specify stage") // description for the stage
  .describe("bucketName", "Specify S3 Bucket Name") // description for the bucketName
  .describe("inputFolderPath", "Optionally specify input Folder Path") // description for the input Folder Path argument
  .describe("profile", "Optionally specify AWS profile") // description for the profile argument
  .check((argv) => {
    if (!argv.stage && !argv.bucketName) {
      throw new Error('Either --stage or --bucketName (or both) must be provided');
    }
    return true;
  }).argv;

let config = { region: argv.region };

// Create an S3 client
const s3Client = new S3Client({ config });

// Specify the local folder path
let localFolderPath = "prompts";
if (argv.inputFolderPath) {
  localFolderPath = argv.inputFolderPath;
}

const stage = argv.stage;
const region = argv.region;
// Specify the bucket name
let bucketName = argv.bucketName;
if (!bucketName) {
  const baseConfig = getConfigFromFile(stage);
  const clientPrefix = baseConfig.clientPrefix;
  bucketName = `${clientPrefix}-${stage}-${region}-connect-prompts`;
}

// Function to deploy all files from local folder to S3 bucket
async function deployAllFiles() {
  try {
    // List all files in the local folder
    const files = readdirSync(localFolderPath);

    // Iterate through each file and upload it to S3
    for (const file of files) {
      const filePath = join(localFolderPath, file);
      const fileContent = fs.readFileSync(filePath);

      // Check if the file is a regular file
      if (statSync(filePath).isFile()) {
        const params = {
          Bucket: bucketName,
          Key: file,
          Body: fileContent
        };

        // Upload the file to S3
        await s3Client.send(new PutObjectCommand(params));

        console.log(`✅ File ${file} uploaded successfully.`);
      }
    }

    console.log("All files deployed successfully.");
  } catch (err) {
    console.error("Error:", err);
  }
}

// Call the function to deploy all files
deployAllFiles();
