# AC Phone Numbers

A Node.js utility for managing Amazon Connect phone numbers programmatically. This tool allows you to cache existing phone numbers, create new phone numbers by claiming available ones, and associate contact flows to phone numbers.

## Features

- **Cache Phone Numbers**: Export existing phone numbers from an Amazon Connect instance to a CSV file
- **Create Phone Numbers**: Claim new phone numbers (TOLL_FREE or DID) and assign descriptions
- **Associate Contact Flows**: Link phone numbers to specific contact flows
- **CSV Configuration**: Manage phone number configurations through a simple CSV file
- **AWS Profile Support**: Use different AWS profiles for different environments

## Prerequisites

- Node.js (v14 or higher)
- AWS CLI configured with appropriate credentials
- Amazon Connect instance
- Access to Amazon Connect APIs

## Installation

1. Navigate to the utility directory:
   ```bash
   cd utils/ac-phone-numbers
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

## Configuration

### CSV Configuration File

Create a CSV file with the following columns:

| description                | type      | contactFlowName          | countryCode |
|----------------------------|-----------|--------------------------|-------------|
| Sample SCV Inbound Flow    | DID       | Sample SCV Inbound Flow  | US          |
| Neuraflash Dev Test Number | TOLL_FREE | _Initialization          | US          |
| Spoof Initilization        | TOLL_FREE | zzz_Initialization_Spoof | US          |

**Column Descriptions:**
- `description`: A unique description for the phone number
- `type`: Phone number type (`TOLL_FREE` or `DID`)
- `contactFlowName`: Name of the contact flow to associate (optional)
- `countryCode`: Country code (e.g., `US`, `CA`, `GB`)

## Usage

### Basic Command Structure

```bash
node create-phone-numbers.js --region <region> --filePath <config-file-path> [options]
```

### Required Parameters

- `--region`: AWS region where your Amazon Connect instance is located
- `--filePath`: Path to your CSV configuration file

### Optional Parameters

- `--instanceArn`: Amazon Connect instance ARN (if not provided, will be read from config file)
- `--stage`: Environment stage (dev, qa, prod) - used to read instance ARN from config
- `--profile`: AWS profile to use for authentication

### Examples

#### Using Instance ARN Directly
```bash
node create-phone-numbers.js \
  --region us-east-1 \
  --instanceArn arn:aws:connect:us-east-1:123456789012:instance/instance-id \
  --filePath ./phone_numbers_config.csv
```

#### Using Stage Configuration
```bash
node create-phone-numbers.js \
  --region us-east-1 \
  --stage dev \
  --filePath ./phone_numbers_config.csv
```

#### Using AWS Profile
```bash
node create-phone-numbers.js \
  --region us-east-1 \
  --stage prod \
  --filePath ./phone_numbers_config.csv \
  --profile prod-profile
```

## How It Works

1. **Cache Existing Phone Numbers**: The script first caches all existing phone numbers from your Amazon Connect instance and saves them to `./data/phone_numbers.csv`

2. **Process Configuration**: Reads your CSV configuration file and processes each phone number entry

3. **Create Missing Numbers**: For phone numbers that don't exist in the instance, it:
   - Searches for available phone numbers of the specified type and country
   - Claims the first available number
   - Waits for the claiming process to complete

4. **Associate Contact Flows**: Associates the specified contact flow to each phone number (if contactFlowName is provided)

## Output Files

- `./data/phone_numbers.csv`: Cached phone numbers from your Amazon Connect instance

## Error Handling

The script includes comprehensive error handling for:
- Duplicate phone number descriptions
- Failed phone number claims
- Missing contact flows
- AWS API errors

## Dependencies

- `@aws-sdk/client-connect`: AWS SDK for Amazon Connect operations
- `@aws-sdk/credential-providers`: AWS credential providers
- `yargs`: Command-line argument parsing
- `fs`: File system operations
