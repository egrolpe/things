const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const {
  ConnectClient,
  ListPhoneNumbersCommand,
  DescribePhoneNumberCommand,
  ClaimPhoneNumberCommand,
  SearchAvailablePhoneNumbersCommand,
  AssociatePhoneNumberContactFlowCommand,
  paginateListContactFlows,
} = require("@aws-sdk/client-connect");
const { fromIni } = require("@aws-sdk/credential-providers");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

// Parse command line arguments using yargs
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] --inputFile [inputFile][--instanceId [instanceId] --profile [profile]] "
  )
  .demandOption(["region", "stage", "inputFile"]) // region, stage arguments required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("instanceId", "Specify Amazon Connect instance Id") // description for the instanceId argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("inputFile", "Specify the phone numbers config file") // description for the inputFile argument
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);
let config = { region: argv.region, maxAttempts: 15 };
const configinputFile = argv.inputFile;

if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}

/**
 * Retrieves details for a specific phone number.
 * @param {object} config - The configuration object for the Amazon Connect client.
 * @param {string} phoneNumberId - The ID of the phone number to retrieve details for.
 * @returns {Promise<object>} - A promise that resolves with an object containing the phone number's details, including its ARN, status, and capabilities.
 */
const describePhoneNumber = async (client, phoneNumberId) => {
  const input = {
    PhoneNumberId: phoneNumberId
  };
  const command = new DescribePhoneNumberCommand(input);
  const response = await client.send(command);
  return response;
};

/**
 * Retrieves a list of phone numbers for a given Amazon Connect instance.
 * @param {object} config - The configuration object for the Amazon Connect client.
 * @param {string} instanceId - The ID of the Amazon Connect instance to retrieve phone numbers for.
 * @returns {Promise<Array<object>>} - A promise that resolves with an array of phone number objects, each containing the phone number's ID, ARN, and description.
 */
const getPhoneNumbers = async (client, instanceId) => {
  const phoneNumbersList = [];
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      PhoneNumberTypes: ["TOLL_FREE", "DID"],
      NextToken: nextToken
    };
    const command = new ListPhoneNumbersCommand(input);
    const response = await client.send(command);
    const phoneNumberSummaryList = response.PhoneNumberSummaryList;
    for (const phoneNumber of phoneNumberSummaryList) {
      const describePhoneNumberResponse = await describePhoneNumber(
        client,
        phoneNumber.Id
      );
      phoneNumber["description"] =
        describePhoneNumberResponse["ClaimedPhoneNumberSummary"][
          "PhoneNumberDescription"
        ];
    }
    phoneNumbersList.push(...phoneNumberSummaryList);
    nextToken = response.NextToken;
  } while (nextToken);
  return phoneNumbersList;
};

/**
 * Caches the details of phone numbers and writes them to a CSV file.
 * @returns {Promise<object>} - A promise that resolves with an object containing the cached phone numbers list.
 */
const cachePhoneNumbers = async (client) => {
  try {
    const connectPhoneNumbers = await getPhoneNumbers(client, instanceId);
    // Check that phone numbers are unique
    if (!phoneNumberDescriptionsAreUnique(connectPhoneNumbers)) {
      throw new Error("Phone number descriptions are not unique");
    }
    // Write the routing profiles to a CSV file
    const phoneNumbers = writePhoneNumbersToCSV(connectPhoneNumbers);

    return phoneNumbers;
  } catch (error) {
    console.error("❌ An error occurred:", error);
  }
};

/**
 * Checks if the descriptions of phone numbers in the list are unique.
 * @param {Array} phoneNumbersList - The list of phone numbers to check.
 * @returns {boolean} - Returns true if all descriptions are unique, false otherwise.
 */
const phoneNumberDescriptionsAreUnique = (phoneNumbersList) => {
  const descriptions = phoneNumbersList.map(({ description }) => description);
  const uniqueDescriptions = new Set(descriptions);
  return descriptions.length === uniqueDescriptions.size;
};

/**
 * Writes phone numbers to a CSV file and returns an object with the phone number data.
 * @param {Array} phoneNumbersList - An array of phone number objects.
 * @param {string} phoneNumbersList[].description - The description of the phone number.
 * @param {string} phoneNumbersList[].PhoneNumberType - The type of phone number.
 * @param {string} phoneNumbersList[].PhoneNumberCountryCode - The country code of the phone number.
 * @param {string} phoneNumbersList[].Id - The ID of the phone number.
 * @returns {Object} An object with the phone number data.
 */
const writePhoneNumbersToCSV = (phoneNumbersList) => {
  const inputFile = "./data/phone_numbers.csv"; // New csv path
  const header = [
    "description",
    "type",
    "countryCode",
    "id",
    "contactFlowName",
  ];

  const rows = phoneNumbersList.map(
    ({ description, PhoneNumberType, PhoneNumberCountryCode, Id }) => {
      return [description, PhoneNumberType, PhoneNumberCountryCode, Id, ""];
    }
  );

  const csvData = [header, ...rows].map((row) => row.join(",")).join("\n");
  fs.writeFileSync(inputFile, csvData);

  const data = phoneNumbersList.reduce(
    (acc, { description, PhoneNumberType, PhoneNumberCountryCode, Id }) => {
      acc[description] = {
        type: PhoneNumberType,
        countryCode: PhoneNumberCountryCode,
        id: Id,
      };
      return acc;
    },
    {}
  );
  return data;
};

const readCSV = (inputFile) => {
  const data = fs.readFileSync(inputFile, "utf8");
  const rows = data.split("\n");
  const header = rows[0].split(",");
  const csvData = rows.slice(1).map((row) => {
    const values = row.split(",");
    const rowObject = {};
    header.forEach((header, index) => {
      const value = values[index] ? values[index].trim() : "";
      rowObject[header] = value;
    });
    return rowObject;
  });
  return csvData;
};

const createPhoneNumber = async (client, phoneNumber) => {
  const { description, type, countryCode } = phoneNumber;

  const response = await client.send(
    new SearchAvailablePhoneNumbersCommand({
      InstanceId: instanceId,
      PhoneNumberCountryCode: countryCode,
      PhoneNumberType: type,
      MaxResults: 10,
    })
  );
  const availableNumbers = response.AvailableNumbersList.map(
    (x) => x.PhoneNumber
  );
  for await (const phoneNumber of availableNumbers) {
    // const phoneNumber = availableNumbers.pop();
    console.log(`Claiming phone number ${phoneNumber}`);
    const response = await client.send(
      new ClaimPhoneNumberCommand({
        InstanceId: instanceId,
        PhoneNumber: phoneNumber,
        PhoneNumberDescription: description,
      })
    );
    if (response.PhoneNumberId) {
      for (let i = 0; i < 3; i++) {
        const describeResp = await client.send(
          new DescribePhoneNumberCommand({
            PhoneNumberId: response.PhoneNumberId,
          })
        );
        const summary = describeResp.ClaimedPhoneNumberSummary;
        const phoneNumberStatus = summary.PhoneNumberStatus.Status;
        const phoneNumberId = summary.PhoneNumberId;
        if (phoneNumberStatus === "CLAIMED") {
          console.log(`Created phone number for ${description}`);
          return phoneNumberId;
        }
        if (phoneNumberStatus === "FAILED") {
          throw new Error(
            `Unable to claim phone number ${phoneNumber}. Reason: ${summary.PhoneNumberStatus.Message}`
          );
        }
        if (phoneNumberStatus === "IN_PROGRESS") {
          console.log("Waiting for phone number to be claimed");
          await new Promise((resolve) => setTimeout(resolve, 5000));
        }
      }
      throw new Error(`Unable to claim phone number ${phoneNumber}`);
    }
  }
};
const getContactFlows = async (client) => {
  const contactFlowList = [];
  const paginator = paginateListContactFlows(
    { client },
    { InstanceId: instanceId }
  );
  for await (const page of paginator) {
    contactFlowList.push(...page.ContactFlowSummaryList);
  }
  const contactFlows = contactFlowList.reduce((acc, { Id, Name }) => {
    acc[Name] = Id;
    return acc;
  }, {});
  return contactFlows;
};

const associateFlowToPhoneNumber = async (
  client,
  phoneNumberId,
  phoneNumber,
  contactFlows
) => {
  const { description, contactFlowName } = phoneNumber;
  if (!contactFlowName) {
    console.log(`No contact flow name found for ${description}`);
  } else if (!contactFlows[contactFlowName]) {
    console.error(
      `No contact flow name ${contactFlowName} found exists in the instance`
    );
  } else {
    const command = new AssociatePhoneNumberContactFlowCommand({
      InstanceId: instanceId,
      PhoneNumberId: phoneNumberId,
      ContactFlowId: contactFlows[contactFlowName],
    });
    const response = await client.send(command);
    console.log(
      `Associated contact flow ${contactFlowName} to phone number ${description}`
    );
  }
};
async function main() {
  // Cache the phone numbers of the current state of the Amazon Connect instance
  const client = new ConnectClient(config);
  const currentPhoneNumbers = await cachePhoneNumbers(client);
  const contactFlows = await getContactFlows(client);
  // console.log(contactFlows);
  console.log(currentPhoneNumbers);
  const configData = readCSV(configinputFile);
  for await (const phoneNumber of configData) {
    const { description } = phoneNumber;
    if (!description) {
      continue;
    }
    let phoneNumberId = "";
    if (!(description in currentPhoneNumbers)) {
      phoneNumberId = await createPhoneNumber(client, phoneNumber);
    } else {
      phoneNumberId = currentPhoneNumbers[description].id;
      console.log(`Phone number for \"${description}\" already exists`);
    }
    await associateFlowToPhoneNumber(
      client,
      phoneNumberId,
      phoneNumber,
      contactFlows
    );
  }
}

main();

module.exports = {
  cachePhoneNumbers,
};
