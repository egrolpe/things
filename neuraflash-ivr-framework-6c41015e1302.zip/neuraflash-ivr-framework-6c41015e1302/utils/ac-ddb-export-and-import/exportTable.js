// import required modules
const { DynamoDBClient, ScanCommand } = require("@aws-sdk/client-dynamodb");
const { fromIni } = require("@aws-sdk/credential-providers");
const fsPromises = require("fs").promises;
// parse command line arguments using yargs
const argv = require("yargs/yargs")(process.argv.slice(2))
  .usage("Usage: $0 --region [region] --tableName [name] [--profile [profile]]")
  .demandOption(["region", "tableName"]) // tableName argument required
  .describe("tableName", "Specify table to export") // description for the tableName argument
  .describe("profile", "optionally specify AWS profile").argv; // description for the profile argument
// variables for data directory, file name, and file path
const dataDir = "./data"; // path to data directory
const filename = `${argv.tableName}_items.json`; // file name based on the table name
const region = `${argv.region}`; // file name based on the table name
const filepath = `${dataDir}/${filename}`; // full path to the file
// set AWS SDK configuration
let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}
// async/await to query DynamoDB table and write data to file
(async () => {
  const client = new DynamoDBClient(config); // create DynamoDB client
  const command = new ScanCommand({
    TableName: argv.tableName, // table to scan
    Select: "ALL_ATTRIBUTES" // select all attributes of the table
  });
  try {
    const items = []; // empty array to hold the items
    let results = await client.send(command); // scan
    console.log(results.Items.length); // log number of items in the first batch
    items.push(...results.Items); // add the items to the array
    while (results.LastEvaluatedKey !== undefined) {
      // if there are more items, keep scanning
      command.input.ExclusiveStartKey = results.LastEvaluatedKey; // set the ExclusiveStartKey to the last evaluated key
      results = await client.send(command); // scan command again
      console.log(results.Items.length); // log number of items in the current batch
      items.push(...results.Items); // add the items to the array
    }
    await fsPromises.mkdir(dataDir, { recursive: true }); // create the data directory if it doesn't exist
    await fsPromises.writeFile(filepath, JSON.stringify(items)); // write the data to the file
    console.log(`Data saved to ${filepath}`); // message confirming data was saved
  } catch (err) {
    console.error(err); // log any errors that occur
  }
})();
