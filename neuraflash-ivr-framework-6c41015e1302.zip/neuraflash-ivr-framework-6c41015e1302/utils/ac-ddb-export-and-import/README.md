# AWS DynamoDB Export & Import

This directory contains two node.js scripts. One for exporting data from a DynamoDB table, as well as another for importing data to DynamoDB table. The resulting file on export is .JSON, this is the required format for importing as well.

## Prerequisites

- AWS CLI (version: `aws --version`)
- AWS CLI Profile configured (`aws configure list`)
- node.js (version: `node -v` | install: `brew install node`)
- node package manager (version: `npm -v` | install: `brew install npm`)

## How to use the scripts

### Exporting data:

The exportTable.js script exports data from a specified DynamoDB table to a JSON file. The script accepts the following command line arguments:

`--tableName`: Name of the table to export (required)

`--profile`: Name of the AWS profile to use (optional)

Before running the script:

1. Open a terminal and navigate to the directory where the script is saved.
2. Execute `npm i` to install necessary modules
3. Udpate any parameters of the script such as region.

To use the script, run the following command:

`node exportTable.js --region <region_name> --tableName <table_name> --profile <aws_profile>`

### Importing data:

The importTable.js script imports data from the JSON file to a specified DynamoDB table. The script accepts the following command line arguments:

`--tableName`: Name of the table to import to (required)

`--sourceFile`: Name of the JSON file containing the data to import (optional, defaults to <table_name>\_items.json)

`--profile`: Name of the AWS profile to use (optional)

Before running the script:

1. Open a terminal and navigate to the directory where the script is saved.
2. Execute `npm i` to install necessary modules (not necessary if done prior)
3. Udpate any parameters of the script such as region.

To use the script, run the following command:

`node importTable.js --tableName <table_name> --profile <aws_profile>`

Optionally, include the source file name:

`node importTable.js --tableName <table_name> --sourceFile <filename> --profile <aws_profile>`

`export AWS_REGION=us-west-2`

1. Prompts JSON -
`node importTable.js --tableName nf-dev-us-west-2-config --sourceFile input/Prompts.json --region us-west-2`

2. Dialog States -
`node importTable.js --tableName nf-dev-us-west-2-config --sourceFile input/DialogStates.json --region us-west-2`

3. Global JSON
`node importTable.js --tableName nf-dev-us-west-2-config --sourceFile input/Globals.json --profile internal-dev --region us-west-2`
