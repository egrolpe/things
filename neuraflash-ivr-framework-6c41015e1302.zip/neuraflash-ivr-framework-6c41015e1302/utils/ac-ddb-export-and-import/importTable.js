// ensure yargs is installed globally: npm install -g yargs

// TODO: update the region to be passed in as an argument
// set the region
let region = "us-west-2";

// import required modules
const {
  DynamoDBClient,
  BatchWriteItemCommand
} = require("@aws-sdk/client-dynamodb");
const { fromIni } = require("@aws-sdk/credential-providers");
const fsPromises = require("fs").promises;

// parse command line arguments using yargs
const argv = require("yargs/yargs")(process.argv.slice(2))
  .usage("Usage: $0 --tableName [name] [--profile [profile]]")
  .demandOption(["tableName"]) // tableName argument required
  .describe("tableName", "Specify table to import") // description for the tableName argument
  .describe(
    "sourceFile",
    "optionally override the source items filename (vs $table_items)"
  ) // description for the sourceFile optional argument
  .describe("profile", "optionally specify AWS profile")
  .describe("region", "optionally specify AWS region").argv; // description for the profile argument

// set AWS SDK configuration
if (argv.region != undefined && argv.region != null) {
  region = argv.region;
}
let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments

  console.log("config: ", config);
}

// Set the path to the source JSON file
let sourceItemsPath = `./data/${argv.tableName}.json`;
if (argv.sourceFile) {
  sourceItemsPath = argv.sourceFile;
}

(async () => {
  // initialize DynamoDB client with the config
  const client = new DynamoDBClient(config);
  try {
    // batch size 25 and read the items from the JSON file
    const batchSize = 25;
    const items = JSON.parse(await fsPromises.readFile(sourceItemsPath));
    console.log(`read ${items.length} items`);
    const batches = [];
    // split the items into batches of 25
    for (let i = 0; i < items.length; i += batchSize) {
      batches.push(items.slice(i, i + batchSize));
    }
    console.log(`writing with ${batches.length} batches`);
    // loop through batches and create a BatchWriteItemCommand for each batch
    for (const batch of batches) {
      const putRequests = batch.map((item) => {
        return { PutRequest: { Item: item } };
      });
      const command = new BatchWriteItemCommand({
        RequestItems: {
          [`${argv.tableName}`]: putRequests
        }
      });
      // batchWriteItemCommand to DynamoDB logging the results
      let results = await client.send(command);
      console.log(results);
    }
  } catch (err) {
    console.error(err); // log errors that occur
  }
})();
