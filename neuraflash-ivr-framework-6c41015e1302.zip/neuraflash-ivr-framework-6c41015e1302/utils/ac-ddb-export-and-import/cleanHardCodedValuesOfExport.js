const fsPromises = require("fs").promises;
const fs = require("fs");
// parse command line arguments using yargs
const argv = require("yargs/yargs")(process.argv.slice(2))
  .usage(
    "Usage: $0 --inputFileName [inputFileName] [--outputFileName [outputFileName] --profile [profile]]"
  )
  .demandOption(["inputFileName"]) // fileName argument required
  .describe("inputFileName", "Specify export file to clean")
  .describe("outputFileName", "Specify export file to save to").argv;

// variables for data directory, file name, and file path
const dataDir = "./data"; // path to data directory
const inputFileName = argv.inputFileName;
const outputFileName =
  argv.outputFileName || `${dataDir}/ddb_export_cleaned.json`;

let data = fs.readFileSync(inputFileName, { encoding: "utf8", flag: "r" });
let completeData = JSON.parse(data);
let filteredData = completeData.filter((element) => element.Typing.S !== "arn");

(async () => {
  // async/await to  write data to file
  await fsPromises.mkdir(dataDir, { recursive: true }); // create the data directory if it doesn't exist
  await fsPromises.writeFile(outputFileName, JSON.stringify(filteredData)); // write the data to the file
})();
