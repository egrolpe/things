# Enable Contact Flow Logs

This directory contains a node.js script. This script takes the amazon connect Instance ID or the Stage name and the amazon region and enables Contact Flow Logs.

## Prerequisites

- node.js (version: `node -v` | install: `brew install node`)
- node package manager (version: `npm -v` | install: `brew install npm`)

## How to use the scripts

Before running the script:

1. Open a terminal and navigate to the directory where the script is saved.
2. Execute `npm i` to install necessary modules

To use the script, run one of the following command:

`node enable-logs.js --region <region> --stage <stage>`

`node enable-logs.js --region <region> --stage <stage> --instanceId <instanceId> --profile <profile>`

If the instanceId isn't provided, we'll use the instance ID for the specified stage from the config files in the config directory.

Profile name is optional

example -

`node enable-logs.js --region us-west-2 --instanceId <instanceId> --profile dev`

`node enable-logs.js --region us-west-2 --stage dev --profile dev`
