const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { fromIni } = require("@aws-sdk/credential-providers");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

// Parse command line arguments using yargs
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId] --profile [profile] ]"
  )
  .demandOption(["region", "stage"]) // arguments required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("instanceId", "Specify Amazon Connect instance ID") // description for the instanceId argument
  .describe("stage", "Specify stage to target the deployment to") // description for the stage argument
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);
let config = { region: argv.region };
if (argv.profile) {
  config = {
    ...config,
    credentials: fromIni({ profile: argv.profile })
  };
}

const {
  ConnectClient,
  UpdateInstanceAttributeCommand
} = require("@aws-sdk/client-connect"); // CommonJS import

const client = new ConnectClient(config);

async function enableLogs() {
  try {
    const input = {
      // UpdateInstanceAttributeRequest
      InstanceId: instanceId, // required
      AttributeType: "CONTACTFLOW_LOGS",
      Value: "true" // required
    };
    const command = new UpdateInstanceAttributeCommand(input);
    const response = await client.send(command);
    console.log(response);
    if (response["$metadata"]["httpStatusCode"] == 200) {
      console.log("✅ contact flow logs enabled successfully");
    } else {
      console.log("❌ contact flow logs are now enabled");
    }
  } catch (err) {
    console.log("❌ contact flow logs are not enabled");
    console.log(err);
  }
}

enableLogs();
