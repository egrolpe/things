const fs = require("fs");
const yargs = require("yargs");
const argv = yargs
  .usage(
    "\nUsage :  node $0 --inputDir <Dir>  --botName <botName> --locale <en_US|es_US> "
  )
  .option("inputDir", {
    demandOption: true,
    describe:
      "input directory where bot exports reside.(relativeDirectory to Current path)",
    type: "string"
  })
  .option("botName", {
    demandOption: true,
    describe: "Name of the bot",
    type: "string"
  })
  .option("locale", {
    demandOption: true,
    describe: "Locale to extract: Currently supporting en_US|es_US.",
    type: "string"
  })

  .check((argv) => {
    if (!argv.locale && !argv.inpputDir) {
      throw new Error("Input Directory and Locale are required parameters");
    }
    if (!argv.botName) {
      throw new Error("BotName is required parameter");
    }
    if (!argv.locale || typeof argv.locale == "object") {
      throw new Error("Locale  can not be empty or repeated..");
    } else if (typeof argv.inputDir == "object" || !argv.inputDir) {
      throw new Error("InputDir is requried.. can not be empty or repeaed..");
    }
    return true;
  }).argv;

const inputDir = argv.inputDir;
const botLocale = argv.locale;
const botName = argv.botName;

const intentPath =
  inputDir + "/" + botName + "/BotLocales/" + botLocale + "/Intents";
const slotTypePath =
  inputDir + "/" + botName + "/BotLocales/" + botLocale + "/SlotTypes";

// defile ouput files.
const intentFile = "output/" + botName + "_" + botLocale + "_intents.csv";
const slotTypesFile = "output/" + botName + "_" + botLocale + "_slotTypes.csv";

// if these files exist overwrite them ;

deleteFileIfExists(intentFile);
deleteFileIfExists(slotTypesFile);

const intents = fs.readdirSync(intentPath); // list of intents..
const slotTypes = fs.readdirSync(slotTypePath); //list of slotTypes..

// for each intent push it to IntentsArray.
iArray = []; // array of object each object contains,

for (let intent of intents) {
  if (intent == "FallbackIntent") {
    continue;
  }
  console.log(intent);
  myPath = intentPath + "/" + intent + "/Intent.json";
  intJson = require(myPath);
  slots = getSortedSlots(intJson);
  sampleUtterances = getSampleUtterances(intJson);
  console.log("Currently working on :", JSON.stringify(intJson, "", 2));
  iArray.push({
    Name: intJson.name,
    DialogCodeHook: intJson.dialogCodeHook?.enabled ? "enabled" : "",
    FulfillMentCodeHook: intJson.fulfillmentCodeHook?.enabled ? "enabled" : "",
    slots: slots,
    slotData: [],
    sampleUtterances: sampleUtterances
  });
}

for (let item of iArray) {
  // for (element of item.slots) {
  //   getSlotDetail(item.Name, element)
  // }

  const max = getMaxSlotCount(iArray);
  for (i = 0; i < max; i++) {
    currentSlot = item.slots[i] ? item.slots[i] : "undefined";
    if (currentSlot != "undefined") {
      curSlotData = getSlotDetail(item.Name, currentSlot);
      item.slotData.push(curSlotData);
    } else {
      item.slotData.push("");
    }
  }
}

//
nameData = ["Name"];
DialogCodeHookData = ["DialogCodeHook"];
FulfillMentCodeHookData = ["FulfilmentCodeHook"];
headers = ["Parameter"];
let headerCount = 0;
for (intent of iArray) {
  headerCount++;
  // console.log("Shape of intent :", JSON.stringify(intent, "", 2))
  headers.push(headerCount);
  nameData.push(intent.Name);
  DialogCodeHookData.push(intent.DialogCodeHook);
  FulfillMentCodeHookData.push(intent.FulfillMentCodeHook);
}
AppendToFile(intentFile, headers.join(","));
AppendToFile(intentFile, nameData.join(","));
AppendToFile(intentFile, DialogCodeHookData.join(","));
AppendToFile(intentFile, FulfillMentCodeHookData.join(","));

//// Now write SlotData..

for (i = 0; i < max; i++) {
  let SlotData = ["Slot"];
  for (intent of iArray) {
    // console.log("SlotDetails:", intent.slotData[i])
    SlotData.push('"' + intent.slotData[i] + '"');
  }
  AppendToFile(intentFile, SlotData.join(","));
}

/////  Write the sample utterances now.

const maxUtterance = getMaxUtteranceCount(iArray);

console.log("Max utterance count is : ", maxUtterance);

for (i = 0; i < maxUtterance; i++) {
  let utteranceData = ["SampleUtterance"];
  for (intent of iArray) {
    currentUtterance = intent.sampleUtterances[i]
      ? intent.sampleUtterances[i]
      : "";
    utteranceData.push('"' + currentUtterance + '"');
  }
  AppendToFile(intentFile, utteranceData.join(","));
}

console.clear();

////        SLOT TYPES start here...

const stArray = [];
for (st of slotTypes) {
  //console.log(st)
  stPath = slotTypePath + "/" + st + "/SlotType.json";
  stJson = require(stPath);
  Type = stJson.parentSlotTypeSignature == null ? "custom" : "Extended";
  Regex =
    stJson.valueSelectionSetting.regexFilter == null
      ? ""
      : stJson.valueSelectionSetting.regexFilter.pattern;
  Resolutionstrategy =
    stJson.valueSelectionSetting.resolutionStrategy == "ORIGINAL_VALUE"
      ? "OriginalValue"
      : "TopResolution";
  SlotValueAsCustomVocabulary =
    stJson.valueSelectionSetting?.advancedRecognitionSetting
      ?.audioRecognitionStrategy == "UseSlotValuesAsCustomVocabulary"
      ? "TRUE"
      : "";
  slotTypeValues = getSlotTypeDetails(stJson);
  stArray.push({
    Name: stJson.name,
    Type: Type,
    Resolutionstrategy: Resolutionstrategy,
    SlotValueAsCustomVocabulary: SlotValueAsCustomVocabulary,
    Regex: '"' + Regex + '"',
    slotTypeValues: slotTypeValues
  });
}

for (let st of stArray) {
  console.log(st);
}

// get the max count of SampleValues
const maxStCount = getMaxSlotTypeValuesCount(stArray);
console.log("Maximum count of Synonyms:", maxStCount);

/// start writing data to
//1. update header for slotTypeValues.
let stHeaders = ["Parameter"];
for (let i = 0; i < stArray.length; i++) {
  stHeaders.push(i + 1);
}
AppendToFile(slotTypesFile, stHeaders.join(","));

//2 udate Name to Vocabulary..
stNameData = ["Name"];
stTypeData = ["Type"];
stRegexData = ["Regex"];
stResolutionStrategy = ["ResolutionStrategy"];
stVocabulary = ["SlotValueAsCustomVocabulary"];

for (let element of stArray) {
  stNameData.push(element.Name);
  stTypeData.push(element.Type);
  stRegexData.push(element.Regex);
  stResolutionStrategy.push(element.Resolutionstrategy);
  stVocabulary.push(element.SlotValueAsCustomVocabulary);
  // append this to file.
}
AppendToFile(slotTypesFile, stNameData.join(","));
AppendToFile(slotTypesFile, stTypeData.join(","));
AppendToFile(slotTypesFile, stRegexData.join(","));
AppendToFile(slotTypesFile, stResolutionStrategy.join(","));
AppendToFile(slotTypesFile, stVocabulary.join(","));

// now write Synonyms

for (let i = 0; i < maxStCount; i++) {
  stSynonyms = ["Synonyms"];
  for (element of stArray) {
    //console.log("Element :", element)
    currentSynonym = element.slotTypeValues[i]
      ? '"' + element.slotTypeValues[i] + '"'
      : "";
    stSynonyms.push(currentSynonym);
  }
  AppendToFile(slotTypesFile, stSynonyms.join(","));
}

console.log(".......Done........");
////        function declaration starts...

/**
 *
 * @param {*} fileName
 * @param {*} data
 */
function AppendToFile(fileName, data) {
  data = data + "\n";
  fs.appendFileSync(fileName, data);
}

function getSortedSlots(input) {
  let slots = [];
  let intent = input.name;
  //   console.log("Input json is :", input.slotPriorities)
  for (element of input.slotPriorities) {
    index = element.priority - 1;
    slots[index] = element.slotName;
  }
  console.log("Number of Slots in :", intent, ": is", slots.length);
  return slots;
}

function getMaxSlotCount(input) {
  // input is array of Objects each containing details about an Intent.
  max = 0;
  for (let element of input) {
    // console.log(JSON.stringify(element))

    if (element.slots.length > max) {
      max = element.slots.length;
    }
  }
  console.log("Maximum count of slots is :", max);

  return max;
}

function getSlotDetail(intent, slot) {
  let slotPath = intentPath + "/" + intent + "/Slots/" + slot + "/Slot.json";

  slotJson = require(slotPath);

  Required = slotJson.slotConstraint == "Required" ? "Required" : "Optional";
  SlotName = slotJson.name;
  slotTypeName = slotJson.slotTypeName;
  prompt =
    slotJson.valueElicitationSetting?.promptSpecification?.messageGroupsList[0]
      ?.message.plainTextMessage.value;

  let result = [Required, SlotName, slotTypeName, prompt].join(":");
  console.log("current slot data :", result, "\n\n");

  return result;
}

function getSampleUtterances(intJson) {
  let array = intJson.sampleUtterances;
  let result = [];
  for (item of array) {
    result.push(item.utterance);
  }
  return result;
}

function getMaxUtteranceCount(intArray) {
  // input is array of Objects each containing details about an Intent.
  max = 0;
  for (let element of intArray) {
    // console.log(JSON.stringify(element))

    if (element.sampleUtterances.length > max) {
      max = element.sampleUtterances.length;
    }
  }
  console.log("Maximum count of SampleUttances is :", max);

  return max;
}

function getMaxSlotTypeValuesCount(slotArray) {
  max = 0;
  for (let element of slotArray) {
    // console.log(JSON.stringify(element))

    if (element.slotTypeValues.length > max) {
      max = element.slotTypeValues.length;
    }
  }
  //console.log("Maximum lines required for slotTypeValues is :", max)

  return max;
}

function getSlotTypeDetails(stJson) {
  //console.log(JSON.stringify(stJson, "", 2))

  let stv = [];
  if (stJson.slotTypeValues == null) {
    // custom types will not have this defined..
    return stv;
  }
  console.log("Found slotTypeValues..");

  for (element of stJson.slotTypeValues) {
    currentSampleValue = element.sampleValue.value;
    console.log("current sampleValue", currentSampleValue);
    if (element.synonyms != null) {
      console.log("Found synonyms");
      for (syn of element.synonyms) {
        currentSampleValue = currentSampleValue + ";" + syn.value;
      }
      console.log("Adding synonyms", currentSampleValue);
    }

    stv.push(currentSampleValue);
  }
  return stv;
}

function deleteFileIfExists(fileName) {
  if (fs.existsSync(fileName)) {
    console.log("...Deleting old file...");
    try {
      fs.unlinkSync(fileName);
    } catch (error) {
      console.log("Error Deleting the file");
      throw new Error(error);
    }
  }
}
