# Bot Parser : Utility to create csv files from bot-exports.

This utility is built to generate bot definitions in csv format from a Lexbot already deployed on AWS. The csv generated from these could be used to create a bot in other/higher environment.

### 1. Export the bot .
  * From AWS management console go to Amazon Lex.
  * List the bots and select the bot ; from Actions export the bot.
  * This will download the .zip file to local machine.
  * unzip the folder to local drive. The unzip will create two items
    * Manifest.json
    * folder by botname.  : copy this folder to utils/lex-build-directories/botParser/bot-exxports directory.

### 2. Run the csv generator
* on a terminal navigate to 
  
 ``` cd utils/lex-build-directories/botParser/  ```

 * run the ```node csvGenerator.js  --inputDir './bot-exports' --botName values --locale en_US ```
  
```

  --inputDir  input directory where bot exports reside.(relativeDirectory to
              Current path)                                  [string] [required]
  --botName   Name of the bot                                [string] [required]
  --locale    Locale to extract: Currently supporting en_US|es_US.
                                                             [string] [required]

This will generate two csv files in output directory. one for intent and other for slotTypes. The file name will be <botName>_locale_intnet.csv/slotTypes.csv.

These files can be used to create a bot ; Check the README at utils/lex-builder-directory/v2

