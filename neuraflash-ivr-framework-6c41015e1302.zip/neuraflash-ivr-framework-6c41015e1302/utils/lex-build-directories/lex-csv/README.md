# Lex CSV Configuration

This directory contains CSV files used to configure Amazon Lex bots. The CSV files define intents and slot types for different bot configurations.

## Directory Structure

- `globals/`: Contains global intents and slot types that can be shared across bots.
- `router-bot/`: Contains intents and slot types specific to the router bot.

## CSV File Formats

### en_intents.csv

This file defines the intents for the Lex bot. Each column represents a different intent, and rows define various parameters for those intents.

#### Columns:
- **Parameter**: The configuration parameter name.
- **1, 2, 3, ...**: Each numbered column corresponds to a specific intent (e.g., 1 for "agent", 2 for "number").

#### Key Parameters:
- **Name**: The name of the intent (e.g., "agent", "number").
- **DialogCodeHook**: Whether the dialog code hook is enabled ("enabled" or empty).
- **FulfilmentCodeHook**: Whether the fulfillment code hook is enabled ("enabled" or empty).
- **Slot**: Slot definitions in the format "Optional:slot_name:slot_type:" or "Required:slot_name:slot_type:".
- **InputContexts**: Contexts that must be active for this intent to be recognized.
- **SampleUtterance**: Example phrases that trigger this intent. Use curly braces for slot placeholders (e.g., `{slot_name}`).

#### Example Structure:

| Parameter          | 1                      | 2                      |
|--------------------|------------------------|------------------------|
| Name               | intent1                | intent2                |
| DialogCodeHook     | enabled                | enabled                |
| FulfilmentCodeHook | enabled                | enabled                |
| Slot               | Optional:slot1:type1:  | Required:slot2:type2:  |
| InputContexts      | context1               | context2               |
| SampleUtterance    | {slot1} phrase         | another phrase         |

### en_slotTypes.csv

This file defines custom slot types for the Lex bot.

#### Columns:
- **Parameter**: The configuration parameter name.
- **1, 2, 3, ...**: Each numbered column corresponds to a specific slot type.

#### Key Parameters:
- **Name**: The name of the slot type (e.g., "agent", "states").
- **Type**: The type of slot ("custom" for custom slots).
- **Regex**: Optional regex pattern for validation (leave empty if not used).
- **ResolutionStrategy**: How to resolve slot values ("OriginalValue" or "TopResolution").
- **SlotValueAsCustomVocabulary**: Whether to use as custom vocabulary (leave empty if not used).
- **Synonyms**: Synonyms for slot values. Format as "value;synonym" or just "synonym" for the slot value itself.

#### Example Structure:

| Parameter                  | 1                    |
|----------------------------|----------------------|
| Name                       | slot_type_name       |
| Type                       | custom               |
| Regex                      |                      |
| ResolutionStrategy         | OriginalValue        |
| SlotValueAsCustomVocabulary|                      |
| Synonyms                   | value1               |
| Synonyms                   | value2               |
| Synonyms                   | value1;synonym1      |

## Usage Notes

- Ensure CSV files are properly formatted with commas as delimiters.
- For intents with multiple sample utterances, add multiple "SampleUtterance" rows.
- Slot types can have multiple synonyms listed in separate rows.
- **The first row should always be the header with "Parameter" and numbered columns.**
- Use consistent naming conventions for intents and slots across files.

## Examples

Refer to the existing CSV files in `globals/` and `router-bot/` for concrete examples of the expected format.
