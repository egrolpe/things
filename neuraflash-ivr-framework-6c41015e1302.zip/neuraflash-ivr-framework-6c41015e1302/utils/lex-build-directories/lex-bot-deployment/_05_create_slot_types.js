const yargs = require("yargs");
const fs = require("fs");
const { LexModelsV2Client } = require("@aws-sdk/client-lex-models-v2");
const path = require("path");
const { fromIni } = require("@aws-sdk/credential-providers");

const { delay, bot_create_slot_type } = require("../../sdk/bot_actions.js");
/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --region <region> --botDetailsFile <bot details file>"
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string",
  })
  .option("profile", {
    describe: "AWS profile to be used in the API call.\n",
    demandOption: true,
    type: "string",
  })
  .option("botDetailsFile", {
    describe: "json file with bot details",
    demandOption: true,
    type: "string",
  })
  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    } else if (typeof argv.botDetailsFile == "object" || !argv.botDetailsFile) {
      throw new Error("botDetails can not be empty or repeaed..");
    }
    return true;
  }).argv;

const profile = argv.profile;
const region = argv.region;
const bot_details = require(argv.botDetailsFile);

let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

console.log("Executing Script 5 ...");
// console.log("Profile and Argument Details: ",argv);
const client = new LexModelsV2Client(config);

// console.log("Beginning. CREATE SLOTS.. aws profile is :", profile);

count = 0; // just to keep the count...
/**
 * This Function creates slotTypes for a locale..
 * @param {LexModelsV2Client} client
 * @param {Object} bot_details
 * @param {string} cur_locale
 *
 */
async function create_slot_types(client, bot_details, cur_locale) {
  // console.log(`====iteration ${count}====`);
  new_slot_types = [];
  const array_of_st = bot_details.bot_locales[cur_locale].slot_types;

  total_count = bot_details.bot_locales[cur_locale].slot_types.length;
  console.log("Total slot types in locale \"" + cur_locale + "\" to add are:", total_count);
  for (st of array_of_st) {
    // iterate over array of slotTypes .
    //console.log(JSON.stringify(st, "", 2));

    response = await bot_create_slot_type(client, bot_details, cur_locale, st);
    st.id = response.slotTypeId;
    new_slot_types.push(st);

    count++;
  }
  bot_details.bot_locales[cur_locale].slot_types = new_slot_types;
  return bot_details;
}

async function main() {
  // if (bot_details.bot_locales["en_US"].slot_types?.length > 0) {
  //   console.log("Creating English slot types");
  //   await create_slot_types(client, bot_details, "en_US");
  // }

  // if (bot_details.bot_locales["es_US"].slot_types?.length > 0) {
  //   console.log("Creating Spanish slot types");
  //   await create_slot_types(client, bot_details, "es_US");
  // }

  for (locale of Object.keys(bot_details.bot_locales)) {
    if (!bot_details.bot_locales[locale].enabled) {
      // console.log(`locale ${locale} not enabled for provisioning..`);
      break;
    } else {
      // console.log(`======creating ${locale}========`);
      await create_slot_types(client, bot_details, locale);
      // console.log(`Created locale for ${locale}`);
    }
  }

  fs.writeFileSync(argv.botDetailsFile, JSON.stringify(bot_details, "", 2));
}

main();
