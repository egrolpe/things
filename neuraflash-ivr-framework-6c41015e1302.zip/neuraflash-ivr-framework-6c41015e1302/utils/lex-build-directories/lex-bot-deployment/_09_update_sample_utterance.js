const yargs = require("yargs");
const fs = require("fs");
const { LexModelsV2Client } = require("@aws-sdk/client-lex-models-v2");
const path = require("path");
const { fromIni } = require("@aws-sdk/credential-providers");

const { delay, bot_update_intent } = require("../../sdk/bot_actions.js");
// const { create } = require("domain");
// const internal = require("stream");
/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --region <region> --botDetailsFile <bot details file>"
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string",
  })
  .option("profile", {
    describe: "AWS profile to be used in the API call.\n",
    demandOption: true,
    type: "string",
  })
  .option("botDetailsFile", {
    describe: "json file with bot details",
    demandOption: true,
    type: "string",
  })
  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    } else if (typeof argv.botDetailsFile == "object" || !argv.botDetailsFile) {
      throw new Error("botDetails can not be empty or repeaed..");
    }

    return true;
  }).argv;

const profile = argv.profile;
const region = argv.region;
const bot_details = require(argv.botDetailsFile);

let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

console.log("Executing Script 9 ...");
// console.log("Profile and Argument Details: ",argv);
const client = new LexModelsV2Client(config);

let count = 0;

count = 0;
// const update_sample_utternces = async () => {
//   // function created to iterate over intents.
//   for (const slot_detail of slot_details) {
//     console.log(`========iteration${count++}=======`)
//     console.log(slot_details)

//     response = await bot_update_intent(
//       client,
//       bot_details,
//       cur_locale,
//       slot_detail
//     )

//     console.log(JSON.stringify(response, "", 2))
//     // slot_detail.slot_id = response.slotId
//   }
// }
// step0 = update_sample_utternces()
// step0.then(async () => {
//   fs.writeFileSync(
//     "intent_slot_map_" + cur_locale + ".json",
//     JSON.stringify(slot_details, "", 2)
//   )
//   await delay(5000) //a slight delay is given for intents to be in available state.
//   // console.log(JSON.stringify(bot_details, "", 2))
//   // fs.writeFileSync("bot_details.json", JSON.stringify(bot_details, "", 2))
// })
async function main() {
  // let new_intents = []
  for (locale of Object.keys(bot_details.bot_locales)) {
    //run for english and spanish..

    if (!bot_details.bot_locales[locale].enabled) {
      console.log(`The Locale ${locale} is not enabled`);
      break;
    }
    intents = bot_details.bot_locales[locale].intents;

    for (intent of intents) {
      for (element of intent.slotPriorities) {
        mySlot = intent.slots.filter((obj) => obj.name === element.slotName);
        element["slotId"] = mySlot[0].id;
      }
      let input = {};
      if (locale == "en_US") {
        intent_details = {
          sampleUtterances: intent.sampleUtterances,
          slotPriorities: intent.slotPriorities,
          intent_id: intent.id,
          intent_name: intent.name,
          fulfillmentCodeHook: intent.fulfillmentCodeHook,
          dialogCodeHook: intent.dialogCodeHook,
          inputContexts: intent.inputContexts,
        };
      } else {
        intent_details = {
          sampleUtterances: intent.sampleUtterances,
          slotPriorities: intent.slotPriorities,
          intent_id: intent.id,
          intent_name: intent.name,
          fulfillmentCodeHook: intent.fulfillmentCodeHook,
          dialogCodeHook: intent.dialogCodeHook,
        };
      }

      // console.log(
      //   `input parameters are :${JSON.stringify(intent_details, "", 2)}`
      // );
      response = await bot_update_intent(
        client,
        bot_details,
        locale,
        intent_details
      );
      // console.log(response);

      // new_slots.push(slot)
    }
  }
}

main();
