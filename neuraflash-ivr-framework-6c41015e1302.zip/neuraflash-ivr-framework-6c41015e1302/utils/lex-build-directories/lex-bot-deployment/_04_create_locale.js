const yargs = require("yargs");
const fs = require("fs");
const { LexModelsV2Client } = require("@aws-sdk/client-lex-models-v2");
const path = require("path");
const { fromIni } = require("@aws-sdk/credential-providers");

const { delay, bot_create_locale } = require("../../sdk/bot_actions.js");
/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --region <region> --botDetailsFile <bot details file>"
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string",
  })
  .option("profile", {
    describe: "AWS profile to be used in the API call.\n",
    demandOption: true,
    type: "string",
  })
  .option("botDetailsFile", {
    describe: "json file with bot details",
    demandOption: true,
    type: "string",
  })
  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    } else if (typeof argv.botDetailsFile == "object" || !argv.botDetailsFile) {
      throw new Error("botDetails can not be empty or repeaed..");
    }

    return true;
  }).argv;

const profile = argv.profile;
const region = argv.region;
const bot_details = require(argv.botDetailsFile);

// const { bot_create_locale } = require("./sdk/bot_actions.js")

let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

console.log("Executing Script 4 ...");
// console.log("Profile and Argument Details: ",argv);
const client = new LexModelsV2Client(config);

// // create a role.
// step0 = bot_create_locale(client, bot_details, cur_locale)

async function create_locale(client, bot_details) {
  try {
    for (locale of Object.keys(bot_details.bot_locales)) {
      if (!bot_details.bot_locales[locale].enabled) {
        // console.log(`locale ${locale} is not enabled for provisioning..`);
        break;
      } else {
        // console.log(`======creating ${locale}========`);
        await bot_create_locale(client, bot_details, locale);
        // console.log(`Created locale for ${locale}`);
      }
    }

    return bot_details;
  } catch (error) {
    console.error("An error occurred:", error);
  }
}

step1 = create_locale(client, bot_details);
step1.then(() => {
  console.log("Locale creation completed ...");
});

//

// step0.then(async (res) => {
//   console.log("=====================")
//   console.log(res)
//   console.log(" waiting so that locale becomes available..")
//   await delay(10000)
// })
