/**
 * This program generated bot_details.json file to be used to automate the bot creation.
 * Takes the input in CSV format.
 * Required input paramters are
 * 1. CSV file.
 * 2. Locale.
 * 3. BotName.
 * 4. Input Json file.. (In case of Updating a new Locale..)
 * 5. Output Json file.
 */
const yargs = require("yargs");
const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");
//const bot_details = require("./bot_template.json")

const argv = yargs
  .usage(
    "\nUsage :  node $0 --en_US_slotTypes <en_slotTypes.csv> --en_US_global_slotTypes <global_en_slotTypes.csv>  --en_US_intents <en_intents.csv> --en_US_global_intents <global_en_intents.csv>  --es_US_slotTypes <es_slotTypes.csv> --es_US_global_slotTypes <global_es_slotTypes.csv>  --es_US_intents <spanish_intent_csv> --global_es_US_intents <global_spanish_intent_csv> --fr_CA_slotTypes <fr_slotTypes.csv>  --fr_CA_global_slotTypes <global_fr_slotTypes.csv>  --fr_CA_intents <fr_intent_csv> --fr_CA_global_intents <global_fr_intent_csv> --botTemplate <template.json>  --outputFile <outputFile>"
  )
  .option("en_US_global_slotTypes", {
    describe: "input CSV file for Global English(US) SlotTypes.",
    type: "string",
  })
  .option("en_US_global_intents", {
    describe: "input CSV file for Global English(US) Intents.",
    type: "string",
  })
  .option("en_US_slotTypes", {
    describe: "input CSV file for English(US) SlotTypes.",
    type: "string",
  })
  .option("en_US_intents", {
    describe: "input CSV file for English(US) Intents.",
    type: "string",
  })
  .option("es_US_global_slotTypes", {
    describe: "input CSV file for Global Spanish(US) SlotTypes.",
    type: "string",
  })
  .option("es_US_global_intents", {
    describe: "input CSV file for Global Spanish(US) Intents.",
    type: "string",
  })
  .option("es_US_slotTypes", {
    describe: "input CSV file for Spanish(US) SlotTypes.",
    type: "string",
  })
  .option("es_US_intents", {
    describe: "input CSV file for Spanish(US) Intents.",
    type: "string",
  })
  .option("fr_CA_global_slotTypes", {
    describe: "input CSV file for Global French(CA) SlotTypes.",
    type: "string",
  })
  .option("fr_CA_global_intents", {
    describe: "input CSV file for Global French(CA) Intents.",
    type: "string",
  })
  .option("fr_CA_slotTypes", {
    describe: "input CSV file for French(CA) SlotTypes.",
    type: "string",
  })
  .option("fr_CA_intents", {
    describe: "input CSV file for French(CA) Intents.",
    type: "string",
  })
  .option("botTemplate", {
    describe: "botTemplate to be used...",
    type: "string",
  })
  .option("outputFile", {
    describe: "output file ; default is bot-details.json",
    type: "string",
  })

  .check((argv) => {
    // if (
    //   !argv.en_US_slotTypes &&
    //   !argv.en_US_intents &&
    //   !argv.es_US_slotTypes &&
    //   !argv.es_US_intents
    // ) {
    //   throw new Error("One or more options missing..");
    // }
    // if (!argv.en_US|| typeof argv.en_US == "object") {
    //   throw new Error("Locale is required.  can not be empty or repeated..");
    // } else if (typeof argv.es_US_intents == "object" || !argv.es_US) {
    //   throw new Error("Locale is requried. can not be empty or repeaed..");
    // }

    return true;
  }).argv;
/**
 * end of yargs..
 */
console.log("Argument: ", argv);
const outputFile = argv.outputFile || "./bot_details.json";
const botTemplate = argv.botTemplate || "./bot_template.json";
const bot_details = require(botTemplate);

// console.log("========Result==========")
//console.log(JSON.stringify(bot_details, "", 2))

/**
 *
 * @param {string} file filename to process.
 * @param {string} locale locale "en_US" | "es_US"
 * @returns {Promise} returns a promise is resolved when CSV processing is complete.
 */

async function getSlotTypes(file, locale) {
  console.log(
    "=============inside getSlottypes:",
    "Locale:",
    locale,
    "========================"
  );

  return new Promise((resolve, reject) => {
    let slotTypes = [];
    fs.createReadStream(file)
      .pipe(csv())
      .on("data", (data) => {
        switch (data.Parameter) {
          case "Name":
            console.log("found name");
            // console.log(data);
            for (key of Object.keys(data)) {
              //console.log(data[key]);
              if (key != "Parameter") {
                slotTypes.push({
                  name: data[key],
                  valueSelectionSetting: {
                    resolutionStrategy: "OriginalValue",
                  },
                });
              }
            }

            break;
          case "Type":
            console.log("Found Type");
            //console.log(JSON.stringify(data, "", 2));
            for (key of Object.keys(data)) {
              if (key != "Parameter") {
                // console.log(`current key is ${key}`);
                arrayIndex = Number(key) - 1;
                //  console.log(arrayIndex);
                // console.log(data.key);
                //slotTypes[arrayIndex].type = data[key];

                switch (data[key].toLowerCase()) {
                  case "custom":
                    slotTypes[arrayIndex].parentSlotTypeSignature = null;

                    break;
                  case "extended":
                    slotTypes[arrayIndex].parentSlotTypeSignature =
                      "AMAZON.AlphaNumeric";
                }
              }
            }

            break;
          case "Regex":
            console.log("found regex");
            for (key of Object.keys(data)) {
              arrayIndex = Number(key) - 1;
              if (
                key != "Parameter" &&
                slotTypes[arrayIndex].parentSlotTypeSignature ==
                  "AMAZON.AlphaNumeric"
              ) {
                //slotTypes[arrayIndex].Regex = data[key];
                slotTypes[arrayIndex]["valueSelectionSetting"]["regexFilter"] =
                  {
                    pattern: data[key],
                  };
              }
            }

            break;
          case "ResolutionStrategy":
            console.log("Found resolutions strategy");
            for (key of Object.keys(data)) {
              if (key != "Parameter") {
                arrayIndex = Number(key) - 1;
                slotTypes[arrayIndex][
                  "valueSelectionSetting"
                ].resolutionStrategy = data[key];
              }
            }
            break;

          case "SlotValueAsCustomVocabulary":
            console.log("Custom vocabulary");
            // console.log("Custom vocabulary", data);
            if (locale != "en_US") {
              break;
            }
            for (key of Object.keys(data)) {
              if (key != "Parameter" && data[key].toLowerCase() == "true") {
                arrayIndex = Number(key) - 1;

                // slotTypes[arrayIndex].useSlotValuesAsCustomVocabulary =
                //   data[key];
                slotTypes[arrayIndex]["valueSelectionSetting"][
                  "advancedRecognitionSetting"
                ] = {
                  audioRecognitionStrategy: "UseSlotValuesAsCustomVocabulary",
                };
              }
            }

          //   break;
          case "Synonyms":
            //  console.log("found synonyms");
            // data will be slotValue;synonym1;synonym2
            for (key of Object.keys(data)) {
              let isDuplicate = false; // initial value
              if (key != "Parameter" && data[key] != "") {
                // console.log(
                //   `The data while processing synonyms ${JSON.stringify(
                //     data[key],
                //     "",
                //     2
                //   )}`
                // );
                arrayIndex = Number(key) - 1;
                // create two arrays. One for Duplicates one for Uniq Values.
                if (slotTypes[arrayIndex].uniqValues == undefined) {
                  slotTypes[arrayIndex].uniqValues = [];
                  slotTypes[arrayIndex].duplicates = [];
                }

                currentSynonymsCount =
                  slotTypes[arrayIndex]?.synonymsCount || 0;
                let temp = data[key].split(";");
                // check each values is in uniqValues if not add it otherwise add the record in duplicates and break;
                temp.forEach((element) => {
                  if (
                    slotTypes[arrayIndex].uniqValues.includes(element) &&
                    element != null
                  ) {
                    console.log("Found duplicate value:", element);
                    isDuplicate = true;
                  }
                });

                if (isDuplicate) {
                  console.log(
                    "Found duplicate updating the duplicate array",
                    JSON.stringify(data[key], "", 2)
                  );

                  slotTypes[arrayIndex].duplicates.push(data[key]);
                  // console.log(
                  //   JSON.stringify(
                  //     slotTypes[arrayIndex].duplicates.push(data[key]),
                  //     "",
                  //     2
                  //   )
                  // );
                  break;
                } else {
                  for (elm of temp) {
                    slotTypes[arrayIndex].uniqValues.push(elm);
                  }
                }

                sampleValue = temp[0];
                synonyms = temp.slice(1);
                //Count the synonyms and sample values.

                slotTypes[arrayIndex].synonymsCount =
                  currentSynonymsCount + temp?.length;

                // console.log(`sampleValue : ${sampleValue}`);
                // console.log(`sampleValue : ${synonyms}`);

                let synArray = [];
                if (synonyms.length > 0) {
                  for (element of synonyms)
                    synArray.push({
                      value: element,
                    });
                } else {
                  synArray = null;
                }

                if (slotTypes[arrayIndex].slotTypeValues == undefined) {
                  slotTypes[arrayIndex].slotTypeValues = []; // define array for the first time.
                }
                //if synArray is more than one change the value Selectionsetting of current SlotType.
                if (synArray?.length > 1) {
                  slotTypes[arrayIndex].valueSelectionSetting = {
                    resolutionStrategy: "TopResolution",
                  };
                }

                slotTypes[arrayIndex].slotTypeValues.push({
                  sampleValue: {
                    value: sampleValue,
                  },
                  synonyms: synArray,
                });
              }
            }
        }
      })
      .on("end", () => {
        // bot_details.bot_locales[locale].slot_types = getSlotTypeValues(
        //   headers,
        //   rows,
        //   locale
        // );
        // console.log(`The result`, JSON.stringify(slotTypes, "", 2));
        resolve(slotTypes);
      })

      .on("error", (err) => {
        reject(err);
      });
  });
}

async function getIntents(file) {
  return new Promise((resolve, reject) => {
    let intents = [];
    let priority = 1;
    fs.createReadStream(file)
      .pipe(csv())
      .on("data", (data) => {
        switch (data.Parameter) {
          case "Name":
            console.log("Found name");

            for (key of Object.keys(data)) {
              //console.log(data[key]);
              if (key != "Parameter") {
                intents.push({
                  name: data[key],
                  slots: [],
                  sampleUtterances: [],
                  slotPriorities: [],
                  inputContexts: [],
                });
              }
            }

            break;
          case "DialogCodeHook":
            console.log("Found DialogCodeHook");
            for (key of Object.keys(data)) {
              //console.log(data[key]);
              if (key != "Parameter") {
                arrayIndex = Number(key) - 1;
                intents[arrayIndex]["dialogCodeHook"] = {
                  enabled: data[key] == "enabled" ? true : false,
                };
              }
            }

            break;
          case "FulfilmentCodeHook":
            console.log("Found FulfilmentCodeHook");
            for (key of Object.keys(data)) {
              //console.log(data[key]);
              if (key != "Parameter") {
                arrayIndex = Number(key) - 1;
                intents[arrayIndex]["fulfillmentCodeHook"] = {
                  enabled: data[key] == "enabled" ? true : false,
                  active: data[key] == "enabled" ? true : false,
                };
              }
            }

            break;
          case "Slot":
            console.log("Found Slot");
            for (key of Object.keys(data)) {
              //console.log(data[key]);
              if (key != "Parameter" && data[key] != "") {
                arrayIndex = Number(key) - 1;
                let temp = data[key].split(":");
                let constraint = temp[0];
                let slotName = temp[1];
                let slotType = temp[2];
                let prompt = temp[3];
                //capitalize the constarint ..
                //slotPriorities
                constraint =
                  constraint.charAt(0).toUpperCase() +
                  constraint.slice(1).toLowerCase();
                let currentPriority =
                  intents[arrayIndex]["slotPriorities"]?.length || 0;
                intents[arrayIndex]["slotPriorities"].push({
                  priority: currentPriority + 1,
                  slotName: slotName,
                });
                priority++; // increase the slot priority

                intents[arrayIndex]["slots"].push({
                  name: slotName,
                  slotType: slotType,
                  valueElicitationSetting: {
                    slotConstraint: constraint,
                    // sampleUtterances: [{ utterance: prompt }],
                    promptSpecification: {
                      messageGroups: [
                        {
                          message: {
                            plainTextMessage: {
                              value: prompt,
                            },
                          },
                        },
                      ],
                      maxRetries: 4,
                    },
                  },
                });
              }
            }

            break;

          case "SampleUtterance":
            console.log("Found SampleUtterance");
            for (key of Object.keys(data)) {
              // console.log(data[key]);
              if (key != "Parameter" && data[key] != "") {
                arrayIndex = Number(key) - 1;

                intents[arrayIndex]["sampleUtterances"].push({
                  utterance: data[key],
                });
              }
            }

            break;

          case "InputContexts":
            console.log("Found InputContexts");
            for (key of Object.keys(data)) {
              // console.log("InputContexts: ", data[key]);
              if (key != "Parameter" && data[key] != "") {
                let inputContextsList = data[key].split(",");
                arrayIndex = Number(key) - 1;
                for (const inputContext of inputContextsList) {
                  intents[arrayIndex]["inputContexts"].push({
                    name: inputContext.trim(),
                  });
                }
              }
            }
            break;
        }
      })
      .on("end", () => {
        // bot_details.bot_locales[locale].slot_types = getSlotTypeValues(
        //   headers,
        //   rows,
        //   locale
        // );
        // console.log(`The result`, JSON.stringify(intents, "", 2));
        resolve(intents);
      })

      .on("error", (err) => {
        reject(err);
      });
  });
}

function getSlots(input) {
  return [];
}

async function main() {
  try {
    for (locale of Object.keys(bot_details.bot_locales)) {
      let slotTypes = argv[`${locale}_slotTypes`];
      let intents = argv[`${locale}_intents`];
      let globalSlotTypes = argv[`${locale}_global_slotTypes`];
      let globalIntents = argv[`${locale}_global_intents`];

      if (bot_details.bot_locales[locale].enabled == true) {
        let globalSlotTypeArray = [];
        let globalIntentsArray = [];
        let slotTypeArray = [];
        let intentsArray = [];

        if (globalSlotTypes) {
          globalSlotTypeArray = await getSlotTypes(globalSlotTypes, locale);
        }
        if (globalIntents) {
          globalIntentsArray = await getIntents(globalIntents, locale);
        }

        slotTypeArray = await getSlotTypes(slotTypes, locale);
        intentsArray = await getIntents(intents, locale);

        bot_details.bot_locales[locale].slot_types = [
          ...globalSlotTypeArray,
          ...slotTypeArray,
        ];
        bot_details.bot_locales[locale].intents = [
          ...globalIntentsArray,
          ...intentsArray,
        ];
      }
    }

    for (locale of Object.keys(bot_details.bot_locales)) {
      if (bot_details.bot_locales[locale].enabled == true) {
        console.log(
          `=============Slot Type /Intent Utterances Summary for Locale ${locale}==========`
        );
        for (st of bot_details.bot_locales[locale].slot_types) {
          console.log(
            "SlotType Name :",
            st.name,
            " :Synonyms Count :",
            st.synonymsCount
          );
        }
        // Display the synonyms Count.

        for (intent of bot_details.bot_locales[locale].intents) {
          console.log(
            "Intent  Name :",
            intent.name,
            ":Sample Utterances Count :",
            intent.sampleUtterances.length
          );
        }
      }
    }
    console.log("========Duplicate Summary============");
    //Display the duplicate values which are omitted.
    for (locale of Object.keys(bot_details.bot_locales)) {
      if (bot_details.bot_locales[locale].enabled == true) {
        for (st of bot_details.bot_locales[locale].slot_types) {
          console.log(
            `${st.name} : duplicate Count : ${st.duplicates?.length}`
          );
        }
      }
    }
    console.log(`Look into ${outputFile} to verify the duplicate values...`);

    /// reset the uniqValues for each intent to reduce the size.

    for (st of bot_details.bot_locales.en_US.slot_types) {
      st.uniqValues = [];
    }

    for (locale of Object.keys(bot_details.bot_locales))
      fs.writeFileSync(outputFile, JSON.stringify(bot_details, "", 2));
  } catch (error) {
    console.error("An error occurred:", error);
  }
}

main();
