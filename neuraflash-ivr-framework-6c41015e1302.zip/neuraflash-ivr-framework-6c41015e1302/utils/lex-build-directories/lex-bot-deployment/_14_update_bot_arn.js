const yargs = require("yargs");

const { fromIni } = require("@aws-sdk/credential-providers");

const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");
const { getConfigFromFile } = (require("ts-node/register"), require("../../../config/config.ts"));
/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --region <region> --botDetailsFile <bot details file> --stage"
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string"
  })
  .option("profile", {
    describe: "AWS profile to be used in the API call.\n",
    demandOption: true,
    type: "string"
  })
  .option("botDetailsFile", {
    describe: "json file with bot details",
    demandOption: true,
    type: "string"
  })
  .option("stage", {
    describe: "environment stage like dev/perf/qa/prod/int",
    demandOption: true,
    type: "string"
  })

  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    } else if (typeof argv.botDetailsFile == "object" || !argv.botDetailsFile) {
      throw new Error("botDetails can not be empty or repeaed..");
    } else if (
      !["dev", "int", "perf", "prod", "qa", "test"].includes(argv.stage)
    ) {
      throw new Error(
        "stage parameter should be one of [dev,int,perf,prod,qa,test]"
      );
    }

    return true;
  }).argv;

const region = argv.region;
const stage = argv.stage;
const bot_details = require(argv.botDetailsFile);
let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}
console.log("Executing Script 14 ...");
// console.log("Profile and Argument Details: ",argv);

//const client = new ConnectClient(config);
// const sts_client = new STSClient(config);

const dbClient = new DynamoDBClient(config);
const baseConfig = getConfigFromFile(stage);

const tableBaseName = "config";
const tableName =
  baseConfig.clientPrefix + "-" + stage + "-" + region + "-" + tableBaseName;
console.log(`Updating lex ARN to dynamodb table "${tableName}" ...`);

lexArn =
  "arn:aws:lex:" +
  region +
  ":" +
  baseConfig.accountNumber +
  ":bot-alias/" +
  bot_details.bot_id +
  "/" +
  bot_details.alias_id;

botShortName = bot_details.bot_name_short;

async function update_arn(dbClient, item) {
  const input = item;
  // console.log(input);
  const command = new PutItemCommand(input);
  try {
    response = await dbClient.send(command);
    // console.log(response);
    // console.log("dynamodb successfully updated with lex-arn");
    return response;
  } catch (error) {
    console.log(error);
    process.exit(1);
  }

  return null;
}

// console.log(lexArn);
// console.log(botShortName);

const input = {
  TableName: tableName,
  Item: {
    Typing: {
      S: "arn"
    },
    Indexing: {
      S: "lex#" +  baseConfig.clientPrefix + "-" + stage + "-" + region + "-" + botShortName
    },
    arn: {
      S: lexArn
    }
  }
};

update_arn(dbClient, input);
