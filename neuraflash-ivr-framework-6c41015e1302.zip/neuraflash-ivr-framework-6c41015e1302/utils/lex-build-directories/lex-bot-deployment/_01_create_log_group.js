const yargs = require("yargs");
const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");
const { fromIni } = require("@aws-sdk/credential-providers");
const { IAMClient } = require("@aws-sdk/client-iam");
const { CloudWatchLogsClient } = require("@aws-sdk/client-cloudwatch-logs");
const {
  iam_create_role,
  iam_check_role_exists,
  iam_create_serviceLinkedPolicy,
} = require("../../sdk/iam_actions.js");
const { cw_create_log_group } = require("../../sdk/cloudwatch_actions.js")
const {
  delay,

} = require("../../sdk/bot_actions.js");
/**
 * process commandline arguments.
 */

const argv = yargs
  .usage(
    "\nUsage :  node $0  --profile <profile>  --region <region> --stage  <dev> --botDetailsFile <botDetailsFile>"
  )


  .option("profile", {
    describe: "AWS profile to be used.",
    demandOption: true,
    type: "string",
  })
  .option("stage", {
    describe: "AWS env argument : dev|uat|prod",
    demandOption: true,
    type: "string",
  })
  .option("region", {
    describe: "AWS region.",
    demandOption: true,
    type: "string",
  })
  .option("botDetailsFile", {
    describe: "botDetails File.",
    demandOption: true,
    type: "string",
  })
  .argv;
/**
 * end of yargs..
 */
console.log("Executing Script 1 ...");
console.log("Profile and Argument Details: ",argv);


const region = argv.region;
const profile = argv.profile;
const stage = argv.stage;
const bot_details = require(argv.botDetailsFile)

let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

const cw_client = new CloudWatchLogsClient(config)

// // create a role.
//step0 = iam_create_role(iam_client, role_details); // this will create a role ; if role is already existing it will return the arn.
// the return value is role_details with ARN filled in.

// console.log("Cloud Watch Log Group Name: ", bot_details.cw_log_group_name);

step0 = cw_create_log_group(cw_client, bot_details)
step1 = step0.then(async (res) => {
  // write the role info to role_details.com and bot_details.
  // console.log(`Returned Response Object :${JSON.stringify(res, "", 2)}`)
  bot_details.cw_log_group_arn = res[0].logGroupArn


  fs.writeFileSync(argv.botDetailsFile, JSON.stringify(bot_details, "", 2));
  await delay(5000)
  // console.log("==== Cloud Watch Log Group Creation completed====");

});
