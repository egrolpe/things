const yargs = require("yargs");
const fs = require("fs");
const { LexModelsV2Client } = require("@aws-sdk/client-lex-models-v2");
const path = require("path");
const { fromIni } = require("@aws-sdk/credential-providers");

const { delay, bot_create_slot } = require("../../sdk/bot_actions.js");
const { create } = require("domain");
/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --region <region> --botDetailsFile <bot details file>"
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string",
  })
  .option("profile", {
    describe: "AWS profile to be used in the API call.\n",
    demandOption: true,
    type: "string",
  })
  .option("botDetailsFile", {
    describe: "json file with bot details",
    demandOption: true,
    type: "string",
  })
  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    } else if (typeof argv.botDetailsFile == "object" || !argv.botDetailsFile) {
      throw new Error("botDetails can not be empty or repeaed..");
    }

    return true;
  }).argv;

const profile = argv.profile;
const region = argv.region;
const bot_details = require(argv.botDetailsFile);

let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

console.log("Executing Script 8 ...");
// console.log("Profile and Argument Details: ",argv);
const client = new LexModelsV2Client(config);

let count = 0;

function getSlotTypeID(bot_details, locale, slot_type) {
  // console.log(` inside getSlotTypeID : slotName: ${slot_type}`);
  if (slot_type.startsWith("AMAZON")) {
    return slot_type;
  }
  result = bot_details.bot_locales[locale].slot_types.filter(
    (obj) => obj.name === slot_type
  );

  return result[0].id;
}

async function main() {
  for (locale of Object.keys(bot_details.bot_locales)) {
    //run for english and spanish..
    if (!bot_details.bot_locales[locale].enabled) {
      console.log(`Locale ${locale} is not enabled `);
      break;
    }
    // console.log(locale);
    intents = bot_details.bot_locales[locale].intents; //intent array..
    if (intents == undefined || intents?.length == 0) {
      break; // if the locale does not contain any intents..
    }
    let new_intents = [];
    for (intent of intents) {
      // there could be multiple slots per intent.
      let new_slots = [];
      for (slot of intent.slots) {
        let slot_details = {
          slot_name: slot.name,
          intent_id: intent.id,
          valueElicitationSetting: slot.valueElicitationSetting,
          slot_type_id: getSlotTypeID(bot_details, locale, slot.slotType),
        };

        response = await bot_create_slot(
          client,
          bot_details,
          locale,
          slot_details
        );
        slot.id = response.slotId;
        new_slots.push(slot);
      }
      intent.slots = new_slots;
      new_intents.push(intent);
    }
    // new_intents.push(intent)
    bot_details.bot_locales[locale].intents = new_intents;
  }
  // bot_details.bot_locales[locale].intents = new_intents
  fs.writeFileSync(argv.botDetailsFile, JSON.stringify(bot_details, "", 2));
  return bot_details;
}

main();
