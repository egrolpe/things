const yargs = require("yargs");

const { fromIni } = require("@aws-sdk/credential-providers");

const {
  LambdaClient,
  AddPermissionCommand
} = require("@aws-sdk/client-lambda");
//const { updateLambdaPolicy } = require("../../sdk/lambda_actions_v2.js")

const { getConfigFromFile } = (require("ts-node/register"), require("../../config/config.ts"));

/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --region <region> --botDetailsFile <bot details file> --stage <stage>"
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string"
  })
  .option("profile", {
    describe: "AWS profile to be used in the API call.\n",
    demandOption: true,
    type: "string"
  })
  .option("botDetailsFile", {
    describe: "json file with bot details",
    demandOption: true,
    type: "string"
  })
  .option("stage", {
    describe: "environment stage like dev/perf/qa/prod/int",
    demandOption: true,
    type: "string"
  })

  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    } else if (typeof argv.botDetailsFile == "object" || !argv.botDetailsFile) {
      throw new Error("botDetails can not be empty or repeaed..");
    } else if (
      !["dev", "int", "perf", "prod", "qa", "test"].includes(argv.stage)
    ) {
      throw new Error(
        "stage parameter should be one of [dev,int,perf,prod,qa,test]"
      );
    }

    return true;
  }).argv;

const region = argv.region;
const stage = argv.stage;
const bot_details = require(argv.botDetailsFile);
const baseConfig = getConfigFromFile(stage);
const clientPrefix = baseConfig.clientPrefix;

let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

// create the lambda client.
const lambdaClient = new LambdaClient(config);

console.log("Executing Script 15 ...");
// console.log("Profile and Argument Details: ",argv);
console.log(`Updating Permission of Lambda function ... `);

//const client = new ConnectClient(config);
// const sts_client = new STSClient(config);

let lambdaArn =
  "arn:aws:lambda:" +
  region +
  ":" +
  baseConfig.accountNumber +
  ":function:" +
  bot_details.lambda_name
    .replace(":active", "")
    .replace("clientPrefix", clientPrefix)
    .replace("stage", stage)
    .replace("region", region);

let lexArn =
  "arn:aws:lex:" +
  region +
  ":" +
  baseConfig.accountNumber +
  ":bot-alias/" +
  bot_details.bot_id +
  "/" +
  bot_details.alias_id;

let params = {}; // create a object to send to update function.
params.FunctionName = lambdaArn;
params.Qualifier = "active";
params.StatementId =
  "lex-lambda-Invokefunction" +
  "-" +
  bot_details.bot_id +
  "-" +
  bot_details.alias_id;
params.Action = "lambda:InvokeFunction";
params.SourceArn = lexArn;
params.SourceAccount = baseConfig.accountNumber;

async function updateLambdaPolicy(lambdaClient, params) {
  const input = {
    Action: params.Action,
    FunctionName: params.FunctionName,
    Principal: "lexv2.amazonaws.com",
    Qualifier: params.Qualifier,
    SourceArn: params.SourceArn,
    StatementId: params.StatementId,
    SourceAccount: params.SourceAccount
  };
  // console.log(input);
  const command = new AddPermissionCommand(input);
  try {
    let response = await lambdaClient.send(command);
    // console.log(JSON.stringify(response, "", 2));
    console.log("Policy created succesfully..");
    return response;
  } catch (error) {
    // console.log("The Type of Error:", typeof (error))
    if (error.name == "ResourceConflictException") {
      console.log("Policy already Exists");
    }
  }

  return null;
}

updateLambdaPolicy(lambdaClient, params);
