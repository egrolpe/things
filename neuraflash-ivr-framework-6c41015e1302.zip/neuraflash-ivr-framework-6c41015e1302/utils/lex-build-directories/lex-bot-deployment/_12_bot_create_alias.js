const yargs = require("yargs");
const fs = require("fs");
const { LexModelsV2Client } = require("@aws-sdk/client-lex-models-v2");
const path = require("path");
const { fromIni } = require("@aws-sdk/credential-providers");
const { sts_get_account_number } = require("../../sdk/iam_actions");

const {
  delay,

  bot_create_alias,
  bot_describe_alias
} = require("../../sdk/bot_actions.js");
const { create } = require("domain");
const internal = require("stream");
const { STSClient } = require("@aws-sdk/client-sts");
const { getConfigFromFile } = (require("ts-node/register"), require("../../config/config.ts"));
/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --stage<stage> --region <region> --botDetailsFile <bot details file> "
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string"
  })
  .option("profile", {
    describe: "AWS profile to be used in the API call.\n",
    demandOption: true,
    type: "string"
  })
  .option("botDetailsFile", {
    describe: "json file with bot details",
    demandOption: true,
    type: "string"
  })
  .option("stage", {
    describe: "environment in which to deploy this",
    demandOption: true,
    type: "string"
  })

  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    } else if (typeof argv.botDetailsFile == "object" || !argv.botDetailsFile) {
      throw new Error("botDetails can not be empty or repeaed..");
    }

    return true;
  }).argv;

const profile = argv.profile;
const region = argv.region;
const bot_details = require(argv.botDetailsFile);
const stage = argv.stage;

let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

const clientPrefix = getConfigFromFile(stage).clientPrefix;

console.log("Executing Script 12 ...");
// console.log("Profile and Argument Details: ",argv);
const client = new LexModelsV2Client(config);
const sts_client = new STSClient(config);

let count = 0;

count = 0;
/**
 *  Function to create a alias.
 */
async function create_alias() {
  const botAliasLocaleSettings = {};
  // build the lambda arn from the function name.
  const aws_account = await sts_get_account_number(sts_client);
  const lambda_name = bot_details.lambda_name
    .replace("clientPrefix", clientPrefix)
    .replace("stage", stage)
    .replace("region", region);
  // lambda_arn": "arn:aws:lambda:us-west-2:863174409786:function:codeHook",
  lambda_arn =
    "arn:aws:lambda:" + region + ":" + aws_account + ":function:" + lambda_name;

  // console.log(`lambdaARN is : ${lambda_arn}`);

  for (locale of Object.keys(bot_details.bot_locales)) {
    if (!bot_details.bot_locales[locale].enabled) {
      console.log(`locale ${locale} not enabled for provisioning..`);
      break;
    }

    botAliasLocaleSettings[locale] = {
      enabled: true,
      codeHookSpecification: {
        lambdaCodeHook: {
          lambdaARN: lambda_arn,
          codeHookInterfaceVersion: "1.0"
        }
      }
    };
  }
  // console.log(
  //   `botAliasLocaleSettings : ${JSON.stringify(botAliasLocaleSettings, "", 2)}`
  // );
  bot_details.botAliasLocaleSettings = botAliasLocaleSettings;
  // add conversation log setting.
  const conversationLogSettings = {
    textLogSettings: [
      {
        enabled: true,
        destination: {
          cloudWatch: {
            cloudWatchLogGroupArn: bot_details.cw_log_group_arn,
            logPrefix: bot_details.bot_name.replace(
              "clientPrefix-stage-region-",
              ""
            )
          }
        }
      }
    ]
  };

  bot_details.conversationLogSettings = conversationLogSettings;

  bot_details.bot_alias = bot_details.bot_alias || "active";

  response = await bot_create_alias(client, bot_details);
  // console.log(response);
  bot_details.alias_id = response.botAliasId;
  fs.writeFileSync(argv.botDetailsFile, JSON.stringify(bot_details, "", 2));
  await delay(10000); // give 10 seconds to create version...
}

step1 = new Promise(async (resolve, reject) => {
  const sts_client = new STSClient(config);
  account = await sts_get_account_number(sts_client);
  // console.log(account);
  resolve(account);
});

step1.then((res) => {
  create_alias();
});
