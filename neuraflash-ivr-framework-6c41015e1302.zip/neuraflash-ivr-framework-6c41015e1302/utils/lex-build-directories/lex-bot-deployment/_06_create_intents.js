const yargs = require("yargs");
const fs = require("fs");
const { LexModelsV2Client } = require("@aws-sdk/client-lex-models-v2");
const path = require("path");
const { fromIni } = require("@aws-sdk/credential-providers");

const { delay, bot_create_intent } = require("../../sdk/bot_actions.js");
/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --region <region> --botDetailsFile <bot details file>"
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string",
  })
  .option("profile", {
    describe: "AWS profile to be used in the API call.\n",
    demandOption: true,
    type: "string",
  })
  .option("botDetailsFile", {
    describe: "json file with bot details",
    demandOption: true,
    type: "string",
  })
  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    } else if (typeof argv.botDetailsFile == "object" || !argv.botDetailsFile) {
      throw new Error("botDetails can not be empty or repeaed..");
    }

    return true;
  }).argv;

const profile = argv.profile;
const region = argv.region;
const bot_details = require(argv.botDetailsFile);
let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

console.log("Executing Script 6 ...");
// console.log("Profile and Argument Details: ",argv);
const client = new LexModelsV2Client(config);

count = 0;
const create_intents = async (client, bot_details, locale) => {
  let intent_info = [];
  console.log("Intent creation started for \"" + locale + "\" locale ...");
  // function created to iterate over intents.
  const intents = bot_details.bot_locales[locale].intents;
  for (const intent of intents) {
    // console.log(`========iteration${count++}=======`);
    // console.log(intent);
    // let intent_details = intent
    response = await bot_create_intent(client, bot_details, locale, intent);
    (intent.id = response.intentId), intent_info.push(intent);
    // console.log("bot_create_intent response", JSON.stringify(response, "", 2));
  }
  // console.log("intent_info: ",JSON.stringify(intent_info, "", 2));
  bot_details.bot_locales[locale].intents = intent_info;
  return bot_details;
};

async function main() {
  // if (bot_details.bot_locales["en_US"].intents?.length > 0) {
  //   await create_intents(client, bot_details, "en_US");
  // }
  // if (bot_details.bot_locales["es_US"].intents?.length > 0) {
  //   await create_intents(client, bot_details, "es_US");
  // }
  for (locale of Object.keys(bot_details.bot_locales)) {
    if (!bot_details.bot_locales[locale].enabled) {
      console.log(`locale ${locale} is not enabled for provisioning..`);
      break;
    } else {
      // console.log(`======creating ${locale}========`);
      await create_intents(client, bot_details, locale);
      // console.log(`Created Intents for ${locale}`);
    }
  }
  await delay(5000);
  fs.writeFileSync(argv.botDetailsFile, JSON.stringify(bot_details, "", 2));
}

main();
