const yargs = require("yargs");
const fs = require("fs");
const { LexModelsV2Client } = require("@aws-sdk/client-lex-models-v2");
const path = require("path");
const { fromIni } = require("@aws-sdk/credential-providers");

const {
  delay,
  bot_create_slot,
  bot_update_intent,
  bot_build_locale,
  bot_describe_locale,
} = require("../../sdk/bot_actions.js");
const { create } = require("domain");
const internal = require("stream");
/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --region <region> --botDetailsFile <bot details file>"
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string",
  })
  .option("profile", {
    describe: "AWS profile to be used in the API call.\n",
    demandOption: true,
    type: "string",
  })
  .option("botDetailsFile", {
    describe: "json file with bot details",
    demandOption: true,
    type: "string",
  })
  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    } else if (typeof argv.botDetailsFile == "object" || !argv.botDetailsFile) {
      throw new Error("botDetails can not be empty or repeaed..");
    }

    return true;
  }).argv;

const profile = argv.profile;
const region = argv.region;
const bot_details = require(argv.botDetailsFile);
let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

console.log("Executing Script 10 ...");
// console.log(argv.profile);
// console.log("Profile and Argument Details: ",argv);
const client = new LexModelsV2Client(config);

let count = 0;

count = 0;

async function build_locale() {
  // let new_intents = []
  for (locale of Object.keys(bot_details.bot_locales)) {
    if (!bot_details.bot_locales[locale].enabled) {
      console.log(`locale ${locale} not enabled for provisioning..`);
      break;
    }
    //run for english and spanish..
    // console.log(`building ${locale}`);

    response = await bot_build_locale(client, bot_details, locale);
    // console.log(response);
  }
  // wait till bot becomes available state..

  // console.log("Checking bot Locales...");
  const max_count = 30; //max wait time is 5 mins...
  let it_count = 0;
  const milli_seconds = 10000; // to be used in delay function..

  for (locale of Object.keys(bot_details.bot_locales)) {
    if (!bot_details.bot_locales[locale].enabled) {
      console.log(`locale ${locale} not enabled for provisioning..`);
      break;
    } //run for english and spanish..
    locale_status = "";
    // console.log(`checking status of.. ${locale}`);

    while (locale_status !== "Built") {
      response = await bot_describe_locale(client, bot_details, locale);
      locale_status = response.botLocaleStatus;
      // console.log(`Current status of ${locale} : ${locale_status}`);
      if (locale_status == "Failed" || it_count > 30) {
        console.log(
          `locale Build failed for ${locale} or exceeded max wait time`
        );
        throw "Locale build failed.. correct manually and rerun...";
      }
      it_count++;
      await delay(milli_seconds);
    }
    // console.log(`${locale} successfully built....`);
  }
}

build_locale();
