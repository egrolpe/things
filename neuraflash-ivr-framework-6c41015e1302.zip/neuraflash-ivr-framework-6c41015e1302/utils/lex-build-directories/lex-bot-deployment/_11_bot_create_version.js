const yargs = require("yargs");
const fs = require("fs");
const { LexModelsV2Client } = require("@aws-sdk/client-lex-models-v2");
const path = require("path");
const { fromIni } = require("@aws-sdk/credential-providers");

const {
  delay,
  bot_create_slot,
  bot_update_intent,
  bot_build_locale,
  bot_describe_locale,
  bot_create_version,
} = require("../../sdk/bot_actions.js");
const { create } = require("domain");
const internal = require("stream");
/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --region <region> --botDetailsFile <bot details file>"
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string",
  })
  .option("profile", {
    describe: "AWS profile to be used in the API call.\n",
    demandOption: true,
    type: "string",
  })
  .option("botDetailsFile", {
    describe: "json file with bot details",
    demandOption: true,
    type: "string",
  })
  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    } else if (typeof argv.botDetailsFile == "object" || !argv.botDetailsFile) {
      throw new Error("botDetails can not be empty or repeaed..");
    }

    return true;
  }).argv;

const profile = argv.profile;
const region = argv.region;
const bot_details = require(argv.botDetailsFile);
let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}
console.log("Executing Script 11 ...");
// console.log("Profile and Argument Details: ",argv);
const client = new LexModelsV2Client(config);

let count = 0;

count = 0;

async function create_version() {
  // let new_intents = []
  const botVersionLocaleSpecification = {};
  for (locale of Object.keys(bot_details.bot_locales)) {
    if (!bot_details.bot_locales[locale].enabled) {
      // if locale is not enabled in bot_details.json dont add it.
      console.log(`locale ${locale} not enabled for provisioning..`);
      break;
    }
    botVersionLocaleSpecification[locale] = {
      sourceBotVersion: "DRAFT",
    };
  }
  // console.log(
  //   `botVersionLocaleSpecification : ${JSON.stringify(
  //     botVersionLocaleSpecification,
  //     "",
  //     2
  //   )}`
  // );
  bot_details.botVersionLocaleSpecification = botVersionLocaleSpecification;
  response = await bot_create_version(client, bot_details);
  // console.log(response);
  bot_details.bot_version = response.botVersion;
  // write this to bot_details

  fs.writeFileSync(argv.botDetailsFile, JSON.stringify(bot_details, "", 2));
  await delay(10000); // give 10 seconds to create version...
}

create_version();
