#!/bin/bash
node generate_bot_details_v2.js --botTemplate "./bot_template_sample.json"  \
--en_US_slotTypes "../lex-csv/values-bot/en_slotTypes.csv"  \
--en_US_intents "../lex-csv/values-bot/en_intents.csv"  \
--es_US_slotTypes "../lex-csv/values-bot/es_slotTypes.csv"  \
--es_US_intents "../lex-csv/values-bot/es_intents.csv"  \
--outputFile './bot_details_new.json'
