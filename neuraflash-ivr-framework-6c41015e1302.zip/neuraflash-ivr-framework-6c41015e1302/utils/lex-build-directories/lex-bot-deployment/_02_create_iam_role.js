const yargs = require("yargs");
const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");
const { fromIni } = require("@aws-sdk/credential-providers");
const { IAMClient } = require("@aws-sdk/client-iam");
const {
  iam_create_role
} = require("../../sdk/iam_actions.js");
const { delay } = require("../../sdk/bot_actions.js");
const { getConfigFromFile } = (require("ts-node/register"), require("../../../config/config.ts"));
/**
 * process commandline arguments.
 */

const argv = yargs
  .usage(
    "\nUsage :  node $0 --roleDetailsFile <role template json file>  --botDetailsFile <bot details json file> --profile <profile> --stage <dev>"
  )
  .option("roleDetailsFile", {
    describe: "role template file to create a LexRole",
    demandOption: true,
    type: "string"
  })
  .option("botDetailsFile", {
    describe: "bot details json file to update the role arn.",
    demandOption: true,
    type: "string"
  })
  .option("profile", {
    describe: "AWS profile to be used.",
    demandOption: true,
    type: "string"
  })
  .option("stage", {
    describe: "AWS env argument : dev|uat|prod",
    demandOption: true,
    type: "string"
  })
  .option("region", {
    describe: "AWS region.",
    demandOption: true,
    type: "string"
  })

  .check((argv) => {
    if (!argv.roleDetailsFile && !argv.botDetailsFile) {
      throw new Error("role detail and bot detail files are required.");
    }

    return true;
  }).argv;
/**
 * end of yargs..
 */
console.log("Executing Script 2...");
// console.log("Profile and Argument Details: ",argv);

const bot_details = require(argv.botDetailsFile);
const role_details = require(argv.roleDetailsFile);

const region = argv.region;
const profile = argv.profile;
const stage = argv.stage;

let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

// role_details.serviceName = "lexv2.amazonaws.com"
// role_details.CustomSuffix = role_details.CustomSuffix.replace("stage", stage)
// console.log(role_details.role_name);

const clientPrefix = getConfigFromFile(stage).clientPrefix;

const iam_client = new IAMClient(config);
botShortName = bot_details.bot_name_short;
role_details.role_name =
  role_details.role_name
    .replace("clientPrefix", clientPrefix)
    .replace("stage", stage)
    .replace("region", region) + botShortName;
role_details.policy_name =
  role_details.policy_name
    .replace("clientPrefix", clientPrefix)
    .replace("stage", stage)
    .replace("region", region) + botShortName;

// update the policy with CloudWatch ARNS.
role_details.policy_document.Statement[1].Resource = [
  bot_details.cw_log_group_arn + ":*"
];

// // create a role.
step0 = iam_create_role(iam_client, role_details); // this will create a role ; if role is already existing it will return the arn.
// the return value is role_details with ARN filled in.

//step0 = iam_create_serviceLinkedPolicy(iam_client, role_details)
step1 = step0.then(async (res) => {
  // write the role info to role_details.com and bot_details.
  // console.log(`Returned Response Object :${JSON.stringify(res, "", 2)}`)
  fs.writeFileSync(
    "role_details_output.json",
    JSON.stringify(role_details, "", 2)
  );
  bot_details.role_arn = role_details.role_arn;
  fs.writeFileSync(argv.botDetailsFile, JSON.stringify(bot_details, "", 2));
  await delay(5000);
  // console.log("==== Role Creation completed====");
});
