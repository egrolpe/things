#!/bin/bash
#This script create the bot ; requires following options.
# profile : aws profile to connect to AWS.
# region  : region where the bot needs to be created.
# botDetails file : json config file containing bot details.like bot name etc.
# roleDetilsFile : a json file with role which lex bot assumes as execution role.
# stage : Environment like dev/uat/prod 
# echo "Usage : $0 --profile <profile> --region <region> --botDetailsFile <jsonfile> --roleDetailsFile <jsonfile> --stage <dev|stage|uat|prod>"
        #  ;;
start=$(date +%s)

while [ $# -gt 0 ] ; do
   key=$1
   shift;
    case $key in 
    --botDetailsFile)
     echo " we found botDetailsFile flag"
     if [ $# -lt 1 ] ; then
        echo "error: -botDetailsFile needs a value"./
     else 
        botDetailsFile=$1
        shift
    fi
    ;;
     --profile)
    echo " we found profile flag"
     if [ $# -lt 1 ] ; then
        echo "error: -profile needs a value"
     else 
        profile=$1
        shift
    fi
    ;;
    --roleDetailsFile)
    echo " we found roleDetailsFile flag"
     if [ $# -lt 1 ] ; then
        echo "error: -roleDetailsFile needs a value"
     else 
        roleDetailsFile=$1
        shift
    fi
    ;;
     --stage)
    echo " we found stage flag"
     if [ $# -lt 1 ] ; then
        echo "error: -stage needs a value"
     else 
        stage=$1
        shift
    fi
    ;;
     --region)
    echo " we found region flag"
     if [ $# -lt 1 ] ; then
        echo "error: -region needs a value"
     else 
        region=$1
        shift
    fi
    ;;

    --help)
    echo " we found something else"
    echo "Usage : $0 --profile <profile> --region <region> --botDetailsFile <jsonfile> --roleDetailsFile <jsonfile> --stage <dev|stage|uat|prod>"
         ;;
    esac
done


echo "$stage"
echo "$roleDetailsFile"
echo "$botDetailsFile"
echo "$profile"
echo "$region"

# check if every value is populated..

if [ "$stage" != "" ] && [ "$roleDetailsFile" != "" ] && [ "$botDetailsFile" != "" ] && [ "$region" != "" ] ;
 then
echo "Got all params continuing with scripts..."
else 
echo "Usage : $0 --profile <profile> --region <region> --botDetailsFile <jsonfile> --roleDetailsFile <jsonfile> --stage <dev|stage|uat|prod>"
exit 1
fi
 
# # create log groups...

node _01_create_log_group.js --roleDetailsFile "$roleDetailsFile"  \
--botDetailsFile "$botDetailsFile"  \
--region "$region" --profile "$profile" \
--stage "$stage"

status=$?
if [ "$status" -eq 0 ] 
then
# create role 
node _02_create_iam_role.js \
--botDetailsFile "$botDetailsFile" \
--roleDetailsFile "$roleDetailsFile" \
--region "$region" \
--profile "$profile" \
--stage "$stage"
else 
 echo $status
 echo " Error in Create Log Group" 
 exit 1
fi



status=$?
if [ "$status" -eq 0 ] 
then
# #create bot...
node _03_create_lex_bot.js  \
--botDetailsFile "$botDetailsFile" \
--region "$region" \
--profile "$profile" \
--stage "$stage"
else 
 echo $status
 echo " Error in create Role" 
 exit 1
fi

# # create locale..
status=$?
if [ "$status" -eq 0 ] 
then
node _04_create_locale.js  \
--botDetailsFile "$botDetailsFile" \
--region "$region" \
--profile "$profile"

else 
 echo " Error in Create Bot" 
 exit 1
fi

# # #create slot Types

status=$?
if [ "$status" -eq 0 ] 
then
node _05_create_slot_types.js  \
--botDetailsFile "$botDetailsFile" \
--region "$region" \
--profile "$profile"
else 
 echo " Error in Create Locale" 
 exit 1
fi
 
# #Creating intents

status=$?
if [ "$status" -eq 0 ] 
then
node _06_create_intents.js  \
--botDetailsFile "$botDetailsFile" \
--region "$region"  \
--profile "$profile" \
--stage "$stage"
else 
 echo " Error in Create SlotTypes" 
 exit 1
fi

## updating fallback intent..
status=$?
if [ "$status" -eq 0 ] 
then
node _07_update_fallback_intent.js  \
--botDetailsFile "$botDetailsFile" \
--region "$region"  \
--profile "$profile" \
--stage "$stage"
else 
 echo " Error in Create Intents" 
 exit 1
fi


# # # ##Creating slots...
status=$?
if [ "$status" -eq 0 ] ;
then
echo "Beginning Creating Slots"
node _08_create_slots.js \
--botDetailsFile "$botDetailsFile" \
--region "$region"  \
--profile "$profile" \
--stage "$stage"
else 
 echo " Error in update Fallback Intent" 
 exit 1
fi

status=$?
# #update sample utterances on each intent....

if [ "$status" -eq 0 ] ;
then
node _09_update_sample_utterance.js \
--botDetailsFile "$botDetailsFile" \
--region "$region"  \
--profile "$profile" \
--stage "$stage"
else 
 echo " Error in update sample utterances bot" 
 exit 1
fi

status=$?
# #Build both Languages..
if [ "$status" -eq 0 ] ;
then
node _10_build_locales.js \
--botDetailsFile "$botDetailsFile" \
--region "$region"  \
--profile "$profile" \
--stage "$stage"
else 
 echo " Error in build bot locales" 
 exit 1
fi
status=$?
# #build botVersion...
if [ "$status" -eq 0 ] ;
then
node _11_bot_create_version.js \
--botDetailsFile "$botDetailsFile" \
--region "$region"  \
--profile "$profile" \
--stage "$stage"

else 
 echo " Error in Create bot version" 
 exit 1
fi

status=$?
# #create alias..
if [ "$status" -eq 0 ] ;
then
node _12_bot_create_alias.js \
--botDetailsFile "$botDetailsFile" \
--region "$region"  \
--profile "$profile" \
--stage "$stage"
else 
 echo " Error in Create bot alias" 
 exit 1
fi

status=$?
# #associate alias with connect..
if [ "$status" -eq 0 ] ;
then
node _13_connect_associate_bot.js \
--botDetailsFile "$botDetailsFile" \
--region "$region"  \
--profile "$profile" \
--stage "$stage"

else 
 echo "Error while associating the bot with Connect." 
 exit 1
fi

status=$?
# #update the dynamodb
if [ "$status" -eq 0 ] ;
then
node _14_update_bot_arn.js \
--botDetailsFile "$botDetailsFile" \
--region "$region"  \
--profile "$profile" \
--stage "$stage"

else 
 echo " Error while updating dynamoDB." 
 exit 1
fi

#script13_update_Lambda_Permission.js

if [ "$status" -eq 0 ] ;
then
node _15_update_lambda_permission.js \
--botDetailsFile "$botDetailsFile" \
--region "$region"  \
--profile "$profile" \
--stage "$stage"

else 
 echo " Error while updating lambda permissions." 
 exit 1
fi
######

if [ "$status" -eq 0 ] ;
then 
echo "Script completed succesfully"
else
echo "Error while updating resource policy"
fi

end=$(date +%s)
echo "Elapsed time is : $((end-start)) seconds"