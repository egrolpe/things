const yargs = require("yargs");
const { fromIni } = require("@aws-sdk/credential-providers");
const { STSClient } = require("@aws-sdk/client-sts");
const { sts_get_account_number } = require("../../sdk/iam_actions");
const { ConnectClient } = require("@aws-sdk/client-connect");
const { connect_associate_bot } = require("../../sdk/bot_actions.js");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../../config/config.ts"));
/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --region <region> --botDetailsFile <bot details file>"
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string"
  })
  .option("profile", {
    describe: "AWS profile to be used in the API call.\n",
    demandOption: true,
    type: "string"
  })
  .option("botDetailsFile", {
    describe: "json file with bot details",
    demandOption: true,
    type: "string"
  })
  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    } else if (typeof argv.botDetailsFile == "object" || !argv.botDetailsFile) {
      throw new Error("botDetails can not be empty or repeaed..");
    }

    return true;
  }).argv;

const region = argv.region;
const stage = argv.stage;
const bot_details = require(argv.botDetailsFile);

let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

console.log("Executing Script 13 ...");
// console.log("Profile and Argument Details: ",argv);
const client = new ConnectClient(config);
const sts_client = new STSClient(config);

bot_details.connect_id = getConnectInstanceId(stage, region)

async function asscociate_bot() {
  aws_account = await sts_get_account_number(sts_client);
  // console.log(`response` + JSON.stringify(aws_account));
  //build lex arn prefix
  lex_arn =
    "arn:aws:lex:" +
    region +
    ":" +
    aws_account +
    ":bot-alias/" +
    bot_details.bot_id +
    "/" +
    bot_details.alias_id;

  // console.log(lex_arn);
  bot_details.lex_arn = lex_arn;
  response = await connect_associate_bot(client, bot_details);
  // console.log("=========response=========");
  // console.log(JSON.stringify(response, "", 2));

  return response;
}

asscociate_bot();
