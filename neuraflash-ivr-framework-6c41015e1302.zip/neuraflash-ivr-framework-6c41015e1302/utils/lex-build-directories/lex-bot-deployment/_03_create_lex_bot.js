const yargs = require("yargs");
const fs = require("fs");
const { LexModelsV2Client } = require("@aws-sdk/client-lex-models-v2");
const { IAMClient } = require("@aws-sdk/client-iam");
const { STSClient } = require("@aws-sdk/client-sts");
const path = require("path");
const { fromIni } = require("@aws-sdk/credential-providers");

const {
  delay,
  bot_create_new,
  bot_add_tags
} = require("../../sdk/bot_actions.js");
const { sts_get_account_number } = require("../../sdk/iam_actions.js");
const { getConfigFromFile } = (require("ts-node/register"), require("../../../config/config.ts"));

/**
 * profile and region are mandatory
 */
const argv = yargs
  .usage(
    "\nUsage :  node $0 --profile <profile> --region <region> --stage <stage> --botDetailsFile <botDetails file>"
  )
  .option("region", {
    describe: "AWS region where bot needs to be created in.",
    demandOption: true,
    type: "string"
  })
  .option("stage", {
    describe: "AWS stage where bot needs to be created in.",
    demandOption: true,
    type: "string"
  })
  .option("profile", {
    describe:
      "AWS profile to be used in the API call. This is where resources will be created.\n",
    demandOption: true,
    type: "string"
  })
  .option("botDetailsFile", {
    describe: "json file containing bot details to be created.",
    demandOption: true,
    type: "string"
  })
  .check((argv) => {
    if (!argv.region || typeof argv.region == "object") {
      throw new Error("region  can not be empty or repeated..");
    }

    return true;
  }).argv;

console.log("Executing Script 3...");
// console.log("Profile and Argument Details: ",argv);

const profile = argv.profile;
const region = argv.region;
const bot_details = require(argv.botDetailsFile);
const stage = argv.stage;

let config = { region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
  console.log("config: ", config);
}

// console.log("Beginning. bot Creating.. aws profile is :", profile);
// console.log("And region :", region);

const clientPrefix = getConfigFromFile(stage).clientPrefix;

// replace the stage and region in the bot name.
bot_details.bot_name =
  bot_details.bot_prefix
    .replace("clientPrefix", clientPrefix)
    .replace("stage", stage)
    .replace("region", region) + bot_details.bot_name_short;

// console.log(`botName: ${bot_details.bot_name}`);

const client = new LexModelsV2Client(config);
//const iamClient = new IAMClient(config)
const sts_client = new STSClient(config);

step1 = bot_create_new(client, bot_details);

step2 = step1.then((res) => {
  // console.log(res);
  //bot is created ; typically its in "Creating status"
  bot_details.bot_id = res.bot_id; // now bot_details has the bot ID. Write it intermittently.
  fs.writeFileSync(argv.botDetailsFile, JSON.stringify(bot_details, "", 2));
  return res;
});

// ****DEPRECATED**** config no longer includes tags, step to add tags is skipped
// wait for 10 seconds to bot to be created and in available state.
// step3 = step2.then(async (res) => {
//   wait = await delay(8000);
//   try {
//     accountNumber = await sts_get_account_number(sts_client);
//     resourceARN =
//       "arn:aws:lex:" +
//       region +
//       ":" +
//       accountNumber +
//       ":bot/" +
//       bot_details.bot_id;
//     // console.log("bot resourceARN:" + resourceARN)
//     bot_details.tags = baseConfig.tags;

//     let response = await bot_add_tags(client, bot_details, resourceARN);
//     // console.log("Added Tags to the Bot")
//     // console.log(JSON.stringify(response, "", 2))
//     // console.log("...Done....'");
//     return;
//   } catch (error) {
//     console.log("Error adding Tags...");
//     throw error;
//   }
// });
