let region = "";
let stackPrefix = "Neuraflashdev";
let tablePrefix = "Neuraflash-dev-";
let tableSuffix = "-config";
const BATCH_SIZE = 25;

// these variables are usually more static
const SCV_BYOA_STACK_SUFFIX = "SCVBYOAContactCenterStack";
const SCV_BUNDLE_STACK_SUFFIX = "SCVContactCenterStack";

const {
  DynamoDBClient,
  BatchWriteItemCommand,
} = require("@aws-sdk/client-dynamodb");
const {
  CloudFormationClient,
  ListStacksCommand,
  ListExportsCommand,
  DescribeStacksCommand,
} = require("@aws-sdk/client-cloudformation");
const { fromIni } = require("@aws-sdk/credential-providers");

// parse command line arguments using yargs
const argv = require("yargs/yargs")(process.argv.slice(2))
  .usage(
    "Usage: $0 [--profile [profile] --region [region] --stackPrefix [stackPrefix] --tablePrefix [tablePrefix] --tableSuffix [tableSuffix]]"
  )
  .demandOption([])
  .describe("profile", "Optionally specify AWS profile")
  .describe("region", "Optionally specify AWS region")
  .describe("stackPrefix", "Optionally spcify a stack prefix")
  .describe("tablePrefix", "Optionally spcify a table prefix")
  .describe("tableSuffix", "Optionally spcify a table suffix").argv;

if (argv.region) {
  region = argv.region;
}
if (argv.stackPrefix) {
  stackPrefix = argv.stackPrefix;
}
if (argv.tablePrefix) {
  tablePrefix = argv.tablePrefix;
}
if (argv.tableSuffix) {
  tableSuffix = argv.tableSuffix;
}
// set AWS SDK configuration
let config = { region: region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}

function convertCdkOutputNameToConfigEntry(inputName) {
  return inputName
    .replace("arn-", "arn#")
    .replace("-", "#")
    .replaceAll("-", "_"); //converts to arn#[objtype]#everything_else_is_like_this
}

function convertCamelCaseToSnakeCase(input) {
  return input
    .replace(/([a-z])([A-Z])/g, "$1_$2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1_$2")
    .toLowerCase();
}

(async () => {
  const dynamoClient = new DynamoDBClient(config);
  const stackClient = new CloudFormationClient(config);
  let nextToken = null;

  //#region find custom stack
  try {
    //#region Find the stack
    const allStacks = [];
    nextToken = null;
    do {
      const command = new ListStacksCommand({
        StackStatusFilter: [
          "CREATE_COMPLETE",
          "ROLLBACK_COMPLETE",
          "UPDATE_COMPLETE",
          "UPDATE_ROLLBACK_COMPLETE",
          "IMPORT_COMPLETE",
          "IMPORT_ROLLBACK_COMPLETE",
        ],
        NextToken: nextToken,
      });
      const {
        StackSummaries: responseStackSummaries,
        NextToken: responseNextToken,
      } = await stackClient.send(command);

      allStacks.push(...responseStackSummaries);
      nextToken = responseNextToken;
    } while (nextToken);
    let stackId = allStacks.find((element) =>
      element?.StackName.startsWith(stackPrefix)
    ).StackId; //Find first stack that matches criteria
    //#endregion

    //#region Get all exports
    const allStacksExports = [];
    nextToken = null;
    do {
      const command = new ListExportsCommand({
        NextToken: nextToken,
      });
      const { Exports: responseExports, NextToken: responseNextToken } =
        await stackClient.send(command);

      allStacksExports.push(...responseExports);
      nextToken = responseNextToken;
    } while (nextToken);

    let stackExports = allStacksExports.filter(
      (element) => element.ExportingStackId === stackId
    );
    //#endregion

    //#region Write exports to DynamoDB
    const itemsToWriteToDynamo = stackExports.map((element) => {
      return {
        Typing: { S: "arn" },
        Indexing: { S: convertCdkOutputNameToConfigEntry(element.Name) },
        arn: { S: element.Value },
      };
    });

    const batches = [];
    for (let i = 0; i < itemsToWriteToDynamo.length; i += BATCH_SIZE) {
      // split the items into batches of BATCH_SIZE
      batches.push(itemsToWriteToDynamo.slice(i, i + BATCH_SIZE));
    }

    for (const batch of batches) {
      const putRequests = batch.map((item) => {
        return { PutRequest: { Item: item } };
      });
      const command = new BatchWriteItemCommand({
        RequestItems: {
          [`${tablePrefix}${region}${tableSuffix}`]: putRequests,
        },
      });
      // batchWriteItemCommand to DynamoDB logging the results
      results = await dynamoClient.send(command);
      console.log(results);
    }
    console.log(`✅ Region: ${region} updated with custom stack`);
    //#endregion
  } catch (err) {
    console.log(err);
  }
  //#endregion

  //#region find BYOA or bundle stack
  try {
    //#region Find the stack
    const allStacks = [];
    nextToken = null;
    do {
      const command = new ListStacksCommand({
        StackStatusFilter: [
          "CREATE_COMPLETE",
          "ROLLBACK_COMPLETE",
          "UPDATE_COMPLETE",
          "UPDATE_ROLLBACK_COMPLETE",
          "IMPORT_COMPLETE",
          "IMPORT_ROLLBACK_COMPLETE",
        ],
        NextToken: nextToken,
      });
      const {
        StackSummaries: responseStackSummaries,
        NextToken: responseNextToken,
      } = await stackClient.send(command);

      allStacks.push(...responseStackSummaries);
      nextToken = responseNextToken;
    } while (nextToken);
    let stackId = allStacks.find(
      (element) =>
        element?.StackName.endsWith(SCV_BYOA_STACK_SUFFIX) ||
        element?.StackName.endsWith(SCV_BUNDLE_STACK_SUFFIX)
    ).StackId; //Find first stack that matches criteria
    let stackName = allStacks.find(
      (element) =>
        element?.StackName.endsWith(SCV_BYOA_STACK_SUFFIX) ||
        element?.StackName.endsWith(SCV_BUNDLE_STACK_SUFFIX)
    ).StackName; //Find first stack that matches criteria
    //#endregion

    //#region Get all outputs of the stack
    const stackDescriptions = [];
    nextToken = null;
    do {
      const command = new DescribeStacksCommand({
        StackName: stackName,
        NextToken: nextToken,
      });
      const { Stacks: responseExports, NextToken: responseNextToken } =
        await stackClient.send(command);

      stackDescriptions.push(...responseExports);
      nextToken = responseNextToken;
    } while (nextToken);

    let stackOutputs = stackDescriptions.filter(
      (element) => element.StackId === stackId
    )?.[0]?.Outputs;
    //#endregion

    //#region Write exports to DynamoDB
    const itemsToWriteToDynamo = stackOutputs.reduce((accumulator, element) => {
      if (element.OutputValue.startsWith("arn:aws:")) {
        //only write outputs that have values that are arns. Can add more criteria here if you want to only write entries that are lambdas, iam, tables, etc.
        const arnType = element.OutputValue.split(":")[2];
        let arn = element.OutputValue;
        if (arnType === "lambda" && !element.OutputKey.endsWith(":active")) {
          //if the current item is a lambda and the arn does not end in :active, add it
          arn += ":active";
        }
        accumulator.push({
          Typing: { S: "arn" },
          Indexing: {
            S: `arn#${arnType}#${convertCamelCaseToSnakeCase(
              element.OutputKey
            )}`,
          }, //convert key to snake case
          arn: { S: arn },
        });
      }
      return accumulator;
    }, []);

    const batches = [];
    for (let i = 0; i < itemsToWriteToDynamo.length; i += BATCH_SIZE) {
      // split the items into batches of BATCH_SIZE
      batches.push(itemsToWriteToDynamo.slice(i, i + BATCH_SIZE));
    }

    for (const batch of batches) {
      const putRequests = batch.map((item) => {
        return { PutRequest: { Item: item } };
      });
      const command = new BatchWriteItemCommand({
        RequestItems: {
          [`${tablePrefix}${region}${tableSuffix}`]: putRequests,
        },
      });
      // batchWriteItemCommand to DynamoDB logging the results
      results = await dynamoClient.send(command);
      console.log(results);
    }
    console.log(`✅ Region: ${region} updated with BYOA or Bundle stack`);
    //#endregion
  } catch (err) {
    console.log(err);
  }
  //#endregion
})();
