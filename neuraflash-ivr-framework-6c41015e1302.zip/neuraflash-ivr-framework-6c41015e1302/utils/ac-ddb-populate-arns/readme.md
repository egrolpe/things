# AWS Extract CDK Outputs and Import to Config Table

This directory contains a node.js script that exports a stack's output and imports into a DynamoDB Config Table.

## Prerequisites

- node.js (version: `node -v` | install: `brew install node`)
- node package manager (version: `npm -v` | install: `brew install npm`)
- stack must exist on target regions
- DynamoDB Config Table must exist on target regions

## How to use the scripts

### Populate DynamoDB Config Table with CDK Output ARNs:

The `populateConfigArns.js` script exports data from a stack and imports it into a DynamoDB Config Table. The script accepts the following command line arguments:

`--profile`: Name of the AWS profile to use (optional)

Before running the script:

1. Open a terminal and navigate to the directory where the script is saved.
2. Execute `npm i` to install necessary modules

To use the script, run the following command:

`node populateConfigArns.js`

Optionally, include the profile:

`node populateConfigArns.js --profile <profile>`


### Configuring Script

`const REGIONS` Fill this array with the regions the script should loop over.
`const STACK_PREFIX` Prefix of the stack to get CDK outputs. The script will get the outputs of the first stack that it finds that has this prefix.
`const TABLE_PREFIX` Prefix of DynamoDB Config Table to write to. Format of config table should be `<Prefix>-<Region>-<Suffix>`, for example, `client-nf-us-west-2-config-table`
`const TABLE_SUFFIX` Suffix of DynamoDB Config Table to write to. Format of config table should be `<Prefix>-<Region>-<Suffix>`, for example, `client-nf-us-west-2-config-table`