const {
  IAMClient,
  CreateRoleCommand,
  CreatePolicyCommand,
  AttachGroupPolicyCommand,
  AttachRolePolicyCommand,
  ListAttachedRolePoliciesCommand,
  GetRoleCommand,
  NoSuchEntityException,
  CreateServiceLinkedRoleCommand,
  DeletePolicyCommand,
  DeleteRoleCommand,
  DetachRolePolicyCommand
} = require("@aws-sdk/client-iam")
//const { RolesAnywhere } = require("aws-sdk")
const { GetCallerIdentityCommand } = require("@aws-sdk/client-sts")
const { delay } = require("./bot_actions")

/**
 * 
 * @param {*} client 
 * @param {*} role_details 
 * @returns 
 */
async function iam_create_role(client, role_details) {
  // first check if role already exists.
  let role_arn = await iam_check_role_exists(client, role_details)

  if (role_arn == "") {
    // role does not exist.
    console.log("Role Does not exist ...");

  } else {
    console.log("The role already exists and ARN is", role_arn);
    // // console.log("Getting the attached policyes")
    // let res1 = await iam_list_attached_role_policies(client, role_details.role_name)
    // let attachedPolicyArray = res1.AttachedPolicies
    // for (policy of attachedPolicyArray) {
    //   // console.log("Detaching the policy from Role")
    //   await iam_detach_role_policy(client, role_details, policy.PolicyArn)
    //   await delay(2000)
    //   // console.log("Deleting Policy :", policy.PolicyArn)
    //   await iam_delete_policy(client, policy.PolicyArn)
    // }
    // // now all the attached policies are deleted.Delete the role.
    // await delay(3000)
    // await iam_delete_role(client, role_details.role_name)

    role_details.role_arn = role_arn;
    return role_details;
  }

  const trusted_entity = role_details.trusted_entity
  input = {
    RoleName: role_details.role_name,
    AssumeRolePolicyDocument: JSON.stringify(trusted_entity, "", 2),
  }
  // console.log("creating Command")
  const command = new CreateRoleCommand(input)
  try {
    response = await client.send(command)

    //role created with trust policy. Now attach policy to the role.
    if (response.$metadata.httpStatusCode == 200) {
      // role creation succeeded now create policy.
      role_details.role_arn = response.Role.Arn

      response1 = await iam_create_policy(client, role_details)
      if (response1.$metadata.httpStatusCode == 200) {
        ; role_details.policy_id = response1.Policy.PolicyId;
        role_details.policy_arn = response1.Policy.Arn;
        //attach the policy to role.
        response2 = await iam_attach_policy_to_role(client, role_details)
        return role_details
      }
    }
  } catch (error) {
    throw error
  }
}
/**
 * Function create a policy document.
 * @param {IAMClient} client
 * @param {*} role_details
 */
async function iam_create_policy(client, role_details) {
  console.log("Creating IAM policy \"", role_details.policy_name, "\" ...");
  const policy_document = role_details.policy_document
  //const policy_name = role_details.policy_name + "-" + get_formatted_date()
  const policy_name = role_details.policy_name
  // console.log(`policy_name: ${policy_name}`)
  const input = {
    PolicyName: policy_name,
    PolicyDocument: JSON.stringify(policy_document),
  }
  const command = new CreatePolicyCommand(input)
  try {
    response = await client.send(command)
    // console.log(response)
    return response
  } catch (error) {
    throw error
  }
}
/**
 * Function attaches the policy to the role as per role_details.
 * @param {IAMClient} client
 * @param {*} role_details
 * @returns results from the aws client response.
 */
async function iam_attach_policy_to_role(client, role_details) {
  // console.log("Inside iam_attach_policy")
  console.log("Attaching IAM policy \"" + role_details.policy_name + "\" to role \"" + role_details.role_name + "\" ...");
  const role_name = role_details.role_name
  const policy_arn = role_details.policy_arn

  const input = {
    RoleName: role_name,
    PolicyArn: policy_arn,
  }
  const command = new AttachRolePolicyCommand(input)
  try {
    response = await client.send(command)
    // console.log(response)
    return response
  } catch (error) {
    throw error
  }
}
/**
 * This function returns roleARN if exists...
 * @param {IAMClient} client
 * @param {*} role_details
 * @returns
 */
async function iam_check_role_exists(client, role_details) {
  console.log("Checking IAM role \"" + role_details.role_name + "\" already exists ...");
  const role_name = role_details.role_name
  const input = {
    RoleName: role_name,
  }

  const command = new GetRoleCommand(input)

  try {
    response = await client.send(command)
    // console.log(response)
    if (response.$metadata.httpStatusCode == 200) {
      if ((response.Role.RoleName = role_details.role_name)) {
        return response.Role.Arn
      } else {
        return ""
      }
    } else {
      return ""
    }
  } catch (ex) {
    if (ex instanceof NoSuchEntityException) {
      console.log("The role was not found...")
      return ""
    } else {
      throw ex
    }
  }
}
/**
 *
 * @param {*} client
 * @returns
 */

async function sts_get_account_number(client) {
  const input = {}
  const command = new GetCallerIdentityCommand(input)
  try {
    response = await client.send(command)
    // console.log(JSON.stringify(response, "", 2))
    return response.Account
  } catch (error) {
    throw error
  }
}

function get_formatted_date() {
  const now = new Date()
  const dt = now.toLocaleString("en-US", { timeZone: "PST" })
  //dt= '10/2/2023, 7:28:16 AM'
  result = dt.replace(/[\/\s,:]/g, "-")
  // console.log(result)
  return result
}
/**
 * 
 * @param {*} client 
 * @param {*} role_details 
 * @returns object role_details with role_arn in it.
 */
async function iam_create_serviceLinkedPolicy(client, role_details) {

  const input = {
    AWSServiceName: role_details.serviceName,
    Description: "Service linked rolde created by SDK",
    CustomSuffix: role_details.CustomSuffix

  }
  // ServiceLinked RoleName would be "AWSServiceRoleForLexV2Bots_customSuffix"
  role_details.role_name = "AWSServiceRoleForLexV2Bots" + "_" + role_details.CustomSuffix;

  let roleArn = await iam_check_role_exists(client, role_details);
  if (roleArn != "") {
    // console.log("Role Already exists:", roleArn)
    role_details.role_arn = roleArn;
    return role_details;
  }

  else {
    console.log("Creating IAM service linked role ...");
    // console.log(`creating service linked role ${JSON.stringify(input)}`)
    const command = new CreateServiceLinkedRoleCommand(input);
    try {
      response = await client.send(command)
      // console.log(response)
      return response
    }
    catch (error) {
      console.log(error)
      throw (error)
    }
  }
}

async function iam_delete_policy(client, policyArn) {
  console.log("Deleting IAM Policy \"" + policyArn + "\" ...");
  const input = {
    PolicyArn: policyArn
  }

  const command = new DeletePolicyCommand(input)
  try {
    response = await client.send(command)
    // console.log("Deleted ", policyArn)
    // console.log("Response:", JSON.stringify(response, "", 2))
    return;
  }
  catch (error) {
    console.log("Error while deleting Policy")
    throw error
  }


}
async function iam_delete_role(client, roleName) {
  console.log("Deleting IAM Role \"" + roleName + "\" ...");
  const input = {
    RoleName: roleName
  }
  const command = new DeleteRoleCommand(input)
  try {
    response = await client.send(command)
    // console.log("Deleted:", roleName)
    // console.log("Response:", JSON.stringify(response, "", 2))
    return;
  }
  catch (error) {
    console.log("Error while deleting Policy")
    throw error
  }
}
async function iam_detach_role_policy(client, role_details, policyArn) {
  console.log("Detaching IAM Policy \"" + policyArn + "\" from \"" + role_details.role_name + "\" role  ...");
  const input = {
    RoleName: role_details.role_name,
    PolicyArn: policyArn
  }
  const command = new DetachRolePolicyCommand(input)
  try {
    response = await client.send(command)
    // console.log("Detached policy from Role:", policyArn)
    return
  }
  catch (error) {
    console.log("Error while detaching the policy from Role")
    throw error
  }

}

async function iam_list_attached_role_policies(client, roleName) {
  console.log("Listing IAM policies attached to the \"" + roleName + "\" role  ...");
  const input = {
    RoleName: roleName
  }
  const command = new ListAttachedRolePoliciesCommand(input)
  try {
    response = await client.send(command)
    // console.log("Response:", JSON.stringify(response, "", 2))
    return response

  }
  catch (error) {
    console.log("Error while listing attached Policies")
    throw error
  }

}

module.exports = {
  iam_create_role,
  iam_create_policy,
  iam_attach_policy_to_role,
  iam_check_role_exists,
  sts_get_account_number,
  iam_create_serviceLinkedPolicy,
  iam_delete_policy,
  iam_delete_role,
  iam_list_attached_role_policies
}
