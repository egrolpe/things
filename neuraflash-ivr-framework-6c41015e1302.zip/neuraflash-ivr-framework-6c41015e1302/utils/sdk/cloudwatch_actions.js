const {
  CloudWatchLogsClient,
  CreateLogGroupCommand,
  DescribeLogGroupsCommand
} = require("@aws-sdk/client-cloudwatch-logs");
const { delay } = require("./bot_actions");

async function cw_create_log_group(client, bot_details) {
  const input = {
    logGroupName:
      bot_details.cw_log_group_name + "/" + bot_details.bot_name_short,
    logGrooupClass: "standard"
  };
  const command = new CreateLogGroupCommand(input);
  try {
    let response = await client.send(command);
    //response does not contain the ARN .. use the describe to get the arn..
    console.log("created Log group succesfully ,getting the ARN");
    await delay(3000); // wait for 3 seconds.

    let response1 = await cw_describe_log_groups(client, input);
    return response1;

    console.log(JSON.stringify(response, "", 2));
    return response;
  } catch (error) {
    // console.log(JSON.stringify(error))
    if (error.name == "ResourceAlreadyExistsException") {
      console.log(
        "CW Log group" +
          input.logGroupName +
          " already Exists. Trying to get the arn for it."
      );

      try {
        let response = await cw_describe_log_groups(client, input);

        return response;
      } catch (error) {
        console.log(error);
        throw error;
      }
    } else {
      throw error;
    }
  }
}

async function cw_describe_log_groups(client, input) {
  const input1 = {
    logGroupNamePrefix: input.logGroupName,
    limit: 10
  };

  const command = new DescribeLogGroupsCommand(input1);
  try {
    response = await client.send(command);
    // console.log(response)

    //extract the log group whose exact name is input.LogGroupNameprefix

    return response.logGroups.filter(
      (x) => x.logGroupName == input.logGroupName
    );
  } catch (error) {
    console.log(error);
  }
}

module.exports = { cw_create_log_group };
