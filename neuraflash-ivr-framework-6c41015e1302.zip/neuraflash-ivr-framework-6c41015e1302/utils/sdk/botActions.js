const {
  LexModelsV2Client,
  ListBotsCommand,
  CreateBotCommand,
  UpdateSlotTypeCommand,
  CreateBotVersionCommand,
  DescribeBotVersionCommand,
  BuildBotLocaleCommand,
  DescribeBotLocaleCommand,
  UpdateBotAliasCommand
} = require("@aws-sdk/client-lex-models-v2");

const { AssociateBotCommand } = require("@aws-sdk/client-connect");

/* helper function */
const delay = (delayInms) => {
  return new Promise((resolve) => setTimeout(resolve, delayInms));
};

async function createBot() {
  // tobe implemented.
}

const dummySlotValue = [
  {
    // used to clear the slots..
    synonyms: [
      {
        value: "To be deleted"
      }
    ],
    sampleValue: {
      value: "To be deleted"
    }
  }
];

async function botUpdateSlots(
  client,
  botDetails,
  slotTypeName,
  slotTypeValues
) {
  const input = {
    slotTypeId: botDetails[slotTypeName].id,
    slotTypeName: botDetails[slotTypeName].name,
    parentSlotTypeSignature: null,
    botId: botDetails.botId, // required
    botVersion: "DRAFT", // required
    localeId: botDetails.botLocaleId, // required
    slotTypeValues: slotTypeValues,
    valueSelectionSetting: {
      resolutionStrategy: "TopResolution" /* required */
    }
  };
  //console.log(JSON.stringify(input,"",2))
  command = new UpdateSlotTypeCommand(input);

  try {
    result = await client.send(command);
    console.log(JSON.stringify(result.$metadata.httpStatusCode, "", 2));
    return result;
  } catch (error) {
    throw error;
  }
}

async function botClearSlots(client, botDetails, slotTypeName, slotTypeValues) {
  const input = {
    slotTypeId: botDetails[slotTypeName].id,
    slotTypeName: botDetails[slotTypeName].name,
    parentSlotTypeSignature: null,
    botId: botDetails.botId, // required
    botVersion: "DRAFT", // required
    localeId: botDetails.botLocaleId, // required
    slotTypeValues: dummySlotValue,
    valueSelectionSetting: {
      resolutionStrategy: "TopResolution" /* required */
    }
  };
  //console.log(JSON.stringify(input,"",2))
  command = new UpdateSlotTypeCommand(input);

  try {
    result = await client.send(command);
    console.log(JSON.stringify(result.$metadata.httpStatusCode, "", 2));
    return result;
  } catch (error) {
    throw error;
  }
}

async function botCreateVersion(client, botDetails) {
  let mySpec = {};
  Object.defineProperty(mySpec, botDetails.botLocaleId, {
    value: {
      sourceBotVersion: "DRAFT"
    },
    configurable: true,
    writabe: true,
    enumerable: true
  });

  const input = {
    botId: botDetails.botId,
    description: "Version created using SDK",
    botVersionLocaleSpecification: mySpec
  };
  // console.log(JSON.stringify(input, '', 2));
  command = new CreateBotVersionCommand(input);
  result = await client.send(command);
  console.log(result);

  return result;
}

async function botUpdateAlias(client, botDetails) {
  console.log("Updating alias");
  input = {
    botId: botDetails.botId,
    botAliasId: botDetails.botAlias.id,
    botAliasName: "active",
    botVersion: botDetails.botVersion
  };
  const command = new UpdateBotAliasCommand(input);

  result = await client.send(command);
  return result;
}

async function botDescribeVersion(client, botDetails) {
  console.log("Checking status..");
  input = {
    botId: botDetails.botId,
    botVersion: botDetails.botVersion
  };
  command = new DescribeBotVersionCommand(input);
  result = await client.send(command);
  return result;
}

async function botBuildLocale(client, botDetails) {
  console.log("Building Bot Locale");
  input = {
    botId: botDetails.botId,
    botVersion: "DRAFT",
    localeId: botDetails.botLocaleId
  };
  console.log(
    "--> Building botLocale : input params are :" + JSON.stringify(input, "", 2)
  );

  command = new BuildBotLocaleCommand(input);
  result = await client.send(command);
  return result;
} // end of botBuildLocale

async function botDescribeLocale(client, botDetails) {
  console.log("Getting the status of Bot Locale");
  input = {
    botId: botDetails.botId,
    botVersion: "DRAFT",
    localeId: botDetails.botLocaleId
  };
  console.log(
    "Getting  botLocale : input params are :" + JSON.stringify(input, "", 2)
  );

  command = new DescribeBotLocaleCommand(input);

  result = await client.send(command);
  // console.log('Current status:' + JSON.stringify(result, '', 2));
  return result;
} // end of botDescribeLocale.

async function connectUpdateBotAlias(client, botDetails) {
  console.log("Associating connect and Bot");
  input = {
    InstanceId: botDetails.connectDetails.instanceId,
    LexV2Bot: {
      AliasArn:
        botDetails.lexArnPrefix +
        "/" +
        botDetails.botId +
        "/" +
        botDetails.botAlias.id
    }
  };
  console.log(
    "Associating Bot : input params are :" + JSON.stringify(input, "", 2)
  );

  command = new AssociateBotCommand(input);

  result = await client.send(command);
  console.log("Current status:" + JSON.stringify(result, "", 2));
  return result;
}
module.exports = {
  delay,
  botUpdateSlots,
  botBuildLocale,
  botDescribeLocale,
  botClearSlots,
  botCreateVersion,
  botDescribeVersion,
  botUpdateAlias,
  connectUpdateBotAlias
};
