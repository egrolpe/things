const {
  LexModelsV2Client,
  ListBotsCommand,
  CreateBotCommand,
  UpdateSlotTypeCommand,
  CreateBotVersionCommand,
  DescribeBotVersionCommand,
  BuildBotLocaleCommand,
  DescribeBotLocaleCommand,
  UpdateBotAliasCommand,
  UpdateBotCommand,
  ListBotLocalesCommand,
  DeleteBotLocaleCommand,
  CreateBotLocaleCommand,
  CreateSlotTypeCommand,
  CreateIntentCommand,
  CreateSlotCommand,
  UpdateSlotCommand,
  UpdateIntentCommand,
  CreateBotAliasCommand,
  DescribeBotAliasCommand,
  ListBotAliasesCommand,
  TagResourceCommand,
} = require("@aws-sdk/client-lex-models-v2");
// const { get_formatted_date } = require("./iam_actions");

const {
  AssociateBotCommand,
  ListInstancesCommand,
} = require("@aws-sdk/client-connect");

/* helper function */
const delay = (delayInms) => {
  return new Promise((resolve) => setTimeout(resolve, delayInms));
};

const dummySlotValue = [
  {
    // used to clear the slots..
    synonyms: [
      {
        value: "To be deleted",
      },
    ],
    sampleValue: {
      value: "To be deleted",
    },
  },
];

async function botUpdateSlots(
  client,
  botDetails,
  slotTypeName,
  slotTypeValues
) {
  const input = {
    slotTypeId: botDetails[slotTypeName].id,
    slotTypeName: botDetails[slotTypeName].name,
    parentSlotTypeSignature: null,
    botId: botDetails.botId, // required
    botVersion: "DRAFT", // required
    localeId: botDetails.botLocaleId, // required
    slotTypeValues: slotTypeValues,
    valueSelectionSetting: {
      resolutionStrategy: "TopResolution" /* required */,
    },
  };
  //console.log(JSON.stringify(input,"",2))
  command = new UpdateSlotTypeCommand(input);

  try {
    result = await client.send(command);
    // console.log(JSON.stringify(result.$metadata.httpStatusCode, "", 2));
    return result;
  } catch (error) {
    throw error;
    process.exit(1);
  }
}

async function botClearSlots(client, botDetails, slotTypeName, slotTypeValues) {
  const input = {
    slotTypeId: botDetails[slotTypeName].id,
    slotTypeName: botDetails[slotTypeName].name,
    parentSlotTypeSignature: null,
    botId: botDetails.botId, // required
    botVersion: "DRAFT", // required
    localeId: botDetails.botLocaleId, // required
    slotTypeValues: dummySlotValue,
    valueSelectionSetting: {
      resolutionStrategy: "TopResolution" /* required */,
    },
  };
  //console.log(JSON.stringify(input,"",2))
  command = new UpdateSlotTypeCommand(input);

  try {
    result = await client.send(command);
    // console.log(JSON.stringify(result.$metadata.httpStatusCode, "", 2));
    return result;
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
}

async function bot_create_version(client, botDetails) {
  const input = {
    botId: botDetails.bot_id,
    description: "Version created using SDK",
    botVersionLocaleSpecification: botDetails.botVersionLocaleSpecification,
  };
  command = new CreateBotVersionCommand(input);
  try {
    response = await client.send(command);
    // console.log(response);

    return response;
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
  // console.log(JSON.stringify(input, '', 2));
}

async function botUpdateAlias(client, botDetails) {
  console.log("Updating alias");
  input = {
    botId: botDetails.botId,
    botAliasId: botDetails.botAlias.id,
    botAliasName: "active",
    botVersion: botDetails.botVersion,
  };
  const command = new UpdateBotAliasCommand(input);

  result = await client.send(command);
  return result;
}

async function botDescribeVersion(client, botDetails) {
  console.log("Checking status..");
  input = {
    botId: botDetails.botId,
    botVersion: botDetails.botVersion,
  };
  command = new DescribeBotVersionCommand(input);
  result = await client.send(command);
  return result;
}

async function bot_build_locale(client, botDetails, locale) {
  console.log("Building Bot Locale");
  input = {
    botId: botDetails.bot_id,
    botVersion: "DRAFT",
    localeId: locale,
  };
  // console.log(
  //   "Building botLocale : input params are :" + JSON.stringify(input, "", 2)
  // );

  command = new BuildBotLocaleCommand(input);
  result = await client.send(command);
  return result;
} // end of botBuildLocale

async function bot_describe_locale(client, botDetails, locale) {
  // console.log("Getting the status of Bot Locale");
  input = {
    botId: botDetails.bot_id,
    botVersion: "DRAFT",
    localeId: locale,
  };
  // console.log(
  //   "Getting  botLocale : input params are :" + JSON.stringify(input, "", 2)
  // );

  command = new DescribeBotLocaleCommand(input);

  result = await client.send(command);
  // console.log('Current status:' + JSON.stringify(result, '', 2));
  return result;
} // end of botDescribeLocale.

async function connect_associate_bot(client, bot_details) {
  console.log("Associating Connect and Bot ...");

  input = {
    InstanceId: bot_details.connect_id,
    LexV2Bot: {
      AliasArn: bot_details.lex_arn,
    },
  };
  // console.log(
  //   "Associating Bot : input params are :" + JSON.stringify(input, "", 2)
  // );

  command = new AssociateBotCommand(input);

  result = await client.send(command);
  // console.log("Current status:" + JSON.stringify(result, "", 2));
  return result;
}
/**
 * Creates a bot from bot_details configurations.
 * @param {LexModelsV2Client} client
 * @param {*} bot_details
 */
async function bot_create_new(client, bot_details) {
  // console.log("inside bot_create_new");
  // generate input parameters.
  const input = {
    botName: bot_details.bot_name || "simple_bot",
    description: bot_details.description || " bot created by sdk_",
    roleArn: bot_details.role_arn,
    dataPrivacy: { ChildDirected: false },
    idleSessionTTLInSeconds: bot_details.idleSessionTTLInSeconds || 300,
  };

  // check if bot exists if so abort and let user delete it manually.
  let bot_data = await check_bot_exists(client, bot_details);
  console.log("Checking bot exists ...", bot_data.bot_exists);
  if (bot_data.bot_exists) {
    console.log('"' + bot_details.bot_name + '" bot already exists.');
    // input.botId = bot_data.bot_id;
    // const up_command = new UpdateBotCommand(input);
    // // console.log(`updating the bot with : ${JSON.stringify(up_command, "", 2)}`)
    // try {
    //   response = await client.send(up_command);
    //   // console.log("===========Bot update results==========");
    //   // console.log(JSON.stringify(response, "", 2));
    //   if (
    //     response.$metadata.httpStatusCode == 200 ||
    //     response.$metadata.httpStatusCode == 202
    //   ) {
    //     bot_details.bot_id = response.botId;
    //     return bot_details;
    //   }
    // } catch (error) {
    //   console.log(error);
    //   process.exit(1);
    // }
    bot_details.bot_id = bot_data.bot_id;
    return bot_details;
  } else {
    // create the bot.
    try {
      console.log(
        '"' +
          bot_details.bot_name +
          "\" bot doesn't exists. Creating the bot...."
      );
      // console.log(
      //   `input params to create the bot is ${JSON.stringify(input, "", 2)}`
      // );
      const command = new CreateBotCommand(input);
      response = await client.send(command);
      //return response
      // console.log(JSON.stringify(response, "", 2));
      if (
        response.$metadata.httpStatusCode == 202 ||
        response.$metadata.httpStatusCode == 200
      ) {
        //update bot_details with botId /Arn..
        bot_details.bot_id = response.botId;
        return bot_details;
      }
    } catch (error) {
      console.log(error);
      process.exit(1);
    }
  }
}
/**
 * Function to check if bot already exists...
 * @param {LexModelsV2Client} client
 * @param {*} bot_details
 * @returns true or false.
 */
async function check_bot_exists(client, bot_details) {
  // console.log("Inside check_bot_exists function...");
  const input = {
    filters: [
      {
        name: "BotName",
        values: [bot_details.bot_name],
        operator: "EQ",
      },
    ],
  };
  const command = new ListBotsCommand(input);
  try {
    result = await client.send(command);
    // console.log(JSON.stringify(result.botSummaries, "", 2));
    if (result.botSummaries.length == 0) {
      return { bot_exists: false, bot_id: null };
    } else {
      return { bot_exists: true, bot_id: result.botSummaries[0].botId };
    }
  } catch (err) {
    throw err;
    process.exit(1);
  }
}
/**
 *
 * @param {LexModelsV2Client} client
 * @param {*} bot_details
 * @param {*} locale_id like en_US or es_US
 * @returns {} returns an object {locale_exists : true/false}
 */
async function check_locale_exists(client, bot_details, locale_id) {
  // ListBotLocalesCommand is used to check if it exists.
  if (locale_id == "en_US") {
    bot_locale_name = "English (US)";
  } else if (locale_id == "es_US") {
    bot_locale_name = "Spanish (US)";
  } else if (locale_id == "fr_CA") {
    bot_locale_name = "French (Canadian)";
  } else {
    console.log("Unsupported locale passed ..");
    process.exit(1);
  }

  const input = {
    botId: bot_details.bot_id,
    botVersion: "DRAFT",
    filters: [
      {
        name: "BotLocaleName",
        values: [bot_locale_name],
        operator: "EQ",
      },
    ],
  };

  const command = new ListBotLocalesCommand(input);
  try {
    response = await client.send(command);
    // console.log("=======check_bot_locale======");
    // console.log(JSON.stringify(response, "", 2));
    if (
      response.$metadata.httpStatusCode == 200 &&
      response.botLocaleSummaries.length == 1
    ) {
      //locale found..
      return {
        locale_exists: true,
        botLocaleStatus: response.botLocaleSummaries[0].botLocaleStatus,
      };
    } else {
      return {
        locale_exists: false,
        botLocaleStatus: null,
      };
    }
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
}
async function bot_create_locale(client, bot_details, locale_id) {
  // check if locale exists. If so
  // delete the locale and then create new from bot_details..
  locale_status = await check_locale_exists(client, bot_details, locale_id);
  // console.log(locale_id, " locale status: ", locale_status);
  // console.log("Bot details: ", bot_details);
  if (locale_status.locale_exists) {
    console.log("Locale already exists. Deleting the locale \"" + locale_id + "\" ...");
    delete_status = await bot_delete_locale(client, bot_details, locale_id);
    if (delete_status == false) {
      console.log("Something gone wrong while deleting locale....");
      process.exit(1);
    }
    // otherwise wait till locale gets deleted..
    await delay(10000);
  }
  console.log("Creating the locale \"" + locale_id + "\" ...");
  const input = {
    botId: bot_details.bot_id,
    botVersion: "DRAFT",
    description: bot_details.bot_locales[locale_id].description,
    localeId: locale_id,
    nluIntentConfidenceThreshold:
      bot_details.bot_locales[locale_id].nluIntentConfidenceThreshold,
    voiceSettings: bot_details.bot_locales[locale_id].voceSettings,
  };

  const command = new CreateBotLocaleCommand(input);
  try {
    response = await client.send(command);
    if (
      response.$metadata.httpStatusCode == 202 ||
      response.$metadata.httpStatusCode == 200
    ) {
      console.log("Successfully Created the locale \"" + locale_id + "\" ...");
    }
    return response;
  } catch (err) {
    console.log(error);
    process.exit(1);
  }
}
async function bot_delete_locale(client, bot_details, locale_id) {
  const input = {
    botId: bot_details.bot_id,
    botVersion: "DRAFT",
    localeId: locale_id,
  };
  const command = new DeleteBotLocaleCommand(input);
  try {
    // console.log("==========Deleting BotLocale==========");
    response = await client.send(command);

    // console.log(JSON.stringify(response, "", 2));
    if (response.$metadata.httpStatusCode == 202) {
      return {
        locale_deleted: true,
      };
    }
  } catch (error) {
    console.log(error);
    process.exit(1);
    //throw error;
  }
}

async function bot_create_slot_type(
  client,
  bot_details,
  locale_id,
  slot_type_details
) {
  // console.log("================Inside Create Slot=============");
  const input = {
    slotTypeName: slot_type_details.name,
    botId: bot_details.bot_id,
    botVersion: "DRAFT",
    localeId: locale_id,
    valueSelectionSetting: slot_type_details.valueSelectionSetting,
    parentSlotTypeSignature: slot_type_details.parentSlotTypeSignature,
  };

  // in case of SlotType is derived from built-in type then we should not send slotTypeValues.
  if (
    slot_type_details.parentSlotTypeSignature == null ||
    slot_type_details.parentSlotTypeSignature == ""
  ) {
    input.slotTypeValues = slot_type_details.slotTypeValues;
  }
  // console.log(` CreateSlot input values  ${JSON.stringify(input, "", 2)}`);
  const command = new CreateSlotTypeCommand(input);
  try {
    response = await client.send(command);
    // console.log(JSON.stringify(response, "", 2));
    return response;
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
}

async function bot_create_intent(
  client,
  bot_details,
  locale_id,
  intent_details
) {
  // console.log("inside bot_create_intent function");
  let input = {};
  if (locale_id == "en_US") {
    input = {
      intentName: intent_details.name,
      description: intent_details.description || "Intent created by SDK",
      dialogCodeHook: intent_details.dialogCodeHook || {
        enabled: true,
      },
      fulfillmentCodeHook: intent_details.fulfillmentCodeHook || {
        enabled: true,
      },
      inputContexts: intent_details.inputContexts,
      botId: bot_details.bot_id,
      localeId: locale_id,
      botVersion: "DRAFT",
    };
    // console.log("CreateIntentCommand Input: ", JSON.stringify(input, "", 2));
  } else {
    input = {
      intentName: intent_details.name,
      description: intent_details.description || "Intent created by SDK",
      dialogCodeHook: intent_details.dialogCodeHook || {
        enabled: true,
      },
      fulfillmentCodeHook: intent_details.fulfillmentCodeHook || {
        enabled: true,
      },
      botId: bot_details.bot_id,
      localeId: locale_id,
      botVersion: "DRAFT",
    };
  }
  const command = new CreateIntentCommand(input);
  try {
    response = await client.send(command);
    // console.log(JSON.stringify(response, "", 2));
    return response;
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
}

async function bot_create_slot(client, bot_details, cur_locale, slot_details) {
  // console.log("inside bot_create_slot functiion");
  const input = {
    slotName: slot_details.slot_name,
    description: slot_details.description || "Slot created by SDK",
    slotTypeId: slot_details.slot_type_id,
    botId: bot_details.bot_id,
    botVersion: "DRAFT",
    intentId: slot_details.intent_id,
    localeId: cur_locale,
    valueElicitationSetting: slot_details.valueElicitationSetting,
  };

  const command = new CreateSlotCommand(input);
  try {
    response = await client.send(command);
    // console.log(response);
    return response;
  } catch (error) {
    throw error;
  }
}

async function bot_update_intent(
  client,
  bot_details,
  cur_locale,
  intent_details
) {
  let input = {};
  if (cur_locale == "en_US") {
    input = {
      botId: bot_details.bot_id,
      botVersion: "DRAFT",
      localeId: cur_locale,
      intentId: intent_details.intent_id,
      intentName: intent_details.intent_name,
      sampleUtterances: intent_details.sampleUtterances,
      slotPriorities: intent_details.slotPriorities,
      fulfillmentCodeHook: intent_details.fulfillmentCodeHook,
      dialogCodeHook: intent_details.dialogCodeHook,
      inputContexts: intent_details.inputContexts,
    };
  } else {
    input = {
      botId: bot_details.bot_id,
      botVersion: "DRAFT",
      localeId: cur_locale,
      intentId: intent_details.intent_id,
      intentName: intent_details.intent_name,
      sampleUtterances: intent_details.sampleUtterances,
      slotPriorities: intent_details.slotPriorities,
      fulfillmentCodeHook: intent_details.fulfillmentCodeHook,
      dialogCodeHook: intent_details.dialogCodeHook,
    }
  }

  // console.log(JSON.stringify(input, "", 2));
  const command = new UpdateIntentCommand(input);
  try {
    response = await client.send(command);
    // console.log(response);
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
}

async function bot_create_alias(client, bot_details) {
  // botAliasLocaleSettings = {}
  // for (Keys of bot_details.bot_locales) {
  //   botAliasLocaleSettings.key = {
  //     enabled: true,
  //     codeHookSpecification: {
  //       lambdaCodeHook: {
  //         lambdaARN: bot_details.bot_alias.lambda_arn,
  //         codeHookInterfaceVersion: bot_details.bot_alias.lambda_version,
  //       },
  //     },
  //   }
  // }

  input = {
    botAliasName: bot_details.bot_alias,
    description: bot_details.bot_alias.description,
    botVersion: bot_details.bot_version,
    botAliasLocaleSettings: bot_details.botAliasLocaleSettings,
    botId: bot_details.bot_id,
    conversationLogSettings: bot_details.conversationLogSettings
  };
  //check if bot exits.
  botAliasId = await bot_check_alias_exists(client, bot_details);
  // console.log(botAliasId);
  if (botAliasId != null) {
    // bot exists. use the updateCommand.
    input.botAliasId = botAliasId;
    try {
      const updateCommand = new UpdateBotAliasCommand(input);
      response = await client.send(updateCommand);
      return response;
    } catch (error) {
      console.log(error);
      process.exit(1);
    }
  }

  const command = new CreateBotAliasCommand(input);

  try {
    response = await client.send(command);
    return response;
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
}

async function bot_describe_alias(client, bot_details) {
  const input = {
    botId: bot_details.bot_id,
    botAliasId: bot_details.bot_alias_id,
  };

  const command = new DescribeBotAliasCommand(input);

  try {
    response = await client.send(command);
    // console.log(JSON.stringify(response, "", 2));
    return response;
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
}
/**
 *
 * @param {} client
 * @param {string} connectAlias
 * @returns if connect ID is found returns else returns null
 */
async function connect_get_id(client, connectAlias) {
  const input = {};
  const command = new ListInstancesCommand(input);
  try {
    respone = await client.send(command);
    // filter the response
    response1 = response.LinstanceSummaryList.filter(
      (obj) => (obj.InstanceAlias = connectAlias)
    );
    if (response1.length == 1) {
      return response1[0].id;
    } else {
      return null;
    }
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
}
async function bot_list_alias(client, bot_details) {
  const input = {
    botId: bot_details.bot_id,
    maxResults: 10,
  };
  let aliases = [];

  const command = new ListBotAliasesCommand(input);
  try {
    do {
      results = await client.send(command);
      input.nextToken = results.nextToken;
      if (results.botAliasSummaries.length != 0) {
        for (alias of results.botAliasSummaries) {
          aliases.push(alias);
        }
      }
    } while ((results.nextToken = ""));
    // console.log(JSON.stringify(aliases, "", 2));
    return aliases;
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
}

async function bot_check_alias_exists(client, bot_details) {
  // console.log("====inside bot_ckeck_bot_alias_exists=========");
  aliases = await bot_list_alias(client, bot_details);
  // console.log(JSON.stringify(aliases, "", 2));

  for (element of aliases) {
    if (element.botAliasName == bot_details.bot_alias)
      return element.botAliasId;
  }
  return null;
}

async function bot_update_Fallback_intent(client, bot_details, locale) {
  //IntentID is always FALLBACKINT
  const input = {

    intentId: "FALLBCKINT",
    intentName: "FallbackIntent",
    parentIntentSignature: "AMAZON.FallbackIntent",

    fulfillmentCodeHook: {
      enabled: true,
      active: true
    },
    dialogCodeHook: {
      enabled: true
    },
    botId: bot_details.bot_id,
    botVersion: "DRAFT",
    localeId: locale

  }
  // console.log(JSON.stringify(input, '', 2))
  const command = new UpdateIntentCommand(input)
  try {
    let response = client.send(command)
    // console.log("UpdateIntentCommand response: ",JSON.stringify(response, "", 2));
    return response
  }
  catch (error) {
    console.log(error)
    throw new Error(error)
  }

}


async function bot_add_tags(client, bot_details, resouceARN) {

  const input = {
    resourceARN: resouceARN,
    tags: bot_details.tags

  }
  const command = new TagResourceCommand(input)
  try {

    let response = client.send(command)
    return response
  }
  catch (error) {
    console.log(error)
    throw new Error(error)
  }




}

module.exports = {
  delay,
  botUpdateSlots,
  bot_build_locale,
  bot_describe_locale,
  botClearSlots,
  bot_create_version,
  botDescribeVersion,
  botUpdateAlias,
  connect_associate_bot,
  connect_get_id,
  bot_create_new,
  check_bot_exists,
  bot_create_locale,
  bot_delete_locale,
  check_locale_exists,
  bot_create_slot_type,
  bot_create_intent,
  bot_create_slot,
  bot_update_intent,
  bot_create_alias,
  bot_describe_alias,
  bot_list_alias,
  bot_check_alias_exists,
  bot_update_Fallback_intent,
  bot_add_tags
};
