const awsProfile = process.env.AWS_PROFILE;
const fs = require("fs");
const {
  LexModelsV2Client,
  DescribeBotLocaleCommand,
  CreateBotVersionCommand,
  DescribeBotVersionCommand
} = require("@aws-sdk/client-lex-models-v2");
const path = require("path");
const { fromIni } = require("@aws-sdk/credential-providers");
const { ConnectClient } = require("@aws-sdk/client-connect");
const botDetails = require("./botdetails.json");
const {
  delay,
  botUpdateSlots,
  botBuildLocale,
  botDescribeLocale,
  botClearSlots,
  botCreateVersion,
  botDescribeVersion,
  botUpdateAlias,
  connectUpdateBotAlias
} = require("./botActions.js");

const config = {
  credentials: fromIni({ profile: awsProfile }),
  region: "us-west-2"
};
console.log("Beginning...");
var botStatus = "";
const client = new LexModelsV2Client(config);

step0 = botBuildLocale(client, botDetails);

step1 = step0.then((res) => {
  console.log("inside Step1 : Building the Locale.");
  botDetails.botLocaleStatus = res.botLocaleStatus;
  console.log("Current bot Locale Status is:" + botDetails.botLocaleStatus);
  return botDetails;
});

step2 = step1.then(async (res) => {
  console.log("inside Step 2 : Checking bot Status");
  if (botDetails.botLocaleStatus != "Built") {
    console.log("Waiting for build to complete...");
  }
  while (botDetails.botLocaleStatus != "Built") {
    delT = 30000;
    console.log("Waiting :" + delT);
    await delay(delT);
    response = await botDescribeLocale(client, botDetails);
    console.log("Current status :" + response.botLocaleStatus);
    botDetails.botLocaleStatus = response.botLocaleStatus;
    if (botDetails.botLocaleStatus == "Failed") {
      throw "Bot Build Failed..";
    }
  }
  return botDetails;
});

step3 = step2.then(async () => {
  console.log("Inside step3: Creating a version");
  result = await botCreateVersion(client, botDetails);
  botDetails.botVersion = result.botVersion;
  return botDetails;
});
step4 = step3.then(async () => {
  console.log("Inside Step4: Checking the status of BotVersion");
  if (botDetails.botStatus != "Available") {
    console.log("Bot is not yet ready...");
  }
  let status = "";

  while (botDetails.botStatus != "Available") {
    delT = 15000;
    console.log("Waiting :" + delT);
    await delay(delT);
    response = await botDescribeVersion(client, botDetails);
    console.log("Current Status :" + response.botStatus);
    botDetails.botStatus = response.botStatus;
  }
  return botDetails;
});

step5 = step4.then(async () => {
  console.log("Inside Step5 : Associating version with Alias");
  result = await botUpdateAlias(client, botDetails);
  console.log(result);
});

step6 = step5.then(async () => {
  const client1 = new ConnectClient(config);
  console.log("Inside Step6: Associating Bot with Connect");
  result = await connectUpdateBotAlias(client1, botDetails);
  console.log(result);
  return botDetails;
});
