// Import required AWS SDK clients and commands for Node.js
const {
  ConnectClient,
  ListSecurityProfilesCommand,
  DescribeSecurityProfileCommand,
  ListSecurityProfilePermissionsCommand
} = require("@aws-sdk/client-connect");
const { fromIni } = require("@aws-sdk/credential-providers");

const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const path = require("path");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId] --profile [profile]]"
  )
  .demandOption(["region", "stage"]) // region argument required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("instanceId", "Specify Amazon Connect instance Id") // description for the instanceId argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

let config = { region: argv.region };
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);

if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}

// Create an Amazon Connect service client object
const client = new ConnectClient(config);

const getSecurityProfileDetails = async (profileId) => {
  const describeCommand = new DescribeSecurityProfileCommand({
    InstanceId: instanceId,
    SecurityProfileId: profileId
  });
  const describeResponse = await client.send(describeCommand);
  const permissionsCommand = new ListSecurityProfilePermissionsCommand({
    InstanceId: instanceId,
    SecurityProfileId: profileId
  });
  const permissionsResponse = await client.send(permissionsCommand);

  return {
    ...describeResponse.SecurityProfile,
    Permissions: permissionsResponse.Permissions
  };
};

const listAndDescribeSecurityProfiles = async () => {
  try {
    const listCommand = new ListSecurityProfilesCommand({
      InstanceId: instanceId
    });
    const listResponse = await client.send(listCommand);

    const detailedProfiles = [];
    for (const profile of listResponse.SecurityProfileSummaryList) {
      const profileDetails = await getSecurityProfileDetails(profile.Id);
      detailedProfiles.push(profileDetails);
    }

    // Ensure the data folder exists
    const dataFolderPath = path.join(__dirname, "data");
    if (!fs.existsSync(dataFolderPath)) {
      fs.mkdirSync(dataFolderPath);
    }

    // Write the detailed profiles to a file in the data folder
    const filePath = path.join(dataFolderPath, "securityProfiles.json");
    fs.writeFileSync(filePath, JSON.stringify(detailedProfiles, null, 2));

    console.log("✅ Security profiles saved to securityProfilesDetailed.json");
  } catch (err) {
    console.error("❌ Error", err);
  }
};

// Execute the function
listAndDescribeSecurityProfiles();
