# Amazon Connect Security Profiles Manager

This module helps manage security profiles in Amazon Connect by creating or updating them based on a configuration file. It utilizes the AWS SDK for JavaScript and requires an AWS account with appropriate permissions.

## Features

- Create new security profiles in Amazon Connect.
- Update existing security profiles with new configurations.
- Manage permissions for security profiles.
- Handles command-line argument parsing for flexible execution.

## Installation

To use this module, ensure you have Node.js installed. Then, install the required packages:

```bash
npm install
```

## Usage

### Full Workflow (Recommended)

To run the complete workflow of caching existing security profiles, converting CSV to JSON, and deploying security profiles, use the full workflow script:

```bash
node full-security-profiles-workflow.js --region us-west-2 --stage dev --instanceId YOUR_INSTANCE_ID
```

This script will:
1. Cache existing security profiles from Amazon Connect
2. Convert your CSV file to JSON format
3. Deploy the security profiles to Amazon Connect

### Individual Scripts

#### Step 1: Set Up AWS Credentials

Ensure your AWS credentials are configured. You can use the AWS CLI to set up profiles or place your credentials in the `~/.aws/credentials` file.

#### Step 2: Cache Existing Security Profiles

First, cache the existing security profiles:

```bash
node cacheSecurityProfiles.js --region us-west-2 --stage dev --instanceId YOUR_INSTANCE_ID
```

#### Step 3: Prepare Security Profile Configuration

Create a JSON file named `securityProfiles.json` in a `data` directory. The structure should look like this:
This can be achieved by using the `convertCsvToSecurityProfile.js` script with the following command

```bash
node convertCsvToSecurityProfile.js --sourceFile ./data/input/SecurityProfiles.csv --destinationFile ./data/output/securityProfiles.json
```

### CSV Structure

The input CSV file should be transposed with headers on the left side. The structure should include:

- `SecurityProfileName`: The name of the security profile
- `Description`: A description of the security profile
- `Permission`: Permissions associated with the security profile (multiple rows allowed)

### Example CSV

You can find an example CSV at `./data/input/SecurityProfiles.csv`:

| SecurityProfileName | CallCenterManager                 | QualityAnalyst                    |
| Description         | Manager responsible for call ce...| Analyst responsible for qualit... |
| Permission          | AccessMetrics                     | AccessMetrics                     |
| Permission          | AgentStates.Create                | AgentTimeCard.View                |
| Permission          |                                   | AgentStates.Edit                  |

This will generate a JSON structure like:

```json
[
    {
        "SecurityProfileName": "CallCenterManager",
        "Description": "Manager responsible for call center operations",
        "Permissions": [
            "AccessMetrics",
            "AgentStates.Create"
        ]
    },
    {
        "SecurityProfileName": "QualityAnalyst",
        "Description": "Analyst responsible for quality assurance",
        "Permissions": [
            "AccessMetrics",
            "AgentTimeCard.View",
            "AgentStates.Edit"
        ]
    }
]
```

#### Step 4: Deploy Security Profiles

Use the command line to execute the deploy script. You must provide the AWS region, stage, and source file. The instance ID is optional (will be fetched from config if not provided).

```bash
node deploySecurityProfiles.js --region us-west-2 --stage dev --sourceFile ./data/securityProfiles.json --instanceId YOUR_INSTANCE_ID
```

### Command-Line Arguments

#### For Scripts with AWS Operations (cacheSecurityProfiles.js, deploySecurityProfiles.js, full-security-profiles-workflow.js):
- `--region`: **Required**. Specify the AWS region (e.g., `us-west-2`).
- `--stage`: **Required**. Specify the deployment stage (used to fetch instance ID from config file if not provided).
- `--instanceId`: Optional. Specify the Amazon Connect instance ID (if not provided, will be fetched from config).
- `--profile`: Optional. Specify the AWS profile to use.

#### For CSV Conversion Script (convertCsvToSecurityProfile.js):
- `--sourceFile`: **Required**. Specify the path to the input CSV file.
- `--destinationFile`: **Required**. Specify the path to the output JSON file.

### Example Output

When you run the script, it will log the operations performed, such as creating or updating security profiles:

```
✅ created security profile CallCenterManager
✅ updated security profile QualityAnalyst
ℹ️  no updates for security profile BasicProfile
```

## Error Handling

If there are issues with the provided configuration, such as invalid permissions, the script will log an error message:

```
❌ Failed to update security profile ProfileName1 because permission InvalidPermission does not exist.
```

## Dependencies

- `@aws-sdk/client-connect`: AWS SDK for interacting with Amazon Connect.
- `csv-parse`: Package to parse CSV files.
- `yargs`: Command-line argument parser.

## License

This project is licensed under the MIT License.
