// Import required AWS SDK clients and commands for Node.js
const {
  ConnectClient,
  CreateSecurityProfileCommand,
  UpdateSecurityProfileCommand,
  ListSecurityProfilesCommand
} = require("@aws-sdk/client-connect");
const { fromIni } = require("@aws-sdk/credential-providers");

const fs = require("fs");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] --sourceFile [sourceFile] [--instanceId [instanceId] --profile [profile]]"
  )
  .demandOption(["region", "stage", "sourceFile"]) // region, stage, sourceFile argument required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("sourceFile", "JSON file to deploy from") // description for sourceFile argument
  .describe("instanceId", "Specify Amazon Connect instance Id") // description for the instanceId argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

let config = { region: argv.region };
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);
const sourceFile = argv.sourceFile

if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}

// Create an Amazon Connect service client object
const client = new ConnectClient(config);

const getExistingSecurityProfiles = async () => {
  const command = new ListSecurityProfilesCommand({
    InstanceId: instanceId
  });
  const response = await client.send(command);
  return response.SecurityProfileSummaryList.reduce((acc, profile) => {
    acc[profile.Name] = profile.Id;
    return acc;
  }, {});
};

const deploySecurityProfiles = async () => {
  try {
    // Read the detailed security profiles from the saved file
    const data = fs.readFileSync(sourceFile, "utf8");
    const securityProfiles = JSON.parse(data);

    const existingProfiles = await getExistingSecurityProfiles();

    for (const profile of securityProfiles) {
      const profileId = existingProfiles[profile.SecurityProfileName];
      const params = {
        InstanceId: instanceId,
        SecurityProfileName: profile.SecurityProfileName,
        Description: profile.Description,
        Permissions: profile.Permissions,
        AllowedAccessControlTags: profile.AllowedAccessControlTags,
        TagRestrictedResources: profile.TagRestrictedResources,
        HierarchyRestrictedResources: profile.HierarchyRestrictedResources || ["User"]
      };

      if (profileId) {
        // Update the existing security profile
        const updateParams = {
          ...params,
          SecurityProfileId: profileId
        };
        const updateCommand = new UpdateSecurityProfileCommand(updateParams);
        await client.send(updateCommand);
        console.log(
          `✅ Security profile ${profile.SecurityProfileName} updated successfully`
        );
      } else {
        // Create a new security profile
        const createCommand = new CreateSecurityProfileCommand(params);
        await client.send(createCommand);
        console.log(
          `✅ Security profile ${profile.SecurityProfileName} created successfully`
        );
      }
    }
  } catch (err) {
    console.error("❌ Error", err);
  }
};

// Execute the function
deploySecurityProfiles();
