const { spawn } = require('child_process');
const yargs = require('yargs/yargs');
const { hideBin } = require('yargs/helpers');
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

/**
 * Master script to manage Amazon Connect Security Profiles workflow:
 * 1. Cache existing security profiles from AWS
 * 2. Convert CSV to JSON format
 * 3. Deploy security profiles to AWS
 *
 * Usage:
 *   node manageSecurityProfiles.js --region us-east-1 --stage dev --profile myprofile
 *
 * Required arguments:
 * - --region: AWS region
 * - --stage: Environment stage (dev, qa, prod)
 *
 * Optional arguments:
 * - --profile: AWS profile name
 * - --instanceId: Amazon Connect instance ID (if not using config file)
 * - --csvFile: Path to input CSV file (default: data/input/SecurityProfiles.csv)
 * - --jsonFile: Path to output JSON file (default: data/output/securityProfiles.json)
 */

const argv = yargs(hideBin(process.argv))
  .usage('Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId] --profile [profile]]')
  .demandOption(['region', 'stage'])
  .describe('region', 'AWS region')
  .describe('stage', 'Environment stage (dev, qa, prod)')
  .describe('instanceId', 'Amazon Connect instance ID')
  .describe('profile', 'AWS profile name')
  .describe('csvFile', 'Path to input CSV file')
  .describe('jsonFile', 'Path to output JSON file')
  .argv;

const region = argv.region;
const stage = argv.stage;
const profile = argv.profile;
const instanceId = argv.instanceId || getConnectInstanceId(stage, region);
const csvFile = argv.csvFile || 'data/input/SecurityProfiles.csv';
const jsonFile = argv.jsonFile || 'data/output/securityProfiles.json';

// Helper function to run a command and return a promise
const runCommand = (command, args) => {
  return new Promise((resolve, reject) => {
    console.log(`\n🔄 Running: ${command} ${args.join(' ')}`);

    const child = spawn(command, args, {
      stdio: 'inherit',
      shell: true
    });

    child.on('close', (code) => {
      if (code === 0) {
        console.log(`✅ Command completed successfully`);
        resolve();
      } else {
        reject(new Error(`Command failed with exit code ${code}`));
      }
    });

    child.on('error', (error) => {
      reject(error);
    });
  });
};

// Main workflow function
const manageSecurityProfiles = async () => {
  try {
    console.log('🚀 Starting Security Profiles Management Workflow\n');

    // Step 1: Cache existing security profiles
    console.log('📥 Step 1: Caching existing security profiles...');
    const cacheArgs = ['cacheSecurityProfiles.js', '--region', region, '--stage', stage];
    if (profile) cacheArgs.push('--profile', profile);
    if (instanceId) cacheArgs.push('--instanceId', instanceId);
    await runCommand('node', cacheArgs);

    // Step 2: Convert CSV to JSON
    console.log('🔄 Step 2: Converting CSV to JSON...');
    const convertArgs = ['convertCsvToSecurityProfile.js', '--sourceFile', csvFile, '--destinationFile', jsonFile];
    await runCommand('node', convertArgs);

    // Step 3: Deploy security profiles
    console.log('🚀 Step 3: Deploying security profiles to AWS...');
    const deployArgs = ['deploySecurityProfiles.js', '--region', region, '--stage', stage, '--sourceFile', jsonFile];
    if (profile) deployArgs.push('--profile', profile);
    if (instanceId) deployArgs.push('--instanceId', instanceId);
    await runCommand('node', deployArgs);

    console.log('\n🎉 Security Profiles Management Workflow completed successfully!');

  } catch (error) {
    console.error('\n❌ Error in workflow:', error.message);
    process.exit(1);
  }
};

// Execute the workflow
manageSecurityProfiles();
