const fs = require('fs');
const { parse } = require("csv-parse");
const yargs = require("yargs/yargs");

/**
 * CSV to JSON Converter
 * 
 * This script reads a CSV file containing Agent Status configurations and converts 
 * it into a structured JSON format. It allows the user to specify the input 
 * CSV file and the output JSON file through command-line arguments.
 *
 * The CSV file should have the following structure:
 * - SecurityProfileName
 * - Description
 * - Permission
 * 
 * NOTE: the CSV should be TRANSPOSE - Headers are on the left side
 * 
 * example:
 * SecurityProfileName | CallCenterManager     | QualityAnalyst
 * Description         | <manager description> | <analyst description>
 * Permission          | AccessMetrics         | AccessMetrics
 * Permission          | AgentStates.Create    | AgentTimeCard.View
 * Permission          |                       | AgentStates.Edit
 *
 * The resulting JSON structure will include the following fields:
 * ```json
 * [
 *     {
 *         "SecurityProfileName": "CallCenterManager",
 *         "Description": "Manager responsible for call center operations",
 *         "Permissions": [
 *             "AccessMetrics",
 *             "AgentStates.Create"
 *         ]
 *     },
 *     {
 *         "SecurityProfileName": "QualityAnalyst",
 *         "Description": "Analyst responsible for quality assurance",
 *         "Permissions": [
 *             "AccessMetrics",
 *             "AgentTimeCard.View",
 *             "AgentStates.Edit"
 *         ]
 *     }
 * ]
 * ```
 *
 * Usage:
 *   node convertCsvToSecurityProfile.js --sourceFile path/to/input.csv --destinationFile path/to/output.json
 *
 * Command-line Arguments:
 * - --sourceFile: The path to the input CSV file (required).
 * - --destinationFile: The path to the output JSON file (required).
 *
 * Dependencies:
 * - fs: Node.js file system module for reading and writing files.
 * - csv-parse: A package to parse CSV files.
 * - yargs: A package to handle command-line arguments.
 *
 * Example:
 *   node convertCsvToSecurityProfile.js --sourceFile data/input/SecurityProfile.csv --destinationFile data/output/securityProfiles.json
 * 
 * Author: Henry Pizzo
 * Date: Sept 4, 2025
 */

// Get input and output file paths from command-line arguments
const argv = yargs(process.argv.slice(2))
    .usage("Usage: $0 --sourceFile [name] --destinationFile [name]")
    .demandOption(["sourceFile", "destinationFile"])
    .describe("sourceFile", "Specify CSV file to convert to JSON") 
    .describe("destinationFile", "Specify a destination to write to")
    .argv; 

const inputFilePath = argv.sourceFile;
const outputFilePath = argv.destinationFile;

const securityProfiles = []

// Function to map CSV data to desired JSON structure
const mapToJsonFormat = (row) => {

    if (row[0] === 'SecurityProfileName') {
        // name row, initialize data structure
        for (let i = 1; i < row.length; i++) {
            securityProfiles.push({
                SecurityProfileName: row[i]
            })
        }      
    } 
    else if (row[0] === 'Description') {
        // description row, add
        for (let i = 1; i < row.length; i++) {
            securityProfiles[i-1].Description = row[i]
        }

    } else if (row[0] === 'Permission') {
        // permission row, add
        for (let i = 1; i < row.length; i++) {
            // skip empty cells
            if (row[i].trim() == '') {
                continue;
            }
            // check if Premissions attribute exists
            if (securityProfiles[i-1].Permissions) {
                securityProfiles[i-1].Permissions.push(row[i]);
            } else {
                // initialize array
                securityProfiles[i-1].Permissions = [row[i]];
            }    
        }
    }
};

fs.createReadStream(inputFilePath, 'utf8')
  .pipe(parse({ delimiter: ',' }))
  .on('data', (row) => {
    mapToJsonFormat(row);
  })
  .on('end', () => {
    // Write the mapped data to a JSON file
    fs.writeFileSync(outputFilePath, JSON.stringify(securityProfiles, null, 2), 'utf8');
    console.log('CSV data has been successfully mapped and written to JSON file.');
  })
  .on('error', (error) => {
    console.error('Error reading the CSV file:', error);
  });

