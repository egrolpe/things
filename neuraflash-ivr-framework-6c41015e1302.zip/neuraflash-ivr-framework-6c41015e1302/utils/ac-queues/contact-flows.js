const {
  ConnectClient,
  DescribeContactFlowCommand,
  paginateListContactFlows
} = require("@aws-sdk/client-connect"); // CommonJS import

const getFlowById = async (config, instanceId, contactFlowId) => {
  const client = new ConnectClient(config);
  const input = {
    // DescribeContactFlowRequest
    InstanceId: instanceId,
    ContactFlowId: contactFlowId
  };
  const command = new DescribeContactFlowCommand(input);
  const response = await client.send(command);
  return response;
};
/**
 * Retrieves a list of outbound whisper contact flows from Amazon Connect.
 * @async
 * @param {AWS.Connect} connect - An instance of the AWS.Connect class.
 * @returns {Promise<Object>} - A Promise that resolves to an object containing the retrieved contact flows, where each key is the name of a contact flow and each value is a ContactFlowSummary object.
 */
const getWhisperFlows = async (connect, instanceId) => {
  const paginator = paginateListContactFlows(
    { client: connect },
    { InstanceId: instanceId, ContactFlowTypes: ["OUTBOUND_WHISPER"] }
  );
  const contactFlowsList = [];
  for await (const response of paginator) {
    // process each page of results
    contactFlowsList.push(...response.ContactFlowSummaryList);
  }
  const contactFlows = contactFlowsList.reduce((acc, contactFlow) => {
    acc[contactFlow.Name] = contactFlow;
    return acc;
  }, {});
  return contactFlows;
};

module.exports = { getFlowById, getWhisperFlows };
