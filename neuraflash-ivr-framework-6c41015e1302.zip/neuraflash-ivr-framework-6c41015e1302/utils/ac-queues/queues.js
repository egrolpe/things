const {
  DescribeQueueCommand,
  paginateListQueues
} = require("@aws-sdk/client-connect");

/**
 * Returns a list of queues for a given instance ID.
 * @param {AWS.Connect} connect - An AWS Connect instance.
 * @param {string} instanceId - The ID of the instance to retrieve queues for.
 * @returns {Promise<Array>} - A promise that resolves to an array of queue objects.
 */
const listQueues = async (connect, instanceId) => {
  const paginator = paginateListQueues(
    { client: connect },
    { InstanceId: instanceId }
  );
  const queueList = [];
  for await (const response of paginator) {
    queueList.push(...response.QueueSummaryList);
  }
  return queueList;
};

/**
 * Returns a list of queue objects.
 * @param {Object} config - The configuration object.
 * @returns {Promise<Object>} - A promise that resolves to an object containing queue objects.
 */
const getQueues = async (connect, instanceId) => {
  const queueList = await listQueues(connect, instanceId);
  const queues = {};
  for await (const queue of queueList) {
    if (queue.QueueType === "STANDARD") {
      const response = await connect.send(
        new DescribeQueueCommand({
          InstanceId: instanceId,
          QueueId: queue.Id
        })
      );
      queues[queue.Name] = response.Queue;
    }
  }
  return queues;
};

const getQueuesById = async (connect, instanceId) => {
  const queueList = await listQueues(connect, instanceId);
  const queues = {};
  for await (const queue of queueList) {
    if (queue.QueueType === "STANDARD") {
      const response = await connect.send(
        new DescribeQueueCommand({
          InstanceId: instanceId,
          QueueId: queue.Id
        })
      );
      queues[queue.Id] = response.Queue;
    }
  }
  return queues;
};

module.exports = { getQueues, getQueuesById };
