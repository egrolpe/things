const fs = require("fs");

const readCSV = (filePath, valueSeparator = ",") => {
  const data = fs.readFileSync(filePath, "utf8");
  // Split data into lines and separate headers from actual data
  // using Array spread operator
  const [headerLine, ...lines] = data.split("\n");

  // Split headers line into an array
  // `valueSeparator` may come from some kind of argument
  // You may want to transform header strings into something more
  // usable, like `camelCase` or `lowercase-space-to-dash`
  const headers = headerLine.split(valueSeparator);

  // Create objects from parsing lines
  // There will be as much objects as lines
  const objects = lines
    // Remove empty lines
    .filter((line) => line.trim() !== "")

    // Parse each line

    .map((line, index) =>
      line

        // Split line with value separators
        .split(valueSeparator)

        // Reduce values array into an object like: { [header]: value }
        // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/reduce
        .reduce(
          // Reducer callback
          (object, value, index) => ({
            ...object,
            [headers[index]]: value
          }),

          // Initial value (empty JS object)
          {}
        )
    );
  return objects;
};
module.exports = { readCSV };
