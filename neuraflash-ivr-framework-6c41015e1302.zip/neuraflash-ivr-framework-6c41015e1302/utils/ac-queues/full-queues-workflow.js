const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { spawn } = require("child_process");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

// Parse command line arguments
const argv = yargs(hideBin(process.argv))
  .usage("Usage: $0 --region [region] --sourceFile [sourceFile] --stage [stage] [--instanceId [instanceId] --profile [profile] --destinationFile [destinationFile]]")
  .demandOption(["region", "sourceFile", "stage"])
  .describe("region", "Specify AWS region")
  .describe("sourceFile", "Specify CSV source file for convertCsvToQueue")
  .describe("destinationFile", "Specify destination file for convertCsvToQueue (default: data/queues.json)")
  .describe("instanceId", "Specify Amazon Connect instance Id")
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile")
  .argv;

const region = argv.region;
const sourceFile = argv.sourceFile;
const destinationFile = argv.destinationFile || "data/queues.json";
const instanceId = argv.instanceId;
const stage = argv.stage;
const profile = argv.profile;

// Function to run a script with arguments
const runScript = (scriptName, args) => {
  return new Promise((resolve, reject) => {
    console.log(`Running ${scriptName} with args: ${args.join(' ')}`);
    const child = spawn('node', [scriptName, ...args], { stdio: 'inherit' });

    child.on('close', (code) => {
      if (code === 0) {
        console.log(`${scriptName} completed successfully`);
        resolve();
      } else {
        reject(new Error(`${scriptName} failed with code ${code}`));
      }
    });

    child.on('error', (error) => {
      reject(error);
    });
  });
};

// Main workflow
const main = async () => {
  try {
    // Step 1: Cache queues
    const cacheArgs = ['--region', region, '--stage', stage];
    if (instanceId) cacheArgs.push('--instanceId', instanceId);
    if (profile) cacheArgs.push('--profile', profile);
    await runScript('cache-queues.js', cacheArgs);

    // Step 2: Convert CSV to Queue JSON
    const convertArgs = ['--sourceFile', sourceFile, '--destinationFile', destinationFile];
    await runScript('convertCsvToQueue.js', convertArgs);

    // Step 3: Deploy queues
    const deployArgs = ['--region', region, '--sourceFile', destinationFile, '--stage', stage];
    if (instanceId) deployArgs.push('--instanceId', instanceId);
    if (profile) deployArgs.push('--profile', profile);
    await runScript('deploy-queues.js', deployArgs);

    console.log('Full queues workflow completed successfully');
  } catch (error) {
    console.error('Error in workflow:', error.message);
    process.exit(1);
  }
};

main();
