const {
  ConnectClient,
  CreateQueueCommand,
  UpdateQueueNameCommand,
  UpdateQueueHoursOfOperationCommand,
  UpdateQueueOutboundCallerConfigCommand,
} = require("@aws-sdk/client-connect");
const _ = require("lodash");
const fs = require("fs");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { fromIni } = require("@aws-sdk/credential-providers");
const { getQueues } = require("./queues");
const { getWhisperFlows } = require("./contact-flows");
const { getHoursOfOperations } = require("./hours-of-operations");
const { getPhoneNumbers } = require("./phone-numbers");
// Parse command line arguments using yargs
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --sourceFile [sourceFile] --stage [stage] [--instanceId [instanceId] --profile [profile]]"
  )
  .demandOption(["region", "sourceFile", "stage"]) // region, sourceFile, and stage arguments required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("sourceFile", "Specify a source file") // description for the sourceFile argument
  .describe("instanceId", "Specify Amazon Connect instance Id") // description for the instanceId argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

let config = { region: argv.region, maxAttempts: 15};
let sourceFile = argv.sourceFile
const region = argv.region;
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);

if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}

const createOutboundConfig = (queueConfig, phoneNumbers, whisperFlows) => {
  const response = {};
  const { outboundCallerConfig } = queueConfig;
  // Add Caller Id Name to config if it exists
  if (outboundCallerConfig?.OutboundCallerIdName) {
    response.OutboundCallerIdName = outboundCallerConfig.OutboundCallerIdName;
  }
  // Add Caller Id Number to config if it exists
  if (outboundCallerConfig?.OutboundCallerIdNumberId) {
    response.OutboundCallerIdNumberId =
      phoneNumbers[outboundCallerConfig.OutboundCallerIdNumberId]?.Id;
  }
  // Add Whisper Flow to config if it exists
  if (outboundCallerConfig?.OutboundFlowId) {
    response.OutboundFlowId =
      whisperFlows[outboundCallerConfig.OutboundFlowId]?.Id;
  }
  return response;
};
const createQueue = async (
  queue,
  hoursOfOperations,
  phoneNumbers,
  whisperFlows
) => {
  const client = new ConnectClient(config);
  const { name, description, hoursOfOperation } = queue;
  const outboundCallerConfig = createOutboundConfig(
    queue,
    phoneNumbers,
    whisperFlows
  );
  const input = {
    InstanceId: instanceId,
    Description: description,
    Name: name,
    HoursOfOperationId: hoursOfOperations[hoursOfOperation].Id,
    OutboundCallerConfig: outboundCallerConfig,
  };
  console.log(input);
  const createQueueResponse = await client.send(new CreateQueueCommand(input));
  console.log(`✅ created queue ${name}`);
  return createQueueResponse;
};

const updateQueue = async (
  queueConfig,
  currentQueue,
  hoursOfOperations,
  whisperFlows,
  phoneNumbers
) => {
  const client = new ConnectClient(config);
  const queueId = currentQueue.QueueId;
  let update = false;
  if (queueConfig.description !== currentQueue.Description) {
    update = true;
    await client.send(
      new UpdateQueueNameCommand({
        InstanceId: instanceId,
        QueueId: queueId,
        Description: queueConfig.description,
      })
    );
  }

  const hoursId = hoursOfOperations[queueConfig.hoursOfOperation]?.Id;
  if (!hoursId) {
    console.error(
      `❌ Failed to update queue ${queueConfig.name} because hours of operation ${queueConfig.hoursOfOperation} does not exist.`
    );
  } else if (hoursId !== currentQueue.HoursOfOperationId) {
    update = true;
    await client.send(
      new UpdateQueueHoursOfOperationCommand({
        InstanceId: instanceId,
        QueueId: queueId,
        HoursOfOperationId: hoursOfOperations[queueConfig.hoursOfOperation].Id,
      })
    );
  }
  const outboundCallerConfig = createOutboundConfig(
    queueConfig,
    phoneNumbers,
    whisperFlows
  );
  const updateOutboundCallerConfig = !_.isEqual(
    outboundCallerConfig,
    currentQueue.OutboundCallerConfig ?? {}
  );
  if (updateOutboundCallerConfig) {
    update = true;
    await client.send(
      new UpdateQueueOutboundCallerConfigCommand({
        InstanceId: instanceId,
        QueueId: queueId,
        OutboundCallerConfig: outboundCallerConfig,
      })
    );
  }
  if (update) {
    console.log(`✅ updated queue ${queueConfig.name}`);
  } else {
    console.log(`ℹ️  no updates for queue ${queueConfig.name}`);
  }
};

const main = async () => {
  const connect = new ConnectClient(config);
  const queueConfigs = JSON.parse(fs.readFileSync(sourceFile, "utf8"));
  const currentQueues = await getQueues(connect, instanceId);
  const hoursOfOperations = await getHoursOfOperations(connect, instanceId);
  const phoneNumbers = await getPhoneNumbers(connect, instanceId);
  const whisperFlows = await getWhisperFlows(connect, instanceId);
  for await (queue of queueConfigs) {
    const { name } = queue;
    if (!currentQueues[name]) {
      await createQueue(queue, hoursOfOperations, phoneNumbers, whisperFlows);
    } else {
      await updateQueue(
        queue,
        currentQueues[name],
        hoursOfOperations,
        whisperFlows,
        phoneNumbers
      );
    }
  }
};
(async () => main())();
