const { paginateListHoursOfOperations } = require("@aws-sdk/client-connect");

/**
 * Retrieves the hours of operations for a given instance ID.
 *
 * @param {ConnectClient} connect - The ConnectClient object.
 * @param {string} instanceId - The ID of the instance to retrieve hours of operations for.
 * @returns {Object} - An object containing the hours of operations for the specified instance.
 */
const getHoursOfOperations = async (connect, instanceId) => {
  const paginator = paginateListHoursOfOperations(
    { client: connect },
    { InstanceId: instanceId }
  );
  const hoursOfOperationsList = [];
  for await (const response of paginator) {
    // process each page of results
    hoursOfOperationsList.push(...response.HoursOfOperationSummaryList);
  }
  const hoursOfOperations = hoursOfOperationsList.reduce((acc, hours) => {
    acc[hours.Name] = hours;
    return acc;
  }, {});
  return hoursOfOperations;
};

module.exports = { getHoursOfOperations };
