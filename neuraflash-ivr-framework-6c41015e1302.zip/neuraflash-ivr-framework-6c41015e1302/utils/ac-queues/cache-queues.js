const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { fromIni } = require("@aws-sdk/credential-providers");
const { getQueues } = require("./queues");
const { ConnectClient } = require("@aws-sdk/client-connect");
const { getWhisperFlows } = require("./contact-flows");
const { getHoursOfOperations } = require("./hours-of-operations");
const { getPhoneNumbers } = require("./phone-numbers");
const fs = require("fs");
const { getConnectInstanceId } = (require("ts-node/register"), require("../../config/config.ts"));

const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --stage [stage] [--instanceId [instanceId] --profile [profile]]"
  )
  .demandOption(["region", "stage"]) // region and stage arguments required
  .describe("region", "Specify AWS region") // description for the region argument
  .describe("instanceId", "Specify Amazon Connect instance Id") // description for the instanceId argument
  .describe("stage", "Specify stage to target the deployment to")
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

let config = { region: argv.region };
const instanceId = argv.instanceId || getConnectInstanceId(argv.stage, argv.region);

if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}
const main = async () => {
  const connect = new ConnectClient(config);

  const queues = await getQueues(connect, instanceId);
  const whisperFlows = await getWhisperFlows(connect, instanceId);
  const hoursOfOperations = await getHoursOfOperations(connect, instanceId);
  const phoneNumbers = await getPhoneNumbers(connect, instanceId);
  const orderedQueues = Object.keys(queues).sort();
  const queueList = [];
  for (const queue of orderedQueues) {
    const queueConfig = queues[queue];
    // console.log(queueConfig);
    const hoursName = Object.values(hoursOfOperations).find(
      (hours) => hours.Id === queueConfig.HoursOfOperationId
    ).Name;
    const outboundCallerConfig = {};
    // Add Caller Id Name to config if it exists
    if (queueConfig?.OutboundCallerConfig?.OutboundCallerIdName) {
      outboundCallerConfig.OutboundCallerIdName =
        queueConfig.OutboundCallerConfig.OutboundCallerIdName;
    }
    // Add Caller Id Number to config if it exists
    if (queueConfig?.OutboundCallerConfig?.OutboundCallerIdNumberId) {
      const phoneNumber = Object.values(phoneNumbers).find(
        (phoneNumber) =>
          phoneNumber.Id ===
          queueConfig.OutboundCallerConfig.OutboundCallerIdNumberId
      );
      console.log(phoneNumber);
      outboundCallerConfig.OutboundCallerIdNumberId = phoneNumber.description;
    }
    // Add Whisper Flow to config if it exists
    if (queueConfig?.OutboundCallerConfig?.OutboundFlowId) {
      const whisperFlow = Object.values(whisperFlows).find(
        (whisperFlow) =>
          whisperFlow.Id === queueConfig.OutboundCallerConfig.OutboundFlowId
      );
      outboundCallerConfig.OutboundFlowId = whisperFlow.Name;
    }
    const refQueue = {
      name: queueConfig.Name,
      description: queueConfig.Description,
      hoursOfOperation: hoursName,
      outboundCallerConfig
    };
    queueList.push(refQueue);
  }
  fs.writeFileSync(
    "data/queues.json",
    JSON.stringify(queueList, null, 2),
    (err) => {
      if (err) {
        console.error(`Failed to cache queues:${err}`);
      }
    }
  );
};

main();
