const {
    paginateListPhoneNumbers,
    DescribePhoneNumberCommand,
  } = require("@aws-sdk/client-connect");

  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  const getPhoneNumbers = async (connect, instanceId) => {
    const paginator = paginateListPhoneNumbers(
      { client: connect },
      { InstanceId: instanceId }
    );
    const phoneNumbersList = [];
    for await (const response of paginator) {
      // process each page of results
      phoneNumbersList.push(...response.PhoneNumberSummaryList);
    }
    for (const phoneNumber of phoneNumbersList) {
      await sleep(200); 
      const describePhoneNumberResponse = await connect.send(
        new DescribePhoneNumberCommand({
          InstanceId: instanceId,
          PhoneNumberId: phoneNumber.Id
        })
      );
      phoneNumber["description"] =
        describePhoneNumberResponse["ClaimedPhoneNumberSummary"][
          "PhoneNumberDescription"
        ];
      if (!phoneNumber["description"]) {
        phoneNumber["description"] =
          describePhoneNumberResponse["ClaimedPhoneNumberSummary"]["PhoneNumber"];
      }
    }
    const phoneNumbers = phoneNumbersList.reduce((acc, phoneNumber) => {
      acc[phoneNumber.description] = phoneNumber;
      return acc;
    }, {});
    return phoneNumbers;
  };
  
  module.exports = { getPhoneNumbers };