# AWS Create Queues from CSV

This directory contains a node.js script that creates queues from CSV.

## Prerequisites

- node.js (version: `node -v` | install: `brew install node`)
- node package manager (version: `npm -v` | install: `brew install npm`)

## How to use the scripts

### Create Routing profiles from CSV:

The `ac-queues.js` script creates routing profiles from CSV. The script accepts the following command line arguments:

`--profile`: Name of the AWS profile to use (optional)
`--region`: Region of AWS Instance
`--instanceId`: ID of AWS Connect instance
`--sourceFile`: File of CSV


Before running the script:

1. Open a terminal and navigate to the directory where the script is saved.
2. Execute `npm i` to install necessary modules

To use the script, run the following command:

`node ac-queues.js --region <region> --instanceId <insatnce id> --sourceFile <file path>`

### CSV Structure
The CSV should have queue names in one column. Optionally, have hours of operation names in another column, associating hours of operations with each queue. By default, `DEFAULT_HOURS_OF_OPERATION_NAME = 'Basic Hours'` is assigned to each queue.
An example CSV is included in the data folder.


### Configuring Script

`const DEFAULT_HOURS_OF_OPERATION_NAME` Enter the default hours of operation name for queues
`const START_ROW` Enter the row number containing the header for all the queue names. This is one indexed, so the first row in the sheet = 1 (not zero), second = 2, so on.
`const QUEUE_NAME_HEADER` Enter the header of the column containing all the queue names.
`const HOURS_OF_OPERATION_HEADER` Optionally. Enter the header of the column containing all the hours of operation names. Leaving this blank will use the hours of operations specified in `DEFAULT_HOURS_OF_OPERATION_NAME`

### How the script works
The script reads the each row, grabbing the queue name from the `QUEUE_NAME_HEADER` column and if populated, the hours of operation name from the `HOURS_OF_OPERATION_HEADER` column.