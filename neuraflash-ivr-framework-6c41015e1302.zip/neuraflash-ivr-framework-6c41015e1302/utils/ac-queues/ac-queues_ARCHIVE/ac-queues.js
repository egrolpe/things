const fs = require("fs");
const { parse } = require("csv-parse");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");
const { fromIni } = require("@aws-sdk/credential-providers");

const DEFAULT_HOURS_OF_OPERATION_NAME = "Basic Hours";
const START_ROW = 1; //one indexed, so starting at 1, 2, 3..
const QUEUE_NAME_HEADER = "Revised 9/5/2023";
const HOURS_OF_OPERATION_HEADER = "";

const {
  ConnectClient,
  CreateQueueCommand,
  ListHoursOfOperationsCommand
} = require("@aws-sdk/client-connect");
// Parse command line arguments using yargs
const argv = yargs(hideBin(process.argv))
  .usage(
    "Usage: $0 --region [region] --instanceId [instanceId] [--profile [profile]]"
  )
  .demandOption(["region"]) // region argument required
  .describe("region", "Specify AWS region") // description for the region argument
  .demandOption(["sourceFile"]) // tableName argument required
  .describe("sourceFile", "Specify csv file to convert to DDB JSon") // description for the tableName argument
  .describe("instanceId", "Specify Amazon Connect instance ID") // description for the instanceID argument
  .describe("profile", "Optionally specify AWS profile").argv; // description for the profile argument

let sourceItemsPath = `./data_input_csv/input.csv`;
if (argv.sourceFile) {
  sourceItemsPath = argv.sourceFile;
}

// Set AWS SDK configuration
let config = { region: argv.region };
if (argv.profile) {
  config = { ...config, credentials: fromIni({ profile: argv.profile }) }; // profile specified for command line arguments
}
const connectClient = new ConnectClient(config);
const instanceId = argv.instanceId;

const destinationHoursOfOperation = {};
async function getDestinationHoursOfOperation() {
  if (Object.keys(destinationHoursOfOperation).length > 0) {
    return destinationHoursOfOperation;
  } else {
    let nextToken = null;
    do {
      const command = new ListHoursOfOperationsCommand({
        InstanceId: instanceId,
        NextToken: nextToken
      });
      const response = await connectClient.send(command);
      nextToken = response.NextToken;
      response.HoursOfOperationSummaryList.forEach((element) => {
        destinationHoursOfOperation[element.Name] = element;
      });
    } while (nextToken);

    return destinationHoursOfOperation;
  }
}

async function createQueues() {
  let colIndexMap = {};
  let lineNum = START_ROW - 1;

  fs.createReadStream(sourceItemsPath)
    .pipe(parse({ delimiter: ",", from_line: START_ROW }))
    .on("data", async function (row) {
      if (++lineNum == START_ROW) {
        for (let i = 0; i < row.length; i++) {
          colIndexMap[row[i]] = i;
        }
        // console.log(colIndexMap);
      } else {
        const queueName = row[colIndexMap[QUEUE_NAME_HEADER]];
        if (queueName) {
          const hoursOfOperationName =
            row[colIndexMap[HOURS_OF_OPERATION_HEADER]];
          const hoursOfOperationId =
            destinationHoursOfOperation[hoursOfOperationName]?.Id ||
            destinationHoursOfOperation[DEFAULT_HOURS_OF_OPERATION_NAME]?.Id;
          try {
            const command = new CreateQueueCommand({
              HoursOfOperationId: hoursOfOperationId,
              InstanceId: instanceId,
              Name: queueName
            });

            const response = await connectClient.send(command);
            console.log(`✅ Queue "${queueName}" created`);
          } catch (error) {
            if (error.name === "DuplicateResourceException") {
              console.error(
                `❌ Error deploying Queue "${queueName}": Resource already exists`
              );
            } else {
              console.error(`❌ Error deploying Queue "${queueName}":`, error);
            }
          }
        }
      }
    })
    .on("close", function () {
      // console.log('Closed file');
    });
}

async function main() {
  try {
    await getDestinationHoursOfOperation();
    await createQueues();
  } catch (error) {
    console.error("❌ An error occurred:", error);
  }
}

main();
