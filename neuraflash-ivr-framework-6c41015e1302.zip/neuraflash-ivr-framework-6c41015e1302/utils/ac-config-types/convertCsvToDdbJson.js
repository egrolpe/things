const fs = require("fs");
const { parse } = require("csv-parse");

// parse command line arguments using yargs
const argv = require("yargs/yargs")(process.argv.slice(2))
  .usage("Usage: $0 --sourceFile [name]")
  .demandOption(["sourceFile"]) // tableName argument required
  .describe("sourceFile", "Specify csv file to convert to DDB JSon") // description for the tableName argument
  .describe(
    "destinationFile",
    "optionally specify a destination to write to"
  ).argv; // description for the sourceFile optional argument

let sourceItemsPath = `./data_input_csv/input.csv`;
if (argv.sourceFile) {
  sourceItemsPath = argv.sourceFile;
}

let destinationItemsPath = `./data_output_json/output.json`;
if (argv.destinationFile) {
  destinationItemsPath = argv.destinationFile;
}

let lineNum = 0;
let colIndexMap = {};
let ddbTableAsArr = [];
let indexings = new Set();
fs.createReadStream(sourceItemsPath)
  .pipe(parse({ delimiter: ",", from_line: 1 }))
  .on("data", function (row) {
    if (++lineNum == 1) {
      for (let i = 0; i < row.length; i++) {
        colIndexMap[row[i]] = i;
      }
    } else {
      if (
        row[colIndexMap["Indexing"]] == "" ||
        indexings.has(row[colIndexMap["Indexing"]])
      ) {
        console.log(
          `Row ${lineNum}: ${
            row[colIndexMap["Indexing"]]
          } is a duplicate or blank key`
        );
      } else {
        indexings.add(row[colIndexMap["Indexing"]]);
        let configEntry = {};
        for (const attr of Object.keys(colIndexMap)) {
          if (
            row[colIndexMap[attr]].toLowerCase() === "true" ||
            row[colIndexMap[attr]].toLowerCase() === "false"
          ) {
            configEntry[attr] = {
              BOOL: row[colIndexMap[attr]].toLowerCase() === "true"
            };
          } else {
            configEntry[attr] = {
              S: row[colIndexMap[attr]]
            };
          }
        }
        ddbTableAsArr.push(configEntry);
      }
    }
  })
  .on("close", function () {
    fs.writeFile(destinationItemsPath, JSON.stringify(ddbTableAsArr), (err) => {
      if (err) {
        console.error(err);
      }
    });
  });
