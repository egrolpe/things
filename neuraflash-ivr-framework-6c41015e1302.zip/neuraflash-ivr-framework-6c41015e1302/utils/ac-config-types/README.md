# AWS DynamoDB Config Convert CSV to DynamoDB

This directory contains one node.js script. This script takes a config CSV and converts it to a JSON file DDB can ingest.

## Prerequisites

- node.js (version: `node -v` | install: `brew install node`)
- node package manager (version: `npm -v` | install: `brew install npm`)

## How to use the scripts

### Converting CSV to JSON:

The `convertCsvToDdbJson.js` script exports data from a specified DynamoDB table to a JSON file. The script accepts the following command line arguments:

`--sourceFile`: File path of the source CSV (required)

`--destinationFile`: File path where the destination JSON file should be saved(optional)

Before running the script:

1. Open a terminal and navigate to the directory where the script is saved.
2. Execute `npm i` to install necessary modules

To use the script, run the following command:

`node convertCsvToDdbJson.js --sourceFile <source_file>`

Optionally, include the destination file name:

`node convertCsvToDdbJson.js --sourceFile <source_file> --destinationFile <destination_file>`

example -
`node convertCsvToDdbJson.js --sourceFile input/DialogStates.csv --destinationFile output/DialogStates.json`
`node convertCsvToDdbJson.js --sourceFile input/Prompts.csv --destinationFile output/Prompts.json`
`node convertCsvToDdbJson.js --sourceFile input/Globals.csv --destinationFile output/Globals.json`

## CSV File Structure

### DialogStates.csv

This CSV file contains dialog state configurations for Amazon Lex bots. Each row represents a dialog state with the following columns:

- **Typing**: The type of entry (typically "dialogState")
- **Indexing**: Unique identifier for the dialog state (used as the primary key)
- **dialog_name**: Name of the dialog state
- **bot_name**: Name of the associated Lex bot
- **supported_intents**: Semicolon-separated list of supported intents
- **supported_contexts**: Contexts supported by this dialog state
- **resolve_conflict**: Conflict resolution strategy
- **required_slots**: Required slots for the dialog state
- **optional_slots**: Optional slots for the dialog state
- **initial_prompt_indexing**: Reference to the initial prompt
- **retry_prompt_1_indexing**: Reference to the first retry prompt
- **retry_prompt_2_indexing**: Reference to the second retry prompt
- **dtmf_option_0** through **dtmf_option_9**: DTMF options for keypad input
- **x-amz-lex:allow-interrupt:*:*:***: Whether interrupts are allowed
- **x-amz-lex:audio:start-timeout-ms:*:*:***: Audio start timeout in milliseconds
- **x-amz-lex:audio:end-timeout-ms:*:*:***: Audio end timeout in milliseconds
- **x-amz-lex:audio:max-length-ms:*:*:***: Maximum audio length in milliseconds
- **x-amz-lex:dtmf:start-timeout-ms:*:*:***: DTMF start timeout in milliseconds
- **x-amz-lex:dtmf:end-timeout-ms:*:*:***: DTMF end timeout in milliseconds
- **x-amz-lex:text:start-timeout-ms:*:*:***: Text start timeout in milliseconds
- **x-amz-lex:text:end-timeout-ms:*:*:***: Text end timeout in milliseconds

**Notes:**
- The "Indexing" column must contain unique values and cannot be blank
- Boolean values should be entered as "true" or "false" (case-insensitive)
- All other values are treated as strings

### Prompts.csv

This CSV file contains prompt configurations for voice responses. Each row represents a prompt with the following columns:

- **Typing**: The type of entry (typically "prompt")
- **Indexing**: Unique identifier for the prompt (used as the primary key)
- **language**: Language code (e.g., "en-US")
- **name**: Name of the prompt
- **prompt_value**: The actual text content of the prompt

**Notes:**
- The "Indexing" column must contain unique values and cannot be blank
- Prompts can be in different languages using appropriate language codes
- The prompt_value can contain the full text that will be spoken by the voice system
