#!/bin/bash

set -xe

export CLIENT_PREFIX=$1
export STAGE=$2
export AWS_REGION=$3

npm install

# import dynamodb data
cd utils/ac-ddb-export-and-import/
npm i
node exportTable.js --region "$AWS_REGION" --tableName "$CLIENT_PREFIX"-"$STAGE"-"$AWS_REGION"-config
node cleanHardCodedValuesOfExport.js --inputFileName ./data/"$CLIENT_PREFIX"-"$STAGE"-"$AWS_REGION"-config_items.json
cd ../../

# get prompts saved in s3 bucket
cd utils/ac-prompts/
npm i
node cache-prompts.js --region "$AWS_REGION" --stage "$STAGE"
cd ../../

# get queue
cd utils/ac-queues/
npm i
node cache-queues --region "$AWS_REGION" --stage "$STAGE"
cd ../../

# get contact flows and module
cd utils/ac-resources/
npm i
node ac-get-views.js --region "$AWS_REGION" --stage "$STAGE"
node ac-get-flow-modules --region "$AWS_REGION" --stage "$STAGE"
node ac-get-flows --region "$AWS_REGION"  --stage "$STAGE" --tableName "$CLIENT_PREFIX"-"$STAGE"-"$AWS_REGION"-config
cd ../../

# get routing profiles
cd utils/ac-routing-profiles/
npm i
node cache-routing-profiles --region "$AWS_REGION" --stage "$STAGE" 
cd ../../

# get security profiles
cd utils/ac-security-profiles/
npm i
node getSecurityProfiles.js --region "$AWS_REGION" --stage "$STAGE" 
cd ../../

# get agent statuses
cd utils/ac-agent-statuses/
npm i
node cache-agent-statuses.js --region "$AWS_REGION" --stage "$STAGE" 
cd ../..

# get user hierarchy and user group
cd utils/ac-user-hierarchy/
npm i
node cache-user-hierarchy.js --region "$AWS_REGION" --stage "$STAGE"
node cache-user-group.js --region "$AWS_REGION" --stage "$STAGE"  
cd ../../
