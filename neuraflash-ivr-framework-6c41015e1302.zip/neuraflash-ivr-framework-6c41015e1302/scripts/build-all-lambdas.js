// Generalized esbuild script to bundle all Lambda entrypoints in src/lambdas/*/index.js
const esbuild = require('esbuild');
const fs = require('fs');
const path = require('path');

const lambdasDir = path.resolve(__dirname, '../src/lambdas');
const distDir = path.resolve(__dirname, '../dist');

console.log(`stage: ${process.env.stage}`);

const minify = process.env.stage === 'prod'; // don't minify for non-prod 
const sourcemap = process.env.stage === 'prod'; // add sourcemap for prod

function findLambdaEntryPoints() {
  return fs.readdirSync(lambdasDir, { withFileTypes: true })
    .filter(d => d.isDirectory())
    .map(d => ({
      name: d.name,
      entry: path.join(lambdasDir, d.name, 'index.js'),
      outdir: path.join(distDir, d.name),
    }))
    .filter(({ entry }) => fs.existsSync(entry));
}

async function bundleAll() {
  // empty the dist directory
  if (fs.existsSync(distDir)) {
    console.log(`emptying ${distDir}`);
    fs.rmSync(distDir, { recursive: true })
  }

  const lambdas = findLambdaEntryPoints();
  for (const lambda of lambdas) {
    console.log(`Bundling ${lambda.name}...`);
    await esbuild.build({
      entryPoints: [lambda.entry],
      bundle: true,
      platform: 'node',
      target: 'node22',
      outfile: path.join(lambda.outdir, 'index.js'),
      minify,
      sourcemap,
      external: ['@aws-sdk/*'],
      treeShaking: true,
      logLevel: 'info',
    });
  }
}

bundleAll().catch(e => { console.error(e); process.exit(1); });
