#!/bin/bash

# if $STAGE is undefined exit with error
export STAGE=$1;
export AWS_REGION=$2

if [ "$STAGE" != dev ] && [ "$STAGE" != int ] && [ "$STAGE" != qa ] && [ "$STAGE" != perf ] && [ "$STAGE" != prod ]; then
    echo "Usage: $0 [dev|int|qa|perf|prod]";
    exit 1;
    fi

npm i && npm audit fix
npm run build-lambdas

npx cdk synth -c config=$STAGE
npx cdk deploy --all --require-approval never -c config=$STAGE




