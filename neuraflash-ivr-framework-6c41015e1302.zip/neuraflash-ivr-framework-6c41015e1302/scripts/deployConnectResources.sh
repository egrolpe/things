#!/bin/bash

set -xe

export CLIENT_PREFIX=$1

export STAGE=$2;

export AWS_REGION=$3


npm install

# import dynamodb data
cd utils/ac-config-types
npm i
node convertCsvToDdbJson.js --sourceFile input/DialogStates.csv --destinationFile output/DialogStates.json
node convertCsvToDdbJson.js --sourceFile input/Prompts.csv --destinationFile output/Prompts.json
cd ../../

cd utils/ac-ddb-export-and-import/
npm i
node importTable.js --region "$AWS_REGION" --tableName "$CLIENT_PREFIX"-"$STAGE"-"$AWS_REGION"-config --sourceFile ../ac-config-types/output/Prompts.json
node importTable.js --region "$AWS_REGION" --tableName "$CLIENT_PREFIX"-"$STAGE"-"$AWS_REGION"-config --sourceFile ../ac-config-types/output/DialogStates.json
cd ../../


# create lex bots

## install dependencies
cd utils/sdk/ && npm i && cd ../lex-build-directories && npm i
cd lex-bot-deployment

## create router bot
node generate_bot_details.js --botTemplate "./config_bot_template_router.json"  \
--en_US_slotTypes "../lex-csv/router-bot/en_slotTypes.csv"  \
--en_US_intents "../lex-csv/router-bot/en_intents.csv"  \
--outputFile './bot_details_router.json'

bash run.sh --region "$AWS_REGION" --botDetailsFile './bot_details_router.json' \
    --roleDetailsFile ./config_lex_role_details.json --stage "$STAGE"

cd ../../../

# ## create router2 bot - Scenario 2 - Bot with Global Intents & SlotTypes
# node generate_bot_details.js --botTemplate "./config_bot_template_router2.json"  \
# --en_US_global_slotTypes "../lex-csv/globals/en_slotTypes.csv"  \
# --en_US_global_intents "../lex-csv/globals/en_intents.csv"  \
# --en_US_slotTypes "../lex-csv/router2-bot/en_slotTypes.csv"  \
# --en_US_intents "../lex-csv/router2-bot/en_intents.csv"  \
# --outputFile './bot_details_router2.json'

# bash run.sh --region "$AWS_REGION" --botDetailsFile './bot_details_router2.json' \
#     --roleDetailsFile ./config_lex_role_details.json --stage "$STAGE"
    
# cd ../../../

# ## create router3 bot - Scenario 3 - Multilingual Bot with Global Intents & SlotTypes
# node generate_bot_details.js --botTemplate "./config_bot_template_router3.json"  \
# --en_US_global_slotTypes "../lex-csv/globals/en_slotTypes.csv"  \
# --en_US_global_intents "../lex-csv/globals/en_intents.csv"  \
# --es_US_global_slotTypes "../lex-csv/globals/es_slotTypes.csv"  \
# --en_US_global_intents "../lex-csv/globals/es_intents.csv"  \
# --en_US_slotTypes "../lex-csv/router3-bot/en_slotTypes.csv"  \
# --en_US_intents "../lex-csv/router3-bot/en_intents.csv"  \
# --es_US_slotTypes "../lex-csv/router3-bot/es_slotTypes.csv"  \
# --es_US_intents "../lex-csv/router3-bot/es_intents.csv"  \
# --outputFile './bot_details_router3.json'

# bash run.sh --region "$AWS_REGION" --botDetailsFile './bot_details_router3.json' \
#     --roleDetailsFile ./config_lex_role_details.json --stage "$STAGE"
    
# cd ../../../

# # enable cloudwatch logs
# cd utils/ac-enable-logs/
# npm i
# node enable-logs.js --region "$AWS_REGION" --stage "$STAGE"
# cd ../../

# # import dynamodb data
# cd utils/ac-ddb-export-and-import/
# npm i
# node importTable.js --region "$AWS_REGION" --tableName "$CLIENT_PREFIX"-"$STAGE"-"$AWS_REGION"-config --sourceFile ./data/ddb_export_cleaned.json
# cd ../../

# # run connect sync lambda to update ARNs
# cd utils/ac-invoke-lambda/
# npm i
# node invoke-lambda.js --region "$AWS_REGION" --functionName "$CLIENT_PREFIX"-"$STAGE"-"$AWS_REGION"-connect-sync
# cd ../../

# cd utils/ac-prompts/
# npm i
# node deploy-prompts.js --region "$AWS_REGION" --stage "$STAGE"
# cd ../../

# # create queue
# cd utils/ac-queues/
# npm i
# node deploy-queues --region "$AWS_REGION" --stage "$STAGE"
# cd ../../

# # create user hierarchy and user group
# cd utils/ac-user-hierarchy/
# npm i
# node deploy-user-hierarchy.js --region "$AWS_REGION" --stage "$STAGE"
# node deploy-user-group.js --region "$AWS_REGION" --stage "$STAGE"
# cd ../../

# # create agent statuses
# cd utils/ac-agent-statuses/
# npm i
# node deploy-agent-stauses.js --region "$AWS_REGION" --stage "$STAGE"
# cd ../../

# # create routing profiles
# cd utils/ac-routing-profiles/
# npm i
# node deploy-routing-profiles --region "$AWS_REGION" --stage "$STAGE"
# cd ../../

# # create security profiles
# cd utils/ac-security-profiles/
# npm i
# node deploySecurityProfiles.js --region "$AWS_REGION" --stage "$STAGE" 
# cd ../../

# # deploy contact flows and module
# cd utils/ac-resources/
# npm i
# node ac-deploy-views.js --region "$AWS_REGION" --stage "$STAGE"
# node ac-deploy-flow-modules --tableName "$CLIENT_PREFIX"-"$STAGE"-"$AWS_REGION"-config --region "$AWS_REGION" --stage "$STAGE"
# node ac-deploy-flows --region "$AWS_REGION" --tableName "$CLIENT_PREFIX"-"$STAGE"-"$AWS_REGION"-config --stage "$STAGE" 
# cd ../../

# # create phone numbers
# cd utils/ac-phone-numbers/
# npm i
# node create-phone-numbers  --region "$AWS_REGION" --filePath phone_numbers_config.csv --stage "$STAGE"
# cd ../../

# # run connect sync lambda to update ARNs
# cd utils/ac-invoke-lambda/
# npm i
# node invoke-lambda.js --region "$AWS_REGION" --stage "$STAGE" --functionName "$CLIENT_PREFIX"-"$STAGE"-"$AWS_REGION"-connect-sync
# cd ../../

# # create quick connects
# cd utils/ac-quick-connects/
# npm i
# node ac-quick-connects.js --qcType agent --region "$AWS_REGION" --stage "$STAGE" --agentCsvFile agents/agents.csv
# node ac-quick-connects.js --qcType external --region "$AWS_REGION" --stage "$STAGE" --externalCsvFile external/external.csv
# node ac-quick-connects.js --qcType queue --region "$AWS_REGION" --stage "$STAGE" --queueCsvFile queues/queues.csv
# node ac-associate-qc.js --region "$AWS_REGION" --stage "$STAGE" --qcCsv ac-associations.csv --queueName "Quick Connects"
# cd ../../

# # Create LexBot Analysis Cloudwatch Dashboard
# cd utils/lex-dashboard/
# npm i
# node put-dashboard.js --region "$AWS_REGION" --dashboardName "$CLIENT_PREFIX"-"$STAGE"-LexBotAnalysisDashboard --dashboardFilePath lex-dashboard-config.json
# cd ../../

