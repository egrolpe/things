import { App } from 'aws-cdk-lib';
import { resolve } from 'path';
import { ConnectLamdaProps } from '../lib/connect-lambdas';

export interface RegionConfig {
  region: string;
  connectInstanceId: string;
  connectInstanceAlias?: string;
}

export interface Config {
  readonly accountNumber: string;
  readonly clientPrefix: string;
  readonly stage: string;
  readonly environmentTag: string;
  readonly snsSubscriptionEmail: string;
  readonly connectLambdasProps?: Pick<
    ConnectLamdaProps,
    'LambdaProvisionedConcurrencyScalingConfig'
  >;
  readonly regions: RegionConfig[];
}

export interface DeployConfig extends Omit<Config, 'regions'>, RegionConfig {}

/**
 * Get the regional config for the specified region or return all regions configured
 * @param config The config object
 * @param region The region to get the config for
 * @returns RegionConfig[]
 */
const getRegionConfig = (config: Config, region?: string): RegionConfig[] => {
  // if no region is specified, then just return the regions config as is
  if (!region) {
    return config.regions;
  }

  // find the region config based on the cdk context variable passed in
  const regionConfig = config.regions.find(
    (regionalConfig: RegionConfig) => regionalConfig.region === region
  );
  if (!regionConfig) {
    throw new Error(`No config found for region ${region}`);
  }

  return [regionConfig];
};

/**
 * @param env The environment to get the config for
 * @example getConfigFromFile('dev')
 * @returns Config
 */
export function getConfigFromFile(env: string): Config {
  const filepath = resolve(__dirname, `${env}.ts`);
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const config = require(filepath);
  if (!config.config) {
    throw new Error(`config object must be export of file\n${filepath}`);
  }
  return config.config;
}

// getConfig reads the config file and returns the config object
export const getConfig = (app: App): Config => {
  const env = app.node.tryGetContext('stage');
  if (!env)
    throw new Error(
      'Context variable missing on CDK command. Pass in as `-c stage=XXX`'
    );

  const baseConfig = getConfigFromFile(env);
  const region = app.node.tryGetContext('region');
  const regionConfig = getRegionConfig(baseConfig, region);
  const config: Config = {
    ...baseConfig,
    regions: regionConfig,
  };

  console.log('config:', JSON.stringify(config, null, 2));
  return config;
};

/**
 * Get the Connect instance ID for the specified stage and region
 * @param stage The stage to get the config for (e.g., 'dev', 'prod')
 * @param region The region to get the instance ID for
 * @returns The Connect instance ID
 */
export const getConnectInstanceId = (stage: string, region: string): string => {
  const config = getConfigFromFile(stage);
  const regionConfig = config.regions.find(
    (regionalConfig: RegionConfig) => regionalConfig.region === region
  );
  if (!regionConfig) {
    throw new Error(`No config found for region ${region} in stage ${stage}`);
  }
  return regionConfig.connectInstanceId;
};
