const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
  DynamoDBDocumentClient,
  QueryCommand,
  PutCommand,
  DeleteCommand
} = require("@aws-sdk/lib-dynamodb");
const {
  ConnectClient,
  ListQueuesCommand,
  ListContactFlowsCommand,
  ListContactFlowModulesCommand
} = require("@aws-sdk/client-connect");
const {
  LambdaClient,
  ListFunctionsCommand
} = require("@aws-sdk/client-lambda");
const {
  LexModelsV2Client,
  ListBotsCommand,
  ListBotAliasesCommand
} = require("@aws-sdk/client-lex-models-v2");

const instanceMap = {
  [process.env.REGION]: process.env.INSTANCE_ID.split("/")[1]
};

console.log(`instanceMap: ${JSON.stringify(instanceMap)}`);

async function getConnectQueues(config, region, instanceId) {
  const client = new ConnectClient({ ...config, region });
  const queues = [];
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      QueueTypes: ["STANDARD"],
      NextToken: nextToken
    };
    const command = new ListQueuesCommand(input);
    const response = await client.send(command);
    queues.push(...response.QueueSummaryList);
    nextToken = response.NextToken;
  } while (nextToken);
  return queues.map((item) => {
    return { ...item, Name: item.Name };
  });
}

async function getConnectFlows(config, region, instanceId) {
  const client = new ConnectClient({ ...config, region });
  const contactFlows = [];
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      NextToken: nextToken
    };
    const command = new ListContactFlowsCommand(input);
    const response = await client.send(command);
    contactFlows.push(...response.ContactFlowSummaryList);
    nextToken = response.NextToken;
  } while (nextToken);
  return contactFlows;
}

async function getConnectFlowModules(config, region, instanceId) {
  const client = new ConnectClient({ ...config, region });
  const contactFlowModules = [];
  let nextToken = null;
  do {
    const input = {
      InstanceId: instanceId,
      NextToken: nextToken
    };
    const command = new ListContactFlowModulesCommand(input);
    const response = await client.send(command);
    contactFlowModules.push(...response.ContactFlowModulesSummaryList);
    nextToken = response.NextToken;
  } while (nextToken);
  return contactFlowModules;
}

async function getLambdas(region) {
  // Set up the Lambda client
  const lambdaClient = new LambdaClient({ region });

  let nextMarker;
  let lambdas = [];

  do {
    const command = new ListFunctionsCommand({ Marker: nextMarker });

    // Retrieve list of Lambda functions
    const response = await lambdaClient.send(command);
    // console.log(response);
    // Extract ARNs from the response
    const filteredlambdas = response.Functions.filter((func) =>
      func.FunctionName.startsWith(process.env.LAMBDA_PREFIX)
    );
    const mappedLambdas = filteredlambdas.map((lambdaData) => {
      return {
        ...lambdaData,
        Name: lambdaData.FunctionName,
        Arn: `${lambdaData.FunctionArn}:${process.env.BOT_ALIAS_NAME}`
      };
    });
    lambdas = lambdas.concat(mappedLambdas);

    // Update the nextMarker for the next iteration
    nextMarker = response.NextMarker;
  } while (nextMarker);

  // console.log("All filtered Lambda:", lambdas);
  return lambdas;
}

async function getLexBots(region) {
  // Set up the LexModelsV2 client
  const lexClient = new LexModelsV2Client({ region });

  const botAliases = [];
  let nextToken;

  do {
    const listBotsCommand = new ListBotsCommand({
      nextToken: nextToken
    });

    const listBotsResponse = await lexClient.send(listBotsCommand);
    // console.log("listBotsResponse", listBotsResponse);
    const allBots = listBotsResponse.botSummaries || [];

    for (const bot of allBots) {
      // console.log("bot", bot);
      if (bot.botName.startsWith(process.env.LEX_PREFIX)) {
        const listBotAliasesCommand = new ListBotAliasesCommand({
          botId: bot.botId
        });

        const aliasesResponse = await lexClient.send(listBotAliasesCommand);
        // console.log("aliasesResponse", aliasesResponse);
        let aliases = aliasesResponse.botAliasSummaries.filter(
          (alias) => alias.botAliasName === process.env.BOT_ALIAS_NAME
        );
        aliases = aliases.map((alias) => {
          return {
            Name: bot.botName.toLowerCase(),
            Arn: `arn:aws:lex:${process.env.REGION}:${process.env.ACCOUNT_ID}:bot-alias/${bot.botId}/${alias.botAliasId}`
          };
        });
        botAliases.push(...aliases);
      }
    }

    nextToken = listBotsResponse.nextToken;
  } while (nextToken);

  // console.log("All Bot Alias ARNs:", botAliases);
  return botAliases;
}

async function getDynamoData(config, tableName, objectIndexingPrefix) {
  const client = new DynamoDBClient(config);
  const ddbDocClient = DynamoDBDocumentClient.from(client, {
    marshallOptions: {
      convertEmptyValues: false,
      removeUndefinedValues: true,
      convertClassInstanceToMap: false
    },
    unmarshallOptions: {
      wrapNumbers: false
    }
  });
  try {
    const command = new QueryCommand({
      TableName: `${tableName}`,
      KeyConditionExpression:
        "#typing = :typing AND begins_with(#indexing, :indexing)",
      ExpressionAttributeNames: {
        "#typing": "Typing",
        "#indexing": "Indexing"
      },
      ExpressionAttributeValues: {
        ":typing": "arn",
        ":indexing": objectIndexingPrefix
      }
    });
    const results = await ddbDocClient.send(command);
    // console.log(results.Items);
    return results.Items;
  } catch (err) {
    console.error(err);
  }
}

function getDeltas(itemType, dynamoItems, connectItems) {
  let connectMap = {};
  let dymanoMap = {};

  for (const item of dynamoItems) {
    dymanoMap[item.Indexing] = item;
  }
  for (const item of connectItems) {
    connectMap[`${itemType}#${item.Name.replace(/ /g, "_").toLowerCase()}`] =
      item;
  }

  const deletedIndexingsSet = new Set(
    Object.keys(dymanoMap).filter((x) => !(x in connectMap))
  );
  const upToDateIndexingsSet = new Set();

  const modifiedItems = connectItems.reduce(function (filtered, item) {
    let connectIndexing = `${itemType}#${item.Name.replace(
      / /g,
      "_"
    ).toLowerCase()}`;
    let dynamoItemArn = dymanoMap[connectIndexing]?.arn;
    if (item.Arn !== dynamoItemArn) {
      // add items whose arns do not match
      filtered.push({
        ...item,
        Indexing: connectIndexing,
        arn: item.Arn
      });
    } else {
      upToDateIndexingsSet.add(connectIndexing);
    }
    return filtered;
  }, []);

  return {
    modifiedItems,
    upToDateIndexingsSet,
    deletedIndexingsSet
  };
}

async function syncQueueArns(config, tableName, dynamoQueues, connectQueues) {
  const { modifiedItems, upToDateIndexingsSet, deletedIndexingsSet } =
    getDeltas("queue", dynamoQueues, connectQueues);
  const client = new DynamoDBClient(config);
  const ddbDocClient = DynamoDBDocumentClient.from(client, {
    marshallOptions: {
      convertEmptyValues: false,
      removeUndefinedValues: true,
      convertClassInstanceToMap: false
    },
    unmarshallOptions: {
      wrapNumbers: false
    }
  });

  [...upToDateIndexingsSet].forEach((indexing) =>
    console.log(`ℹ️  ${indexing} arn is already up to date in DDB`)
  );

  // handle modified items
  for (const item of modifiedItems) {
    try {
      const putCmd = new PutCommand({
        TableName: tableName,
        Item: {
          Typing: "arn",
          Indexing: item.Indexing,
          arn: item.arn
        }
      });
      await ddbDocClient.send(putCmd);
      console.log(`✅ ${item.Name} updated in DDB`);
    } catch (err) {
      console.error(err);
    }
  }

  // handle deleted items
  for (const indexing of deletedIndexingsSet) {
    try {
      const deleteCmd = new DeleteCommand({
        TableName: tableName,
        Key: {
          Typing: "arn",
          Indexing: indexing
        }
      });
      await ddbDocClient.send(deleteCmd);
      console.log(`🔥 ${indexing} deleted from DDB`);
    } catch (err) {
      console.error(err);
    }
  }

  console.log(
    `${upToDateIndexingsSet.size} untouched, ${modifiedItems.length} modified, ${deletedIndexingsSet.size} deleted`
  );
}

async function syncContactFlowArns(
  config,
  tableName,
  dynamoFlows,
  connectFlows
) {
  const { modifiedItems, upToDateIndexingsSet, deletedIndexingsSet } =
    getDeltas("flow", dynamoFlows, connectFlows);
  const client = new DynamoDBClient(config);
  const ddbDocClient = DynamoDBDocumentClient.from(client, {
    marshallOptions: {
      convertEmptyValues: false,
      removeUndefinedValues: true,
      convertClassInstanceToMap: false
    },
    unmarshallOptions: {
      wrapNumbers: false
    }
  });

  [...upToDateIndexingsSet].forEach((indexing) =>
    console.log(`ℹ️  ${indexing} arn is already up to date in DDB`)
  );

  // handle modified items
  for (const item of modifiedItems) {
    try {
      const putCmd = new PutCommand({
        TableName: tableName,
        Item: {
          Typing: "arn",
          Indexing: item.Indexing,
          arn: item.arn
        }
      });
      await ddbDocClient.send(putCmd);
      console.log(`✅ ${item.Name} updated in DDB`);
    } catch (err) {
      console.error(err);
    }
  }

  // handle deleted items
  for (const indexing of deletedIndexingsSet) {
    try {
      const deleteCmd = new DeleteCommand({
        TableName: tableName,
        Key: {
          Typing: "arn",
          Indexing: indexing
        }
      });
      await ddbDocClient.send(deleteCmd);
      console.log(`🔥 ${indexing} deleted from DDB`);
    } catch (err) {
      console.error(err);
    }
  }

  console.log(
    `${upToDateIndexingsSet.size} untouched, ${modifiedItems.length} modified, ${deletedIndexingsSet.size} deleted`
  );
}

async function syncContactFlowModuleArns(
  config,
  tableName,
  dynamoFlowModules,
  connectFlowModules
) {
  const { modifiedItems, upToDateIndexingsSet, deletedIndexingsSet } =
    getDeltas("flowmodule", dynamoFlowModules, connectFlowModules);
  const client = new DynamoDBClient(config);
  const ddbDocClient = DynamoDBDocumentClient.from(client, {
    marshallOptions: {
      convertEmptyValues: false,
      removeUndefinedValues: true,
      convertClassInstanceToMap: false
    },
    unmarshallOptions: {
      wrapNumbers: false
    }
  });

  [...upToDateIndexingsSet].forEach((indexing) =>
    console.log(`ℹ️  ${indexing} arn is already up to date in DDB`)
  );

  // handle modified items
  for (const item of modifiedItems) {
    try {
      const putCmd = new PutCommand({
        TableName: tableName,
        Item: {
          Typing: "arn",
          Indexing: item.Indexing,
          arn: item.arn
        }
      });
      await ddbDocClient.send(putCmd);
      console.log(`✅ ${item.Name} updated in DDB`);
    } catch (err) {
      console.error(err);
    }
  }

  // handle deleted items
  for (const indexing of deletedIndexingsSet) {
    try {
      const deleteCmd = new DeleteCommand({
        TableName: tableName,
        Key: {
          Typing: "arn",
          Indexing: indexing
        }
      });
      await ddbDocClient.send(deleteCmd);
      console.log(`🔥 ${indexing} deleted from DDB`);
    } catch (err) {
      console.error(err);
    }
  }

  console.log(
    `${upToDateIndexingsSet.size} untouched, ${modifiedItems.length} modified, ${deletedIndexingsSet.size} deleted`
  );
}

async function syncLambdaArns(config, tableName, dynamoLambdas, lambdas) {
  const { modifiedItems, upToDateIndexingsSet, deletedIndexingsSet } =
    getDeltas("lambda", dynamoLambdas, lambdas);
  const client = new DynamoDBClient(config);
  const ddbDocClient = DynamoDBDocumentClient.from(client, {
    marshallOptions: {
      convertEmptyValues: false,
      removeUndefinedValues: true,
      convertClassInstanceToMap: false
    },
    unmarshallOptions: {
      wrapNumbers: false
    }
  });

  [...upToDateIndexingsSet].forEach((indexing) =>
    console.log(`ℹ️  ${indexing} arn is already up to date in DDB`)
  );

  // handle modified items
  for (const item of modifiedItems) {
    try {
      const putCmd = new PutCommand({
        TableName: tableName,
        Item: {
          Typing: "arn",
          Indexing: item.Indexing,
          arn: item.arn
        }
      });
      await ddbDocClient.send(putCmd);
      console.log(`✅ ${item.Name} updated in DDB`);
    } catch (err) {
      console.error(err);
    }
  }
  // handle deleted items
  for (const indexing of deletedIndexingsSet) {
    try {
      const deleteCmd = new DeleteCommand({
        TableName: tableName,
        Key: {
          Typing: "arn",
          Indexing: indexing
        }
      });
      await ddbDocClient.send(deleteCmd);
      console.log(`🔥 ${indexing} deleted from DDB`);
    } catch (err) {
      console.error(err);
    }
  }

  console.log(
    `${upToDateIndexingsSet.size} untouched, ${modifiedItems.length} modified, ${deletedIndexingsSet.size} deleted`
  );
}

async function syncLexBotArns(config, tableName, dynamoLexBots, lexBots) {
  const { modifiedItems, upToDateIndexingsSet, deletedIndexingsSet } =
    getDeltas("lex", dynamoLexBots, lexBots);
  const client = new DynamoDBClient(config);
  const ddbDocClient = DynamoDBDocumentClient.from(client, {
    marshallOptions: {
      convertEmptyValues: false,
      removeUndefinedValues: true,
      convertClassInstanceToMap: false
    },
    unmarshallOptions: {
      wrapNumbers: false
    }
  });

  [...upToDateIndexingsSet].forEach((indexing) =>
    console.log(`ℹ️  ${indexing} arn is already up to date in DDB`)
  );

  // handle modified items
  for (const item of modifiedItems) {
    try {
      const putCmd = new PutCommand({
        TableName: tableName,
        Item: {
          Typing: "arn",
          Indexing: item.Indexing,
          arn: item.arn
        }
      });
      await ddbDocClient.send(putCmd);
      console.log(`✅ ${item.Name} updated in DDB`);
    } catch (err) {
      console.error(err);
    }
  }

  // handle deleted items
  for (const indexing of deletedIndexingsSet) {
    try {
      const deleteCmd = new DeleteCommand({
        TableName: tableName,
        Key: {
          Typing: "arn",
          Indexing: indexing
        }
      });
      await ddbDocClient.send(deleteCmd);
      console.log(`🔥 ${indexing} deleted from DDB`);
    } catch (err) {
      console.error(err);
    }
  }

  console.log(
    `${upToDateIndexingsSet.size} untouched, ${modifiedItems.length} modified, ${deletedIndexingsSet.size} deleted`
  );
}

exports.handler = async () => {
  const config = { region: process.env.REGION };
  const tableName = process.env.DDB_TABLE;
  const stageConfig = instanceMap;
  for (const region of Object.keys(stageConfig)) {
    console.log("region", region);
    const instanceId = stageConfig[region];

    //#region Queues
    console.log("\n\nSyncing Queues");
    const dynamoQueues = await getDynamoData(
      config,
      tableName,
      "queue#",
      region
    );
    const connectQueues = await getConnectQueues(config, region, instanceId);
    await syncQueueArns(config, tableName, dynamoQueues, connectQueues);
    //#endregion Queues

    //#region Contact Flows
    console.log("\n\nSyncing Contact Flows");
    const dynamoContactFlows = await getDynamoData(
      config,
      tableName,
      "flow#",
      region
    );
    const connectFlows = await getConnectFlows(config, region, instanceId);
    await syncContactFlowArns(
      config,
      tableName,
      dynamoContactFlows,
      connectFlows
    );
    //#endregion Contact Flows

    //#region Contact Flow Modules
    console.log("\n\nSyncing Contact Flow Modules");
    const dynamoContactFlowModules = await getDynamoData(
      config,
      tableName,
      "flowmodule#",
      region
    );
    const connectFlowModules = await getConnectFlowModules(
      config,
      region,
      instanceId
    );
    await syncContactFlowModuleArns(
      config,
      tableName,
      dynamoContactFlowModules,
      connectFlowModules
    );
    //#endregion Contact Flow Modules

    //#region Lambda
    console.log("\n\nSyncing Lambda Arns");
    const dynamoLambdaArns = await getDynamoData(
      config,
      tableName,
      "lambda#",
      region
    );
    const lambdas = await getLambdas(region);
    await syncLambdaArns(config, tableName, dynamoLambdaArns, lambdas);
    //#endregion Lambda

    //#region lex
    console.log("\n\nSyncing lex Arns");
    const dynamoLexArns = await getDynamoData(
      config,
      tableName,
      "lex#",
      region
    );
    const lexBots = await getLexBots(region);
    await syncLexBotArns(config, tableName, dynamoLexArns, lexBots);
    //#endregion lex
  }

  return { status: "200" };
};
