require("dotenv").config();

const { handler } = require("./index");
const event = {};

(async () => {
  const res = await handler(event, null);
  console.log(res);
})();
