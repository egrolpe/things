const { DynamoDBDocument } = require("@aws-sdk/lib-dynamodb");
const { DynamoDB } = require("@aws-sdk/client-dynamodb");
const dynamodb = DynamoDBDocument.from(new DynamoDB());

function removeBlankKeysAndValues(obj) {
  Object.keys(obj).forEach((key) => {
    if (obj[key] && typeof obj[key] === "object" && !Array.isArray(obj[key])) {
      removeBlankKeysAndValues(obj[key]);
    } else if (obj[key] === "" || obj[key] === null || obj[key] === undefined) {
      delete obj[key];
    }
  });
}

function convertValuesToString(obj, prosody, event) {
  for (let key in obj) {
    if (
      key.includes("prompt") &&
      !key.includes("_indexing") &&
      obj[key] &&
      event.Details.ContactData.Channel !== "CHAT"
    ) {
      obj[
        key
      ] = `<speak><prosody rate='${prosody}%'> ${obj[key]} </prosody></speak>`;
    }
    obj[key] = String(obj[key]);
  }
  return obj;
}

async function getDialogState(event) {
  const typing = "dialogState";
  let indexing = event.Details.Parameters.configRef;

  let langCode = event.Details.ContactData.LanguageCode;
  const prosody = "100";
  const query = "equals";

  console.log(
    "Config Retrieval Inputs: [ typing: " +
      typing +
      " indexing: " +
      indexing +
      " query: " +
      query +
      " ]"
  );

  const params = {
    TableName: process.env.DDB_TABLE,
    KeyConditionExpression: "#typing = :typing AND #indexing = :indexing",
    ExpressionAttributeNames: {
      "#typing": "Typing",
      "#indexing": "Indexing",
    },
    ExpressionAttributeValues: {
      ":typing": typing,
      ":indexing": indexing,
    },
  };

  try {
    let data = await dynamodb.query(params);
    console.log("db response", data);
    data.Items.forEach((item) => removeBlankKeysAndValues(item));
    const obj = convertValuesToString(data.Items[0], prosody, event);

    const paramsArray = [];

    for (let key in obj) {
      obj[key] = String(obj[key]);
      if (key.includes("_indexing") && obj[key]) {
        const params = {
          TableName: process.env.DDB_TABLE,
          KeyConditionExpression: "#typing = :typing AND #indexing = :indexing",
          ExpressionAttributeNames: {
            "#typing": "Typing",
            "#indexing": "Indexing",
          },
          ExpressionAttributeValues: {
            ":typing": "prompt",
            ":indexing":
              typing === "dialogState"
                ? langCode.toLowerCase() + "#" + obj[key]
                : obj[key],
          },
        };
        paramsArray.push({ key, params });
      } else if (key === "bot_name" && obj[key]) {
        let botName = obj[key].replace("{lex-prefix}", process.env.LEX_PREFIX);
        const params = {
          TableName: process.env.DDB_TABLE,
          KeyConditionExpression: "#typing = :typing AND #indexing = :indexing",
          ExpressionAttributeNames: {
            "#typing": "Typing",
            "#indexing": "Indexing",
          },
          ExpressionAttributeValues: {
            ":typing": "arn",
            ":indexing": `lex#${botName}`,
          },
        };
        paramsArray.push({ key, params });
      }
    }

    // Use Promise.all to fetch values from DynamoDB in parallel
    const getPromises = paramsArray.map(async ({ key, params }) => {
      try {
        const result = await dynamodb.query(params);

        if (key.includes("_indexing")) {
          const value = result.Items[0].prompt_value;
          // Apply SSML and Prosody formatting
          let replacedKey = key.replaceAll(/_indexing/g, "");

          let replacedValue = value.replace(/\$.Attributes.(\w+)/g, (match, variable) => {
            // Check if the variable is defined in the Contact Attributes object
            if (Object.hasOwn(event.Details.ContactData.Attributes, variable)) {
              // Get the value of the variable from the Contact Attributes object
              return event.Details.ContactData.Attributes[variable];
            } else {
              // If the variable is not defined, return the original placeholder
              return match;
            }
          });

          if (event.Details.ContactData.Channel === "CHAT"){
            obj[replacedKey] = replacedValue;
          } else {
            obj[
              replacedKey
            ] = `<speak><prosody rate="${prosody}%">${replacedValue}</prosody></speak>`;
          }
        } else if (key === "bot_name") {
          console.log(result);
          obj["botArn"] = result.Items[0].arn;
        }
      } catch (error) {
        console.error(`Error fetching ${key} from DynamoDB:`, error);
      }
    });

    await Promise.all(getPromises);

    console.log(`obj: ${JSON.stringify(obj)}`);

    return obj;
  } catch (error) {
    console.error("Error calling DynamoDB:", error);
    throw error;
  }
}

module.exports = {
  getDialogState,
};
