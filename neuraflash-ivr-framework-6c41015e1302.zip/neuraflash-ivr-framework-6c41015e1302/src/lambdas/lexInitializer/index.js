const {
  LexRuntimeV2Client,
  RecognizeTextCommand,
} = require("@aws-sdk/client-lex-runtime-v2");

// Initialize the Lex V2 client
const lexClient = new LexRuntimeV2Client();
const { getDialogState } = require("./dynamoDbHelper");

async function invokeLexBot(event, dialogState) {
  try {
    const sessionId =
      event.Details?.ContactData?.ContactId || "default_session_id";

    // Split the Bot ARN by '/' and get the botId and aliasId
    const parts = dialogState.botArn.split("/");
    const botId = parts[1];
    const botAliasId = parts[2];

    const localeId = "en_US";
    const inputText = "xyz";

    let activeContexts = [];

    let supportedContexts =
      dialogState.supported_contexts
        ?.split(";")
        ?.map((s) => s.trim()) || [];
    if (supportedContexts.length > 0) {
      for (let supportedContext of supportedContexts) {
        let context = {
          name: supportedContext,
          contextAttributes: {},
          timeToLive: {
            timeToLiveInSeconds: 90,
            turnsToLive: 4,
          },
        };
        activeContexts.push(context);
      }
    }

    const command = new RecognizeTextCommand({
      botId,
      botAliasId,
      localeId,
      sessionId,
      text: inputText,
      sessionState: {
        sessionAttributes: {
          configRef: "standard_menu",
          initialize: "true",
        },
        activeContexts,
      },
    });

    const lexResponse = await lexClient.send(command);
    console.log("Lex response:", JSON.stringify(lexResponse, null, 2));
  } catch (error) {
    console.error("Error communicating with Lex:", error);
    throw error;
  }
}

exports.handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));
  try {
    const dialogState = await getDialogState(event);

    if(event.Details.ContactData.Channel === "CHAT"){
      dialogState["isChat"] = "true"
    }
    if (
      event.Details.ContactData.Channel === "VOICE" &&
      event.Details.ContactData.LanguageCode === "en-US" &&
      dialogState.supported_contexts
    ) {
      await invokeLexBot(event, dialogState);
    }

    let response = {
      statusCode: 200,
      lex_initial_prompt: dialogState.initial_prompt,
      lex_arn: dialogState.botArn,
      lex_session_attributes: JSON.stringify(dialogState),
      lex_allow_interrupt: dialogState["x-amz-lex:allow-interrupt:*:*"],
      lex_audio_end_timeout_ms:
        dialogState["x-amz-lex:audio:end-timeout-ms:*:*"],
      lex_audio_max_length_ms: dialogState["x-amz-lex:audio:max-length-ms:*:*"],
      lex_audio_start_timeout_ms:
        dialogState["x-amz-lex:audio:start-timeout-ms:*:*"],
      lex_dtmf_end_timeout_ms: dialogState["x-amz-lex:dtmf:end-timeout-ms:*:*"],
      lex_text_start_timeout_ms:
        dialogState["x-amz-lex:text:start-timeout-ms:*:*"],
    };

    console.log(response);
    return response;
  } catch (error) {
    console.error("Error:", error);
    throw error;
  }
};
