const { updateStandardQueue } = require("./methods/updateStandardQueue");
const { updateVCR } = require("./methods/updateVCR");
const { executeOmniFlow } = require("./methods/executeOmniFlow");

exports.handler = async (event) => {
  try {
    console.log("Event: " + JSON.stringify(event));
    const parameters = event.Details.Parameters;
    // Get method name from parameters
    const methods = parameters.methods?.split(";")?.map((s) => s.trim()) || [];
    for (const methodName of methods) {
      switch (methodName) {
        case "updateStandardQueue":
          await updateStandardQueue(event);
          break;
        case "updateVCR":
          await updateVCR(event);
          break;
        case "executeOmniFlow":
          await executeOmniFlow(event);
          break;
      }
    }
    return {
      result: "success",
    };
  } catch (err) {
    return {
      result: "failure",
    };
  }
};
