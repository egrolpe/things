const { invokeLambdaFunction } = require("../invokeLambda");

const updateVCR = async (event) => {
  try {
    const parameters = {
      methodName: "updateRecord",
      objectApiName: "VoiceCall",
      recordId: event.Details.ContactData.Attributes.voiceCallId,
      ANI__c: event.Details.ContactData.Attributes.dialerANI,
      UserId__c: event.Details.ContactData.Attributes.UID,
      Why_Transferred__c: event.Details.ContactData.Attributes.whyTransferred,
      Call_Reason__c: event.Details.ContactData.Attributes.callReason,
      IVR_Trail__c: event.Details.ContactData.Attributes.IVR_Trail
    };
    const lambdaName = process.env.INVOKE_SALESFORCE_REST_API_FUNCTION;
    const res = await invokeLambdaFunction(
      lambdaName,
      event.Details.ContactData,
      parameters
    );
  } catch (e) {
    console.log(error);
    throw new Error(`Error: ${e}`);
  }
};

module.exports = { updateVCR };
