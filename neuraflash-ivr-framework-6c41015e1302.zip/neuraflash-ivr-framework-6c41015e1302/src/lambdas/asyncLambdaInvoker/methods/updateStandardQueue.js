const { invokeLambdaFunction } = require("../invokeLambda");

const updateStandardQueue = async (event) => {
  try {
    const parameters = {
      methodName: "updateVoiceCall",
      fieldValues: {
        queue: event.Details.ContactData.Attributes.queue,
        isActiveCall: true
      },
      contactId: event.Details.ContactData.ContactId
    };
    const lambdaName = process.env.INVOKE_TELEPHONY_INTEGRATION_API_FUNCTION;

    const res = await invokeLambdaFunction(
      lambdaName,
      event.Details.ContactData,
      parameters
    );
  } catch (e) {
    throw new Error(`Error: ${e}`);
  }
};

module.exports = { updateStandardQueue };
