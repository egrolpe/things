const { invokeLambdaFunction } = require("../invokeLambda");

const executeOmniFlow = async (event) => {
  try {
    const parameters = {
      methodName: "executeOmniFlow",
      flowDevName: "NeuraFlash_Voice_Calls_Routed_to_Queues",
      Id: event.Details.ContactData.Attributes.voiceCallId,
      "flowInput-customqueuename": event.Details.ContactData.Attributes.queue
    };
    const lambdaName = process.env.INVOKE_TELEPHONY_INTEGRATION_API_FUNCTION;

    const res = await invokeLambdaFunction(
      lambdaName,
      event.Details.ContactData,
      parameters
    );
  } catch (e) {
    throw new Error(`Error: ${e}`);
  }
};

module.exports = { executeOmniFlow };
