const { handler } = require("./index.js");

let event = {
  Details: {
    ContactData: {
      Attributes: {
        inEmergency: "false",
        queue: "Tier2",
      },
      AwsRegion: "eu-central-1",
      Channel: "VOICE",
      ContactId: "315fa704-1e26-4f0e-ba5b-e1875a154136",
      CustomerEndpoint: {
        Address: "+15082031791",
        Type: "TELEPHONE_NUMBER",
      },
      CustomerId: null,
      Description: null,
      InitialContactId: "315fa704-1e26-4f0e-ba5b-e1875a154136",
      InitiationMethod: "INBOUND",
      InstanceARN:
        "arn:aws:connect:eu-central-1:381492027044:instance/d2904d6c-c955-4711-9a1c-420f3d9f7714",
      LanguageCode: "en-US",
      MediaStreams: {
        Customer: {
          Audio: null,
        },
      },
      Name: null,
      PreviousContactId: "315fa704-1e26-4f0e-ba5b-e1875a154136",
      Queue: {
        ARN: "arn:aws:connect:eu-central-1:381492027044:instance/d2904d6c-c955-4711-9a1c-420f3d9f7714/queue/40596596-efcf-4ef0-8a19-50824a4a3cb9",
        Name: "Tier1",
        OutboundCallerId: {
          Address: "+18665130740",
          Type: "TELEPHONE_NUMBER",
        },
      },
      References: {},
      RelatedContactId: null,
      SegmentAttributes: {
        "connect:Subtype": {
          ValueInteger: null,
          ValueMap: null,
          ValueString: "connect:Telephony",
        },
      },
      SystemEndpoint: {
        Address: "+18665130740",
        Type: "TELEPHONE_NUMBER",
      },
      Tags: {
        "aws:connect:instanceId": "d2904d6c-c955-4711-9a1c-420f3d9f7714",
        "aws:connect:systemEndpoint": "+18665130740",
      },
    },
    Parameters: {
      methods: "updateVCR",
    },
  },
  Name: "ContactFlowEvent",
};

handler(event);
