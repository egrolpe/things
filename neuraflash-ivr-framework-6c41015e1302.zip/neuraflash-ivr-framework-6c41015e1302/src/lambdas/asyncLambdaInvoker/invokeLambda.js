const { LambdaClient, InvokeCommand } = require("@aws-sdk/client-lambda");

async function invokeLambdaFunction(lambdaName, contactData, parameters) {
  try {
    const payload = {
      Details: {
        ContactData: contactData,
        Parameters: parameters
      }
    };

    const params = {
      FunctionName: lambdaName,
      Payload: JSON.stringify(payload),
      InvocationType: "Event"
    };

    const lambdaClient = new LambdaClient();

    console.log("Lambda request params", params);

    // Invoke the Lambda function asynchronously
    const command = new InvokeCommand(params);
    const data = await lambdaClient.send(command);
    console.log("Lambda response", data);
    return data;
  } catch (err) {
    console.log(err);
    throw err;
  }
}

module.exports = { invokeLambdaFunction };
