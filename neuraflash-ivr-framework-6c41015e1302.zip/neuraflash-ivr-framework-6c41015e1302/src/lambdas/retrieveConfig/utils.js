// Utility function(s) for retrieveConfig Lambda function.

function removePrefix(inputString, prefix) {
  if (prefix && inputString.startsWith(prefix)) {
    return inputString.substring(prefix.length);
  }
  return inputString;
}

// Proces DNIS config data.
const processConfig = (typing, indexing, data, response, query, prosody, event) => {
  function convertValuesToString(obj) {
    for (let key in obj) {
      if (
        key.includes("prompt") &&
        !key.includes("_indexing") &&
        obj[key] &&
        key !== "ConfirmReprompt" &&
        event.Details.ContactData.Channel !== "CHAT"
      ) {
        obj[
          key
        ] = `<speak><prosody rate='${prosody}%'> ${obj[key]} </prosody></speak>`;
      }
      obj[key] = String(obj[key]);
    }
    return obj;
  }
  if (query !== "equals") {
    response = convertValuesToString(response);
    data.Items.forEach((element) => {
      const tokens = element.Indexing.split("#");
      let keyName = tokens[tokens.length - 1];
      if (typing === "arn") {
        if (indexing === "lambda") {
          keyName = removePrefix(keyName, process.env.LAMBDA_PREFIX);
          keyName = removePrefix(keyName, process.env.SALESFORCE_PREFIX);
          keyName = keyName + "-lambda-arn";
        }
        if (indexing === "lex") {
          keyName = removePrefix(keyName, process.env.LEX_PREFIX);
          keyName = keyName + "-lex-arn";
        }
        if (indexing === "flowmodule") {
          keyName = keyName + "_module_arn";
        }
        response[keyName] = element.arn;
      } else if (typing === "prompt") {
        keyName = keyName + "-prompt";
        if(event.Details.ContactData.Channel === "CHAT"){
          response[keyName] = element.prompt_value;
        } else {
        response[keyName] =
          `<speak><prosody rate='${prosody}%'> ${element.prompt_value} </prosody></speak>`;
        }
      } else {
        response[keyName] = convertValuesToString(element);
      }
    });
    return response;
  } else {
    response = {
      ...response,
      ...data.Items[0]
    };
    return convertValuesToString(response);
  }
};

// safely retrieve nested properties of an object without encountering errors due to undefined properties in the object. By returning the errorValue instead of throwing an error, this function provides a way to handle missing properties in a more graceful way.
function safeGet(obj, path, errorValue = undefined) {
  return path.reduce(
    (xs, x) => (xs && xs[x] !== undefined ? xs[x] : errorValue),
    obj
  );
}

function removeBlankKeysAndValues(obj) {
  Object.keys(obj).forEach((key) => {
    if (obj[key] && typeof obj[key] === "object" && !Array.isArray(obj[key])) {
      removeBlankKeysAndValues(obj[key]);
    } else if (obj[key] === "" || obj[key] === null || obj[key] === undefined) {
      delete obj[key];
    }
  });
}

function convertValuesToString(originalObj) {
  const newObj = {};

  for (const key in originalObj) {
    if (typeof originalObj[key] === "object" && originalObj[key] !== null) {
      // If the value is an object or array, stringify it
      newObj[key] = JSON.stringify(originalObj[key]);
    } else {
      // Convert the value to a string
      newObj[key] = String(originalObj[key]);
    }
  }

  return newObj;
}

module.exports = {
  safeGet,
  processConfig,
  removeBlankKeysAndValues,
  convertValuesToString
};
