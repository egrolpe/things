const index = require("./index");

const event = {
  Details: {
    ContactData: {
      Attributes: {},
      AwsRegion: "eu-central-1",
      Channel: "VOICE",
      ContactId: "7176563c-7f9e-4a54-9dfa-59eccac1a5dd",
      CustomerEndpoint: {
        Address: "+15082031791",
        Type: "TELEPHONE_NUMBER"
      },
      CustomerId: null,
      Description: null,
      InitialContactId: "7176563c-7f9e-4a54-9dfa-59eccac1a5dd",
      InitiationMethod: "INBOUND",
      InstanceARN:
        "arn:aws:connect:eu-central-1:058264386761:instance/5baa7a82-3cd3-4075-8d10-9f587009b936",
      LanguageCode: "en-US",
      MediaStreams: {
        Customer: {
          Audio: null
        }
      },
      Name: null,
      PreviousContactId: "7176563c-7f9e-4a54-9dfa-59eccac1a5dd",
      Queue: null,
      References: {},
      RelatedContactId: null,
      SegmentAttributes: {
        "connect:Subtype": {
          ValueString: "connect:Telephony"
        }
      },
      SystemEndpoint: {
        Address: "+18666035923",
        Type: "TELEPHONE_NUMBER"
      },
      Tags: {
        "aws:connect:instanceId": "5baa7a82-3cd3-4075-8d10-9f587009b936",
        "aws:connect:systemEndpoint": "+18666035923"
      }
    },
    Parameters: {
      typing: "arn",
      indexing: "lambda",
      query: "begins"
    }
  },
  Name: "ContactFlowEvent"
};

index.handler(event);
