const dynamoDBResponseForLambdaARNsBeginsQuery = {
  Items: [
    {
      Typing: "arn",
      Indexing: "arn#lambda#dev-us-west-2-config-retrieval",
      arn: "arn:aws:lambda:us-west-2:008129450445:function:dev-us-west-2-config-retrieval:active"
    },
    {
      Typing: "arn",
      Indexing: "arn#lambda#dev-us-west-2-connect-sync",
      arn: "arn:aws:lambda:us-west-2:008129450445:function:dev-us-west-2-connect-sync:active"
    }
  ],
  Count: 2,
  ScannedCount: 2
};

const dynamoDBResponseForLambdaARNsEqualsQuery = {
  Items: [
    {
      Typing: "arn",
      Indexing: "arn#lambda#dev-us-west-2-config-retrieval",
      arn: "arn:aws:lambda:us-west-2:008129450445:function:dev-us-west-2-config-retrieval:active"
    }
  ]
};

const dynamoDBResponseForPromptsEqualsQuery = {
  Items: [
    {
      Typing: "prompt",
      name: "max_nm_or_ni",
      language: "en-US",
      Indexing: "en-us#max_nm_or_ni",
      prompt_value: "Sorry I'm not understanding you."
    }
  ],
  Count: 1,
  ScannedCount: 1
};

const dynamoDBResponseForPromptsBeginsQuery = {
  Items: [
    {
      Typing: "prompt",
      name: "max_nm_or_ni",
      language: "en-US",
      Indexing: "en-us#max_nm_or_ni",
      prompt_value: "Sorry I'm not understanding you."
    },
    {
      Typing: "prompt",
      name: "max_nm_or_ni_v2",
      language: "en-US",
      Indexing: "en-us#max_nm_or_ni_v2",
      prompt_value: "Sorry I'm not understanding you. V2"
    }
  ]
};

const dynamoDBResponseForDialogStateEqualsQuery = {
  Items: [
    {
      dtmf_option_2: "dd-no",
      dtmf_option_1: "dd-yes",
      Typing: "dialogState",
      dtmf_option_0: "dd-customerservice",
      lex_interrupt: true,
      initial_prompt_indexing: "conf_persona_ini",
      dialog_name: "conf_persona",
      lex_voice_timeout: "4000",
      Indexing: "conf_persona",
      lex_max_utterance_length: "13000",
      retry_prompt_1_indexing: "conf_persona_rep1",
      supported_intents:
        "dd-yes; dd-no; dd-dasher; dd-customer; dd-merchant; dd-customerservice"
    }
  ],
  Count: 1,
  ScannedCount: 1
};

const dynamoDBResponseForDialogStateEqualsQuery1 = {
  Items: [
    {
      Typing: "prompt",
      name: "conf_persona_ini",
      language: "en-US",
      Indexing: "en-us#conf_persona_ini",
      prompt_value: "Are you calling as a $.Attributes.['profileType'] today?"
    }
  ]
};

const dynamoDBResponseForDialogStateEqualsQuery2 = {
  Items: [
    {
      Typing: "prompt",
      name: "conf_persona_rep1",
      language: "en-US",
      Indexing: "en-us#conf_persona_rep1",
      prompt_value:
        "I found your phone number on a $.Attributes.['profileType'] profile. Is that what you're calling about today?"
    }
  ]
};

module.exports = {
  dynamoDBResponseForLambdaARNsBeginsQuery,
  dynamoDBResponseForLambdaARNsEqualsQuery,
  dynamoDBResponseForPromptsBeginsQuery,
  dynamoDBResponseForPromptsEqualsQuery,
  dynamoDBResponseForDialogStateEqualsQuery,
  dynamoDBResponseForDialogStateEqualsQuery1,
  dynamoDBResponseForDialogStateEqualsQuery2
};
