jest.mock("@aws-sdk/client-dynamodb", () => {
  return {
    DynamoDB: jest.fn(),
    DynamoDBClient: jest.fn(() => ({
      send: jest.fn()
    })),
    QueryCommand: jest.fn()
  };
});

jest.mock("@aws-sdk/lib-dynamodb", () => {
  const queryMock = jest.fn();
  return {
    DynamoDBDocument: {
      from: jest.fn(() => ({
        query: queryMock
      })),
      __queryMock: queryMock
    }
  };
});

const testData = require("./testData");
const { handler } = require("../index");

describe("Lambda Handler", () => {
  it("should handle config retrieval for ARN - Begins Query", async () => {
    const { DynamoDBDocument } = require("@aws-sdk/lib-dynamodb");
    DynamoDBDocument.__queryMock.mockResolvedValueOnce(testData.dynamoDBResponseForLambdaARNsBeginsQuery);

    const event = {
      Details: {
        Parameters: {
          typing: "arn",
          indexing: "arn#lambda",
          query: "begins"
        },
        ContactData: {
          LanguageCode: "en-US",
          prosody: "100"
        }
      }
    };

    const result = await handler(event);
    expect(result).toBeDefined();
    expect(result.statusCode).toEqual(200);
    expect(result["dev-us-west-2-config-retrieval"]).toBeDefined();
    expect(result["dev-us-west-2-connect-sync"]).toBeDefined();
  });

  it("should handle config retrieval for ARN - Equals Query", async () => {
    const { DynamoDBDocument } = require("@aws-sdk/lib-dynamodb");
    DynamoDBDocument.__queryMock.mockResolvedValueOnce(testData.dynamoDBResponseForLambdaARNsEqualsQuery);
    
    const event = {
      Details: {
        Parameters: {
          typing: "arn",
          indexing: "arn#lambda#dev-us-west-2-config-retrieval",
          query: "equals"
        },
        ContactData: {
          LanguageCode: "en-US",
          prosody: "100"
        }
      }
    };
    const result = await handler(event);
    expect(result).toBeDefined();
    expect(result.statusCode).toEqual(200);
    expect(result.Indexing).toEqual("arn#lambda#dev-us-west-2-config-retrieval");
    expect(result.arn).toEqual("arn:aws:lambda:us-west-2:008129450445:function:dev-us-west-2-config-retrieval:active");
  });

  it("should handle config retrieval for Prompts - Begins Query", async () => {
    const { DynamoDBDocument } = require("@aws-sdk/lib-dynamodb");
    DynamoDBDocument.__queryMock.mockResolvedValueOnce(testData.dynamoDBResponseForPromptsBeginsQuery);
    
    const event = {
      Details: {
        Parameters: {
          typing: "prompt",
          indexing: "max_nm_or_ni",
          query: "begins"
        },
        ContactData: {
          LanguageCode: "en-US",
          prosody: "100"
        }
      }
    };
    const result = await handler(event);
    
    expect(result).toBeDefined();
    expect(result.statusCode).toEqual(200);
    expect(result["max_nm_or_ni-prompt"]).toBeDefined();
    expect(result["max_nm_or_ni-prompt"]).toEqual("<speak><prosody rate='100%'> Sorry I'm not understanding you. </prosody></speak>");
    expect(result["max_nm_or_ni_v2-prompt"]).toBeDefined();
    expect(result["max_nm_or_ni_v2-prompt"]).toEqual("<speak><prosody rate='100%'> Sorry I'm not understanding you. V2 </prosody></speak>");    
  });

  it("should handle config retrieval for Prompts - Equals Query", async () => {
    const { DynamoDBDocument } = require("@aws-sdk/lib-dynamodb");
    DynamoDBDocument.__queryMock.mockResolvedValueOnce(testData.dynamoDBResponseForPromptsEqualsQuery);
    
    const event = {
      Details: {
        Parameters: {
          typing: "prompt",
          indexing: "max_nm_or_ni",
          query: "equals"
        },
        ContactData: {
          LanguageCode: "en-US",
          prosody: "100"
        }
      }
    };
    const result = await handler(event);
    expect(result).toBeDefined();
    expect(result.statusCode).toEqual(200);
    expect(result.Indexing).toEqual("en-us#max_nm_or_ni");
    expect(result.prompt_value).toEqual("<speak><prosody rate='100%'> Sorry I'm not understanding you. </prosody></speak>");
  });

  it("should handle config retrieval for Prompts - Equals Query - Prosody 80", async () => {
    const { DynamoDBDocument } = require("@aws-sdk/lib-dynamodb");
    DynamoDBDocument.__queryMock.mockResolvedValueOnce(testData.dynamoDBResponseForPromptsEqualsQuery);
    const event = {
      Details: {
        Parameters: {
          typing: "prompt",
          indexing: "max_nm_or_ni",
          query: "equals"
        },
        ContactData: {
          LanguageCode: "en-US",
          prosody: "80"
        }
      }
    };
    const result = await handler(event);
    expect(result).toBeDefined();
    expect(result.statusCode).toEqual(200);
    expect(result.Indexing).toEqual("en-us#max_nm_or_ni");
    expect(result.prompt_value).toEqual("<speak><prosody rate='80%'> Sorry I'm not understanding you. </prosody></speak>");
  });

  it("should handle config retrieval for Prompts - Equals Query -Without Prosody & LanguageCode in event", async () => {
    const { DynamoDBDocument } = require("@aws-sdk/lib-dynamodb");
    DynamoDBDocument.__queryMock.mockResolvedValueOnce(testData.dynamoDBResponseForPromptsEqualsQuery);
    
    const event = {
      Details: {
        ContactData: {
          Channel: "VOICE"
        },
        Parameters: {
          typing: "prompt",
          indexing: "max_nm_or_ni",
          query: "equals"
        }
      }
    };
    const result = await handler(event);
    expect(result).toBeDefined();
    expect(result.statusCode).toEqual(200);
    expect(result.Indexing).toEqual("en-us#max_nm_or_ni");
    expect(result.prompt_value).toEqual("<speak><prosody rate='100%'> Sorry I'm not understanding you. </prosody></speak>");
  });

  it("should handle config retrieval for Dialog State - Equals Query", async () => {
    const { DynamoDBDocument } = require("@aws-sdk/lib-dynamodb");
    DynamoDBDocument.__queryMock.mockResolvedValueOnce(testData.dynamoDBResponseForDialogStateEqualsQuery);
    DynamoDBDocument.__queryMock.mockResolvedValueOnce(testData.dynamoDBResponseForDialogStateEqualsQuery1);
    DynamoDBDocument.__queryMock.mockResolvedValueOnce(testData.dynamoDBResponseForDialogStateEqualsQuery2);
    
    const event = {
      Details: {
        Parameters: {
          typing: "dialogState",
          indexing: "conf_persona",
          query: "equals"
        },
        ContactData: {
          LanguageCode: "en-US",
          prosody: "100"
        }
      }
    };
    const result = await handler(event);
    
    expect(result).toBeDefined();
    expect(result.statusCode).toEqual(200);
    expect(result.Indexing).toEqual("conf_persona");
    expect(result.initial_prompt).toEqual("<speak><prosody rate=\"100%\">Are you calling as a $.Attributes.['profileType'] today?</prosody></speak>");
    expect(result.retry_prompt_1).toEqual("<speak><prosody rate=\"100%\">I found your phone number on a $.Attributes.['profileType'] profile. Is that what you're calling about today?</prosody></speak>");
  });
});