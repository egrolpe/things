const { DynamoDBDocument } = require("@aws-sdk/lib-dynamodb");
const { DynamoDB } = require("@aws-sdk/client-dynamodb");
const dynamodb = DynamoDBDocument.from(new DynamoDB());
const {
  ConnectClient,
  UpdateContactAttributesCommand
} = require("@aws-sdk/client-connect"); // ES Modules import
const {
  processConfig,
  removeBlankKeysAndValues,
  convertValuesToString
} = require("./utils");

exports.handler = async (event) => {
  console.log("Config Retrieval Event: " + JSON.stringify(event));
  const typing = event.Details.Parameters.typing; // ex. prompt or config or dnis
  let indexing = event.Details.Parameters.indexing; // ex. prompt or config or dnis
  console.log(`indexing: ${indexing.toLowerCase()}`);
  if (typing === "arn") {
    indexing = indexing.toLowerCase().replaceAll(/ /g, "_");
  } else {
    indexing.toLowerCase().replaceAll(/ /g, "");
  }

  let langCode = event.Details?.ContactData?.LanguageCode || "en-US";

  if (typing === "prompt" || typing === "global" || typing === "confirmation") {
    indexing = langCode.toLowerCase() + "#" + indexing;
  }

  const prosody = event.Details?.ContactData?.prosody || "100";
  const query = event.Details.Parameters?.query?.toLowerCase() || "equals"; // begins or equals
  const response = {};

  console.log(
    "Config Retrieval Inputs: [ typing: " +
      typing +
      " indexing: " +
      indexing +
      " query: " +
      query +
      " ]"
  );

  const params = {
    TableName: process.env.DDB_TABLE,
    KeyConditionExpression: "#typing = :typing",
    ExpressionAttributeNames: {
      "#typing": "Typing",
      "#indexing": "Indexing"
    },
    ExpressionAttributeValues: {
      ":typing": typing,
      ":indexing": indexing
    }
  };

  if (query === "equals") {
    params.KeyConditionExpression += " AND #indexing = :indexing";
  } else {
    params.KeyConditionExpression += " AND begins_with(#indexing, :indexing)";
  }

  try {
    let data = await dynamodb.query(params);
    console.log("db response", data);
    data.Items.forEach((item) => removeBlankKeysAndValues(item));
    const obj = processConfig(typing, indexing, data, response, query, prosody, event);

    const paramsArray = [];
    if (
      typing === "dnis" ||
      typing === "dialogState" ||
      typing === "intentAttributes"
    ) {
      for (let key in obj) {
        obj[key] = String(obj[key]);
        if (key.includes("_indexing") && obj[key]) {
          const params = {
            TableName: process.env.DDB_TABLE,
            KeyConditionExpression:
              "#typing = :typing AND #indexing = :indexing",
            ExpressionAttributeNames: {
              "#typing": "Typing",
              "#indexing": "Indexing"
            },
            ExpressionAttributeValues: {
              ":typing": "prompt",
              ":indexing": langCode.toLowerCase() + "#" + obj[key]
            }
          };
          console.log("params", params);
          paramsArray.push({ key, params });
        }
      }

      // Use Promise.all to fetch values from DynamoDB in parallel
      const getPromises = paramsArray.map(async ({ key, params }) => {
        try {
          const result = await dynamodb.query(params);
          const value = result.Items[0].prompt_value;
          // Apply SSML and Prosody formatting
          let replacedKey = key.replaceAll(/_indexing/g, "");
          if(event.Details.ContactData.Channel === "CHAT"){
            obj[replacedKey] = value;
          } else {
          obj[replacedKey] =
            `<speak><prosody rate="${prosody}%">${value}</prosody></speak>`;
          }
        } catch (error) {
          console.error(`Error fetching ${key} from DynamoDB:`, error);
        }
      });

      await Promise.all(getPromises);
    } else if (typing === "arn") {
      for (let key in obj) {
        obj[key];
      }
    }

    obj.statusCode = 200;

    console.log(`obj: ${JSON.stringify(obj)}`);

    if (event.Details.Parameters.updateVariable === "true") {
      const connectClient = new ConnectClient();
      const attributes = convertValuesToString(obj);
      const input = {
        InitialContactId: event.Details.ContactData.ContactId,
        InstanceId: event.Details.ContactData.InstanceARN.split("/").pop(),
        Attributes: attributes
      };
      const command = new UpdateContactAttributesCommand(input);
      const response = await connectClient.send(command);
      console.log("updated attributes", response);
    }
    return obj;
  } catch (error) {
    console.error("Error:", error);
    throw error;
  }
};
