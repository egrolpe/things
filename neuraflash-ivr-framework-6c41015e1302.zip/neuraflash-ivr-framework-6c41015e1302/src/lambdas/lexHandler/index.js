// Importing necessary functions from the "helpers.js" module
const {
  safeGet,
  close,
  elicitIntentWithRetries,
  // updateIvrTrail
} = require("./helpers.js");

const { v4: uuidv4 } = require("uuid");

const {
  LexRuntimeV2Client,
  RecognizeTextCommand,
} = require("@aws-sdk/client-lex-runtime-v2");

// Initialize the Lex V2 client
const lexClient = new LexRuntimeV2Client();

// const { getDialogState } = require("./dynamoDbHelper");

// Constants
const MIN_NLU_CONFIDENCE = process.env.MIN_NLU_CONFIDENCE;
const FALLBACK_INTENT = "FallbackIntent";
const NUMBER_SLOT = "number_slot";
const NUMERIC_INTENT = "number";

function hasValidSlot(event, interpretation, requiredSlots, optionalSlots) {
  let slots = interpretation.intent.slots;

  if (
    hasNoRequiredOrOptionalSlots(
      event.sessionState.intent,
      requiredSlots,
      optionalSlots
    )
  ) {
    return true;
  } else {
    let slotNameArray = Object.keys(slots);
    for (let slotName of slotNameArray) {
      if (safeGet(slots, [slotName, "value", "interpretedValue"])) {
        // event.sessionState.sessionAttributes.lexIntent =
        //   interpretation.intent.name;
        return true;
      }
    }
    return false;
  }
}

/**
Checks if an intent does not contain any required or optional slots.
Returns true if the intent has no required or optional slots, and false otherwise.
**/
function hasNoRequiredOrOptionalSlots(intent, requiredSlots, optionalSlots) {
  let slots = intent.slots;
  let slotNameArray = Object.keys(slots);

  let requiredSlotNames = requiredSlots.map(
    (requiredSlot) => requiredSlot.split(":")[0]
  );

  let optionalSlotsNames = optionalSlots.map(
    (optionalSlot) => optionalSlot.split(":")[0]
  );

  for (let slotName of slotNameArray) {
    if (
      requiredSlotNames.includes(slotName) ||
      optionalSlotsNames.includes(slotName)
    ) {
      return false;
    }
  }
  return true;
}

// Function to generate Slot Value Based On Logic
function generateSlotValueBasedOnLogic(dialog) {
  switch (dialog) {
    // case MATCH_FIRST_NAME: {
    //   let lastName = safeGet(slots, [LAST_NAME, "value", "interpretedValue"]);
    //   if (lastName) {
    //     event.sessionState.sessionAttributes.lexIntent = FIRST_NAME_INTENT;
    //     return lastName;
    //   } else return false;
    // }
    // case MATCH_LAST_NAME: {
    //   let firstName = safeGet(slots, [FIRST_NAME, "value", "interpretedValue"]);
    //   if (firstName) {
    //     event.sessionState.sessionAttributes.lexIntent = LAST_NAME_INTENT;
    //     return firstName;
    //   } else return false;
    // }
    default:
      return false;
  }
}

// Function to validate the slot value based on the dialog name
function validateAndUpdateSlotValue(
  dialog,
  supportedSlot,
  slotName,
  slotValue
) {
  let updatedSlotValue;
  switch (dialog) {
    case "get_phone":
      if (slotName === NUMBER_SLOT) {
        if (slotValue.length === 10) {
          updatedSlotValue = "+1" + slotValue;
          return { isValid: true, updatedSlotValue };
        }
        if (slotValue.length === 11) {
          updatedSlotValue = "+" + slotValue;
          return { isValid: true, updatedSlotValue };
        } else {
          return { isValid: false };
        }
      } else {
        return { isValid: false };
      }
    // case "jcp_num":
    //   if (slotName === NUMBER_SLOT && slotValue.length === 9) {
    //     return true;
    //   } else {
    //     return false;
    //   }

    // Default case: consider the slot value as valid for other slot names
    default:
      if (slotName === NUMBER_SLOT) {
        let parts = supportedSlot.split(":");
        if (parts.length === 2) {
          let range = parts[1].trim();
          let slotLength = slotValue.length;

          if (range.includes("-")) {
            let [minLength, maxLength] = range
              .split("-")
              .map((num) => parseInt(num.trim()));
            return {
              isValid: slotLength >= minLength && slotLength <= maxLength,
            };
          } else {
            let requiredLength = parseInt(range);
            return { isValid: slotLength === requiredLength };
          }
        }
      }

      return { isValid: true };
  }
}

// Function to process slots based on slotNames and whether they are required or optional
const processSlots = (
  event,
  selectedInterpretation,
  supportedSlots,
  slotType
) => {
  const selectedInterpretationSlots = selectedInterpretation.intent.slots;
  const dialog = event.sessionState.sessionAttributes.dialog_name;

  const remainingSlots = [];
  for (const supportedSlot of supportedSlots) {
    let slotName = supportedSlot.split(":")[0];
    if (
      !event.sessionState.sessionAttributes[
        slotType + "_slot_" + supportedSlots.indexOf(supportedSlot)
      ]
    ) {
      // Retrieve slotValue using safeGet or generate a slot value based on logic
      let slotValue =
        safeGet(selectedInterpretationSlots, [
          slotName,
          "value",
          "interpretedValue",
        ]) || generateSlotValueBasedOnLogic(dialog);
      if (slotValue) {
        const { isValid, updatedSlotValue } = validateAndUpdateSlotValue(
          dialog,
          supportedSlot,
          slotName,
          slotValue
        );
        if (updatedSlotValue !== undefined) {
          slotValue = updatedSlotValue;
        }
        if (isValid) {
          // Assign valid slotValue to sessionAttributes
          event.sessionState.sessionAttributes[
            slotType + "_slot_" + supportedSlots.indexOf(supportedSlot)
          ] = slotValue;
          event.ivrTrail += "," + slotName + ":" + slotValue;
        } else {
          remainingSlots.push(supportedSlot);
        }
      } else {
        remainingSlots.push(supportedSlot);
      }
    }
  }
  return remainingSlots;
};

function checkDtmfOptions(event, interpretation) {
  let slots = interpretation.intent.slots;
  // Retrieve the interpreted value from the NUMBER_SLOT in the slots object
  let numberSlotValue = safeGet(slots, [
    NUMBER_SLOT,
    "value",
    "interpretedValue",
  ]);

  // Check if a numeric slot value is present
  if (numberSlotValue) {
    if (
      // Check for a mapped DTMF option in session attributes
      safeGet(event, [
        "sessionState",
        "sessionAttributes",
        "dtmf_option_" + numberSlotValue,
      ])
    ) {
      // Set lexIntent based on the mapped DTMF option
      event.sessionState.sessionAttributes.lexIntent = safeGet(event, [
        "sessionState",
        "sessionAttributes",
        "dtmf_option_" + numberSlotValue,
      ]);

      event.sessionState.sessionAttributes.nluConfidence = 1;
      event.sessionState.sessionAttributes.IVR_Trail +=
        " ~ " +
        event.inputTranscript +
        " - " +
        event.sessionState.sessionAttributes.lexIntent;

      return true;
    }
  }
  return false;
}

async function invokeLex(event) {
  const sessionId = event.sessionState.sessionAttributes.customSessionId;
  const botId = event.bot.id;
  const botAliasId = event.bot.aliasId;
  const localeId = event.bot.localeId;
  let inputText = event.inputTranscript;

  event.sessionState.sessionAttributes.nestedCall = "true";

  let activeContexts = [];
  if (localeId === "en_US") {
    let supportedContexts =
      event.sessionState.sessionAttributes.supported_contexts
        ?.split(";")
        ?.map((s) => s.trim()) || [];
    if (supportedContexts.length > 0) {
      for (let supportedContext of supportedContexts) {
        let context = {
          name: supportedContext,
          contextAttributes: {},
          timeToLive: {
            timeToLiveInSeconds: 90,
            turnsToLive: 3,
          },
        };
        activeContexts.push(context);
      }
    }
  }

  try {
    const command = new RecognizeTextCommand({
      botId,
      botAliasId,
      localeId,
      sessionId,
      text: inputText,
      sessionState: {
        sessionAttributes: event.sessionState.sessionAttributes,
        activeContexts,
      },
    });

    const lexResponse = await lexClient.send(command);
    console.log(
      "RecognizeTextCommand response:",
      JSON.stringify(lexResponse, null, 2)
    );
    let response;
    if (lexResponse?.sessionState?.dialogAction?.type === "Close") {
      response = {
        sessionState: {
          dialogAction: {
            type: "Close",
          },
          sessionAttributes: lexResponse?.sessionState?.sessionAttributes,
          intent: lexResponse?.sessionState.intent,
        },
      };
      response.sessionState.intent.confirmationState = "Confirmed";
    } else if (
      lexResponse?.sessionState?.dialogAction?.type === "ElicitIntent"
    ) {
      response = {
        sessionState: {
          sessionAttributes: lexResponse?.sessionState?.sessionAttributes,
          dialogAction: {
            type: "ElicitIntent",
          },
        },
      };
    }

    if (lexResponse.messages) {
      response.messages = lexResponse.messages;
    }
    response.sessionState.sessionAttributes.nestedCall = "false";

    console.log("lex response", JSON.stringify(response, null, 2));

    return response;
  } catch (error) {
    console.error("Error communicating with Lex:", error);
    throw error;
  }
}

// Lambda function entry point
exports.handler = async (event) => {
  console.log("Event: " + JSON.stringify(event));
  event.sessionState.sessionAttributes.inputTranscript = event.inputTranscript;
  if (event.sessionState.sessionAttributes.firstConnectInvocation === "true") {
    event.sessionState.sessionAttributes = {
      ...event.sessionState.sessionAttributes,
      ...JSON.parse(
        event.sessionState.sessionAttributes.lex_session_attributes
      ),
    };
    event.sessionState.sessionAttributes.firstConnectInvocation === "false";
  }

  // if (event.inputMode === "Text") {
  //   event.sessionState.sessionAttributes.isChat = "true";
  if (event.sessionState.sessionAttributes.isChat === "true") {
    if (
      event.sessionState.sessionAttributes.lexWarmer !== "true" &&
      event.sessionState.sessionAttributes.initialize !== "true" &&
      event.bot.localeId === "en_US" &&
      event.sessionState.sessionAttributes.supported_contexts
    ) {
      // event.sessionState.sessionAttributes.isChat = "true";
      if (!event.sessionState.sessionAttributes.customSessionId) {
        event.sessionState.sessionAttributes.customSessionId = uuidv4();
        console.log(
          "Generated UUID:",
          event.sessionState.sessionAttributes.customSessionId
        );
      }
      if (event.sessionState.sessionAttributes.nestedCall !== "true") {
        return invokeLex(event);
      }
    }
  }
  // Extract supported intents from session attributes
  let supportedIntents =
    event.sessionState.sessionAttributes.supported_intents?.split(";");

  if (!supportedIntents) {
    return close(
      event.sessionState.sessionAttributes,
      "Fulfilled",
      event.sessionState.intent.name,
      event.sessionState.intent.slots
    );
  }

  supportedIntents = supportedIntents.map((s) => s.trim());
  console.log("Supported Intents: ", supportedIntents);

  const requiredSlots = (
    event.sessionState.sessionAttributes.required_slots || ""
  )
    .split(";")
    .filter(Boolean)
    .map((s) => s.trim());

  console.log("requiredSlots: ", requiredSlots);

  const optionalSlots = (
    event.sessionState.sessionAttributes.optional_slots || ""
  )
    .split(";")
    .filter(Boolean)
    .map((s) => s.trim());

  console.log("optionalSlots: ", optionalSlots);

  let intentName = event.sessionState.intent.name;
  let isIntentSelected = false;
  let dtmfOptionSelected = false;
  let selectedInterpretation;

  if (intentName !== FALLBACK_INTENT) {
    if (event.bot.localeId !== "en_US" || event.sessionState.sessionAttributes.resolve_conflict === "true") {
      // Iterate through interpretations and select a valid intent
      for (let interpretation of event.interpretations) {
        let interpretationIntentName = interpretation.intent.name;

        console.log("interpretationIntentName: ", interpretationIntentName);
        console.log(
          "interpretation[nluConfidence]: ",
          safeGet(interpretation, ["nluConfidence"])
        );

        if (interpretationIntentName === FALLBACK_INTENT) {
          break;
        }
        // Check if the interpretation meets the conditions for intent selection
        if (
          ((intentName === interpretationIntentName) || (safeGet(interpretation, ["nluConfidence"]) > MIN_NLU_CONFIDENCE)) &&
          (supportedIntents.includes(interpretationIntentName) ||
            interpretationIntentName === NUMERIC_INTENT) &&
          hasValidSlot(event, interpretation, requiredSlots, optionalSlots)
        ) {
          console.log(
            "Selected interpretationIntentName: ",
            interpretationIntentName
          );

          if (interpretationIntentName === NUMERIC_INTENT) {
            dtmfOptionSelected = checkDtmfOptions(event, interpretation);

            if (dtmfOptionSelected) {
              isIntentSelected = true;
              break;
            } else if (
              hasNoRequiredOrOptionalSlots(
                interpretation.intent,
                requiredSlots,
                optionalSlots
              )
            ) {
              continue;
            }
          }

          isIntentSelected = true;
          selectedInterpretation = interpretation;
          break;
        }
      }
    } else {
      let interpretation = event.interpretations[0];
      let interpretationIntentName = interpretation.intent.name;

      console.log("IntentName: ", interpretationIntentName);
      console.log(
        "nluConfidence: ",
        safeGet(interpretation, ["nluConfidence"])
      );

      // Check if the interpretation meets the conditions for intent selection
      if (
        (supportedIntents.includes(interpretationIntentName) ||
          interpretationIntentName === NUMERIC_INTENT) &&
        hasValidSlot(event, interpretation, requiredSlots, optionalSlots)
      ) {
        console.log("Selected intent: ", interpretationIntentName);

        if (interpretationIntentName === NUMERIC_INTENT) {
          dtmfOptionSelected = checkDtmfOptions(event, interpretation);
          if (
            dtmfOptionSelected ||
            !hasNoRequiredOrOptionalSlots(
              interpretation.intent,
              requiredSlots,
              optionalSlots
            )
          ) {
            isIntentSelected = true;
            selectedInterpretation = interpretation;
          }
        } else {
          isIntentSelected = true;
          selectedInterpretation = interpretation;
        }
      }
    }
  }

  if (isIntentSelected) {
    if (
      dtmfOptionSelected ||
      hasNoRequiredOrOptionalSlots(
        selectedInterpretation.intent,
        requiredSlots,
        optionalSlots
      )
    ) {
      if (!dtmfOptionSelected) {
        event.sessionState.sessionAttributes.nluConfidence = safeGet(
          selectedInterpretation,
          ["nluConfidence"]
        );
        event.sessionState.sessionAttributes.lexIntent =
          selectedInterpretation.intent.name;
        event.sessionState.intent.name = selectedInterpretation.intent.name;
        event.sessionState.intent.slots = selectedInterpretation.intent.slots;
        event.sessionState.sessionAttributes.IVR_Trail +=
          " ~ " + selectedInterpretation.intent.name;
      }
      // await updateIvrTrail(event);
      // add mapping to fulfill actual intent from interpretations when there is a mapping available
      return close(
        event.sessionState.sessionAttributes,
        "Fulfilled",
        event.sessionState.intent.name,
        event.sessionState.intent.slots
      );
    } else {
      event.ivrTrail = "";
      // Process required and optional slots to determine remaining slots
      const remainingRequiredSlots = processSlots(
        event,
        selectedInterpretation,
        requiredSlots,
        "required"
      );
      const remainingOptionalSlots = processSlots(
        event,
        selectedInterpretation,
        optionalSlots,
        "optional"
      );

      if (
        (requiredSlots.length > 0 && remainingRequiredSlots.length > 0) ||
        (requiredSlots.length === 0 &&
          optionalSlots.length > 0 &&
          remainingOptionalSlots.length === optionalSlots.length)
      ) {
        for (const key in event.sessionState.sessionAttributes) {
          if (
            Object.hasOwn(event.sessionState.sessionAttributes, key) &&
            (key.startsWith("optional_slot_") ||
              key.startsWith("required_slot_"))
          ) {
            delete event.sessionState.sessionAttributes[key];
          }
        }
        delete event.ivrTrail;

        return await elicitIntentWithRetries(
          event,
          event.sessionState.sessionAttributes.dialog_name
        );
      } else {
        event.sessionState.sessionAttributes.IVR_Trail +=
          " ~ " +
          selectedInterpretation.intent.name +
          "(" +
          event.ivrTrail.replace(",", "") +
          ")";
        delete event.ivrTrail;
        event.sessionState.sessionAttributes.nluConfidence = safeGet(
          selectedInterpretation,
          ["nluConfidence"]
        );
        event.sessionState.sessionAttributes.lexIntent =
          selectedInterpretation.intent.name;
        event.sessionState.intent.name = selectedInterpretation.intent.name;
        event.sessionState.intent.slots = selectedInterpretation.intent.slots;

        // await updateIvrTrail(event);
        return close(
          event.sessionState.sessionAttributes,
          "Fulfilled",
          event.sessionState.intent.name
        );
      }
    }
  } else {
    if (event.inputTranscript === "") {
      event.sessionState.sessionAttributes.allNI =
        event.sessionState.sessionAttributes.allNI !== undefined
          ? event.sessionState.sessionAttributes.allNI === "true"
          : true;
    } else {
      event.sessionState.sessionAttributes.allNI = false;
    }

    return await elicitIntentWithRetries(
      event,
      event.sessionState.sessionAttributes.dialog_name
    );
  }
};
