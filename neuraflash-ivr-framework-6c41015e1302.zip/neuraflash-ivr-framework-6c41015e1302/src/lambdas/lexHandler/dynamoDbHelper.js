const { DynamoDBDocument } = require("@aws-sdk/lib-dynamodb");
const { DynamoDB } = require("@aws-sdk/client-dynamodb");
const dynamodb = DynamoDBDocument.from(new DynamoDB());
const {
  removeBlankKeysAndValues,
  convertValuesToString
} = require("./helpers.js");

async function getDialogState(event) {
  const typing = "dialogState";
  let indexing = event.sessionState.sessionAttributes.configRef;

  let langCode = event.bot?.localeId?.replace("_", "-") || "en-US";

  const prosody = "100";
  const query = "equals";

  console.log(
    "Config Retrieval Inputs: [ typing: " +
      typing +
      " indexing: " +
      indexing +
      " query: " +
      query +
      " ]"
  );

  const params = {
    TableName: process.env.DDB_TABLE,
    KeyConditionExpression: "#typing = :typing AND #indexing = :indexing",
    ExpressionAttributeNames: {
      "#typing": "Typing",
      "#indexing": "Indexing"
    },
    ExpressionAttributeValues: {
      ":typing": typing,
      ":indexing": indexing
    }
  };

  try {
    let data = await dynamodb.query(params);
    console.log("db response", data);
    data.Items.forEach((item) => removeBlankKeysAndValues(item));
    const obj = convertValuesToString(data.Items[0], prosody);

    const paramsArray = [];

    for (let key in obj) {
      obj[key] = String(obj[key]);
      if (key.includes("_indexing") && obj[key]) {
        const params = {
          TableName: process.env.DDB_TABLE,
          KeyConditionExpression: "#typing = :typing AND #indexing = :indexing",
          ExpressionAttributeNames: {
            "#typing": "Typing",
            "#indexing": "Indexing"
          },
          ExpressionAttributeValues: {
            ":typing": "prompt",
            ":indexing":
              typing === "dialogState"
                ? langCode.toLowerCase() + "#" + obj[key]
                : obj[key]
          }
        };
        paramsArray.push({ key, params });
      }
    }

    // Use Promise.all to fetch values from DynamoDB in parallel
    const getPromises = paramsArray.map(async ({ key, params }) => {
      try {
        const result = await dynamodb.query(params);
        const value = result.Items[0].prompt_value;
        // Apply SSML and Prosody formatting
        let replacedKey = key.replaceAll(/_indexing/g, "");

        let replacedValue = value.replace(/\$(\w+)/g, (match, variable) => {
          // Check if the variable is defined in the variables object
          if (Object.hasOwn(event.sessionState.sessionAttributes, variable)) {
            // Get the value of the variable from the variables object
            return event.sessionState.sessionAttributes[variable];
          } else {
            // If the variable is not defined, return the original placeholder
            return match;
          }
        });

        obj[replacedKey] =
          `<speak><prosody rate="${prosody}%">${replacedValue}</prosody></speak>`;
      } catch (error) {
        console.error(`Error fetching ${key} from DynamoDB:`, error);
      }
    });

    await Promise.all(getPromises);

    console.log(`obj: ${JSON.stringify(obj)}`);

    return obj;
  } catch (error) {
    console.error("Error:", error);
    throw error;
  }
}

module.exports = {
  getDialogState
};
