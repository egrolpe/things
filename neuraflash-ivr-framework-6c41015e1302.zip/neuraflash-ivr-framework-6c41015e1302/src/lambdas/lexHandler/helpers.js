const {
  ConnectClient,
  UpdateContactAttributesCommand
} = require("@aws-sdk/client-connect");

const SLOT_PROMPTS = {};

// safely retrieve nested properties of an object without encountering errors due to undefined properties in the object. By returning the errorValue instead of throwing an error, this function provides a way to handle missing properties in a more graceful way.
function safeGet(obj, path, errorValue = undefined) {
  return path.reduce(
    (xs, x) => (xs && xs[x] !== undefined ? xs[x] : errorValue),
    obj
  );
}

function elicitSlot(
  sessionAttributes,
  IntentName,
  slots,
  slotToElicit,
  message
) {
  const response = {
    sessionState: {
      sessionAttributes: sessionAttributes,
      dialogAction: {
        slotToElicit: slotToElicit,
        type: "ElicitSlot"
      },
      intent: {
        name: IntentName,
        slots: slots
      }
    }
  };
  if (message) {
    if (message.indexOf("<speak>") === -1) {
      message = "<speak>" + message + "</speak>";
    }
    response.messages = [{ contentType: "SSML", content: message }];
  }
  console.log("response", JSON.stringify(response, null, 2));
  return response;
}

function close(
  sessionAttributes,
  fulfillmentState,
  IntentName,
  slots,
  message
) {
  const response = {
    sessionState: {
      dialogAction: {
        type: "Close",
      },
      sessionAttributes: sessionAttributes,
      intent: {
        state: fulfillmentState,
        name: IntentName,
        slots: slots,
        confirmationState: "Confirmed",
      },
    },
  };

  if (message) {
    if (sessionAttributes.isChat !== "true" && message.content.indexOf("<speak>") === -1) {
      message.content = "<speak>" + message.content + "</speak>";
    }
    response.messages = [
      {
        contentType: sessionAttributes.isChat ? "PlainText" : "SSML",
        content: message.content,
      },
    ];
  }
  console.log("response", JSON.stringify(response, null, 2));
  return response;
}

function delegate(sessionAttributes, IntentName, slots) {
  console.log(
    "DEBUG>>delegate sessionAttributes:" +
      JSON.stringify(sessionAttributes, null, 2) +
      ", slots:" +
      JSON.stringify(slots, null, 2)
  );
  const response = {
    sessionState: {
      sessionAttributes: sessionAttributes,
      dialogAction: {
        type: "Delegate",
      },
      intent: {
        name: IntentName,
        slots: slots,
      },
    },
  };
  console.log("response", JSON.stringify(response, null, 2));
  return response;
}

function elicitIntent(sessionAttributes, locale, message) {
  if (sessionAttributes.isChat !== "true" && message.indexOf("<speak>") === -1) {
    message = "<speak>" + message + "</speak>";
  }
  const response = {
    sessionState: {
      sessionAttributes: sessionAttributes,
      dialogAction: {
        type: "ElicitIntent",
      },
    },
  };
  if (message) {
    response.messages = [
      {
        contentType: sessionAttributes.isChat ? "PlainText" : "SSML",
        content: message,
      },
    ];
  }

  let activeContexts = [];
  if (locale === "en_US") {
    let supportedContexts =
      sessionAttributes.supported_contexts
        ?.split(";")
        ?.map((s) => s.trim()) || [];
    if (supportedContexts.length > 0) {
      for (let supportedContext of supportedContexts) {
        let context = {
          name: supportedContext,
          contextAttributes: {},
          timeToLive: {
            timeToLiveInSeconds: 90,
            turnsToLive: 3,
          },
        };
        activeContexts.push(context);
      }
    }
  }
  response.sessionState.activeContexts = activeContexts;
  console.log("response", JSON.stringify(response, null, 2));
  return response;
}

async function elicitSlotWithRetries(event, requiredSlots, slotToElicit) {
  const sessionAttributes = event.sessionState.sessionAttributes;
  const intent = event.sessionState.intent;

  let retryPrompts = [];
  if (requiredSlots.length === 1) {
    for (const key in sessionAttributes) {
      if (
        Object.hasOwn(sessionAttributes, key) &&
        key.startsWith("retry_prompt_") &&
        sessionAttributes[key] !== ""
      ) {
        retryPrompts.push(sessionAttributes[key]);
      }
    }
  } else {
    retryPrompts = SLOT_PROMPTS[slotToElicit];
  }

  console.log(retryPrompts);
  if (retryPrompts.length === 0) {
    return await fallBackIntentHandler(event);
  }

  const tries = sessionAttributes[slotToElicit + "_retries"] || "0";
  const numTries = parseInt(tries);
  const numPrompts = retryPrompts.length;

  // give up with final message
  if (numTries + 1 >= numPrompts) {
    // fulfillmentState = "Failed";
    return fallBackIntentHandler(event);
  } else {
    sessionAttributes[slotToElicit + "_retries"] = String(numTries + 1);
    const message = retryPrompts[numTries];
    return elicitSlot(
      sessionAttributes,
      intent.name,
      intent.slots,
      slotToElicit,

      message
    );
  }
}

async function elicitIntentWithRetries(event, dialog) {
  const sessionAttributes = event.sessionState.sessionAttributes;
  const retryPrompts = [];

   // Collect the keys that match the criteria
  const retryPromptKeys = Object.keys(sessionAttributes)
    .filter(
      (key) =>
        key.startsWith("retry_prompt_") &&
        !key.includes("_indexing") &&
        sessionAttributes[key] !== ""
  );

  // Sort the keys based on the number suffix
  retryPromptKeys.sort((a, b) => {
    const numA = parseInt(a.split("retry_prompt_")[1]);
    const numB = parseInt(b.split("retry_prompt_")[1]);
    return numA - numB;
  });

  // Push the values into the array in order
  for (const key of retryPromptKeys) {
    retryPrompts.push(sessionAttributes[key]);
  }

  if (!retryPrompts) {
    return await fallBackIntentHandler(event);
  }

  let tries = sessionAttributes[dialog + "_retries"] || "0";

  if (!tries) {
    tries = "0";
  }

  const numTries = parseInt(tries);
  const numPrompts = retryPrompts ? retryPrompts.length : 0;

  // Give up with final message
  if (numTries + 1 > numPrompts) {
    delete sessionAttributes[dialog + "_retries"];
    return await fallBackIntentHandler(event);
  } else {
    sessionAttributes[dialog + "_retries"] = String(numTries + 1);
    const message = retryPrompts[numTries];
    if (numTries > 0) {
      event.sessionState.sessionAttributes.IVR_Trail += ", retry" + numTries;
    }
    // await updateIvrTrail(event);
    return elicitIntent(sessionAttributes, event.bot.localeId, message);
  }
}

// Fallback intent handler
async function fallBackIntentHandler(event) {
  event.sessionState.sessionAttributes.lexIntent = "fallback";
  event.sessionState.sessionAttributes.IVR_Trail += " ~ " + "fallback";
  // await updateIvrTrail(event);
  return close(
    event.sessionState.sessionAttributes,
    "Fulfilled",
    event.sessionState.intent.name,
    event.sessionState.intent.slots
  );
}

async function updateIvrTrail(event) {
  const connectClient = new ConnectClient();
  const attributes = {
    IVR_Trail: event.sessionState.sessionAttributes.IVR_Trail
  };
  const input = {
    InitialContactId: event.sessionId,
    InstanceId: process.env.CONNECT_INSTANCE_ARN.split("/").pop(),
    Attributes: attributes
  };
  const command = new UpdateContactAttributesCommand(input);
  const response = await connectClient.send(command);
  console.log("updated attributes", response);
}

function removeBlankKeysAndValues(obj) {
  Object.keys(obj).forEach((key) => {
    if (obj[key] && typeof obj[key] === "object" && !Array.isArray(obj[key])) {
      removeBlankKeysAndValues(obj[key]);
    } else if (obj[key] === "" || obj[key] === null || obj[key] === undefined) {
      delete obj[key];
    }
  });
}

function convertValuesToString(obj, prosody) {
  for (let key in obj) {
    if (
      key.includes("prompt") &&
      !key.includes("_indexing") &&
      obj[key] &&
      key !== "ConfirmReprompt"
    ) {
      obj[key] =
        `<speak><prosody rate='${prosody}%'> ${obj[key]} </prosody></speak>`;
    }
    obj[key] = String(obj[key]);
  }
  return obj;
}

module.exports = {
  safeGet,
  elicitSlot,
  elicitIntent,
  close,
  delegate,
  elicitSlotWithRetries,
  elicitIntentWithRetries,
  fallBackIntentHandler,
  updateIvrTrail,
  removeBlankKeysAndValues,
  convertValuesToString
};
