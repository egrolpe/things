process.env.MIN_NLU_CONFIDENCE = "0.7";
const { handler } = require("../index");
const testData = require("./testData");

// Mock console.log to avoid unnecessary output in the test results
console.log = jest.fn();

describe("Lambda Function Tests", () => {
  it("should handle valid speech intent with high confidence", async () => {    
    const result = await handler(testData.eventWithHighConfidence);
    expect(result.sessionState.sessionAttributes.lexIntent).toBe(
      "RefundOrCredit"
    );
    expect(result.sessionState.sessionAttributes.nluConfidence).toBe(1);
    expect(result.sessionState.dialogAction.type).toBe("Close");
  });

  it("should handle valid DTMF intent", async () => {
    const result = await handler(testData.eventWithValidDtmfEvent);
    console.log(result);
    expect(result.sessionState.sessionAttributes.lexIntent).toBe("yes");
    expect(result.sessionState.dialogAction.type).toBe("Close");
  });

  it("should handle no input for fallback intent", async () => {
    const noInputResult = await handler(testData.eventWithNoInput);
    expect(noInputResult.sessionState.intent.name).toBe("FallbackIntent");
    expect(noInputResult.sessionState.sessionAttributes.lexIntent).toBe(
      "noInput"
    );
    expect(noInputResult.sessionState.dialogAction.type).toBe("Close");
  });

  it("should handle no match for fallback intent", async () => {
    const noMatchResult = await handler(testData.eventWithNoMatch);
    expect(noMatchResult.sessionState.sessionAttributes.lexIntent).toBe(
      "noMatch"
    );
    expect(noMatchResult.sessionState.intent.name).toBe("FallbackIntent");
    expect(noMatchResult.sessionState.dialogAction.type).toBe("Close");
  });

  it("should handle no supported intents", async () => {
    const result = await handler(testData.eventWithoutSupportedIntents);

    expect(result.sessionState.intent.name).toBe("RefundOrCredit");
    expect(result.sessionState.dialogAction.type).toBe("Close");
  });

  it("should handle valid speech intent with multiple interpretations", async () => {
    const result = await handler(testData.eventWithMultipleInterpretations);

    expect(result.sessionState.intent.name).toBe("RefundOrCredit");
    expect(result.sessionState.sessionAttributes.lexIntent).toBe(
      "refundorcredit"
    );
    expect(result.sessionState.dialogAction.type).toBe("Close");
  });

  it("should handle DTMF intent without dtmf options", async () => {
    const result = await handler(testData.eventWithoutDtmfOptionsEvent);

    expect(result.sessionState.sessionAttributes.lexIntent).toBe("fallback");
    expect(result.sessionState.intent.name).toBe("FallbackIntent");
    expect(result.sessionState.dialogAction.type).toBe("Close");
  });

  it("should handle intent with low confidence", async () => {
    const result = await handler(testData.eventWithLowConfidence);

    expect(result.sessionState.sessionAttributes.lexIntent).toBe("noMatch");
    expect(result.sessionState.dialogAction.type).toBe("Close");
  });
});
