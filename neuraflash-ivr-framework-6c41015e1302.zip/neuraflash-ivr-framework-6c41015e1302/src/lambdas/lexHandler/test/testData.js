module.exports.eventWithHighConfidence = {
  requestAttributes: {
    "x-amz-lex:accept-content-types": "PlainText,SSML",
    "x-amz-lex:channels:platform": "Connect"
  },
  sessionId: "771fdb9a-6ca4-44bd-ab4c-b91ef797b803",
  inputTranscript: "i need a refund",
  rawInputTranscript: "i need a refund",
  interpretations: [
    {
      nluConfidence: 1,
      intent: {
        name: "RefundOrCredit",
        slots: {
          cxRefundOrCreditSlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [
                "I need a refund",
                "I need a complete refund",
                "I need to request a refund",
                "I need help with my refund"
              ],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.16,
      intent: {
        name: "FoodQuality",
        slots: {
          cxFoodQualitySlot: {
            value: {
              originalValue: "need a refund",
              resolvedValues: [],
              interpretedValue: "need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.14,
      intent: {
        name: "GiftCardInquiry",
        slots: {
          cxGiftCardInquirySlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      intent: {
        name: "FallbackIntent",
        slots: {},
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.13,
      intent: {
        name: "IssuesWithPayment",
        slots: {
          cxIssuesWithPaymentSlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    }
  ],
  bot: {
    name: "Cx",
    version: "1",
    localeId: "en_US",
    id: "PSAYU8NUSB",
    aliasId: "MS1RD4YZH2",
    aliasName: "active"
  },
  responseContentType: "text/plain; charset=utf-8",
  sessionState: {
    sessionAttributes: {
      supported_intents:
        "neverdelivered; missingorincorrectitems; promodiscount; cancelorder; dashpassinquiries; accountupdate; customerservice; issueswithpayment; orderstatus; reportunauthorizedcharges; RefundOrCredit; whywasordercanceled; accountdeactivation; foodquality; potentialdasher; accountreactivation; giftcardinquiry; wrongorder",
      dtmf_option_4: "",
      dtmf_option_5: "",
      dtmf_option_6: "",
      "x-amz-lex:dtmf:end-timeout-ms:*:*": "50",
      "x-amz-lex:allow-interrupt:*:*": "true",
      "x-amz-lex:audio:start-timeout-ms:*:*": "4000",
      dtmf_option_0: "customerservice",
      dtmf_option_1: "",
      "x-amz-lex:audio:end-timeout-ms:*:*": "200",
      dtmf_option_2: "",
      "x-amz-lex:audio:max-length-ms:*:*": "13000",
      dtmf_option_3: ""
    },
    activeContexts: [],
    intent: {
      name: "RefundOrCredit",
      slots: {
        cxRefundOrCreditSlot: {
          value: {
            originalValue: "i need a refund",
            resolvedValues: [
              "I need a refund",
              "I need a complete refund",
              "I need to request a refund",
              "I need help with my refund"
            ],
            interpretedValue: "i need a refund"
          },
          shape: "Scalar"
        }
      },
      state: "ReadyForFulfillment",
      confirmationState: "None"
    },
    originatingRequestId: "65601223-fdb6-4c13-bfca-2668e8d79b37"
  },
  messageVersion: "1.0",
  invocationSource: "FulfillmentCodeHook",
  transcriptions: [
    {
      transcriptionConfidence: 0.92,
      resolvedContext: {
        intent: "RefundOrCredit"
      },
      transcription: "i need a refund",
      rawTranscription: "i need a refund",
      resolvedSlots: {
        cxRefundOrCreditSlot: {
          value: {
            originalValue: "i need a refund",
            resolvedValues: [
              "I need a refund",
              "I need a complete refund",
              "I need to request a refund",
              "I need help with my refund"
            ]
          },
          shape: "Scalar"
        }
      }
    }
  ],
  inputMode: "Speech"
};

module.exports.eventWithValidDtmfEvent = {
  inputMode: "Text",
  requestAttributes: {
    "x-amz-lex:accept-content-types": "PlainText,SSML",
    "x-amz-lex:channels:platform": "Connect"
  },
  sessionId: "5607918f-f6a8-4c21-909a-6ed5d3db06af",
  inputTranscript: "1",
  interpretations: [
    {
      interpretationSource: "Lex",
      intent: {
        name: "FallbackIntent",
        slots: {},
        state: "InProgress",
        confirmationState: "None"
      }
    },
    {
      interpretationSource: "Lex",
      nluConfidence: 0.53,
      intent: {
        name: "yes",
        slots: {
          yesSlot: null
        },
        state: "InProgress",
        confirmationState: "None"
      }
    },
    {
      interpretationSource: "Lex",
      nluConfidence: 0.5,
      intent: {
        name: "customer",
        slots: {
          customerSlot: null
        },
        state: "InProgress",
        confirmationState: "None"
      }
    },
    {
      interpretationSource: "Lex",
      nluConfidence: 0.49,
      intent: {
        name: "CustomerService",
        slots: {
          CustomerServiceSlot: null
        },
        state: "InProgress",
        confirmationState: "None"
      }
    },
    {
      interpretationSource: "Lex",
      nluConfidence: 0.45,
      intent: {
        name: "no",
        slots: {
          noSlot: null
        },
        state: "InProgress",
        confirmationState: "None"
      }
    }
  ],
  bot: {
    name: "PersonaYesNo",
    version: "2",
    localeId: "en_US",
    id: "HD28LCY2MR",
    aliasId: "IOJK1ETPVF",
    aliasName: "active"
  },
  responseContentType: "text/plain; charset=utf-8",
  sessionState: {
    originatingRequestId: "bfd19131-0b2c-41a1-8346-5e5fcd1968be",
    sessionAttributes: {
      supported_intents: "yes; no; dasher; customer; merchant; customerservice",
      dtmf_option_4: "",
      dtmf_option_5: "",
      dtmf_option_6: "",
      "x-amz-lex:dtmf:end-timeout-ms:*:*": "50",
      "x-amz-lex:allow-interrupt:*:*": "true",
      "x-amz-lex:audio:start-timeout-ms:*:*": "4000",
      dtmf_option_0: "customerservice",
      dtmf_option_1: "yes",
      "x-amz-lex:audio:end-timeout-ms:*:*": "200",
      dtmf_option_2: "no",
      "x-amz-lex:audio:max-length-ms:*:*": "13000",
      dtmf_option_3: ""
    },
    intent: {
      name: "FallbackIntent",
      slots: {},
      state: "InProgress",
      confirmationState: "None"
    }
  },
  messageVersion: "1.0",
  invocationSource: "DialogCodeHook",
  transcriptions: [
    {
      resolvedContext: {
        intent: "FallbackIntent"
      },
      resolvedSlots: {},
      transcriptionConfidence: 1,
      transcription: "1"
    }
  ]
};

module.exports.eventWithNoInput = {
  requestAttributes: {
    "x-amz-lex:accept-content-types": "PlainText,SSML",
    "x-amz-lex:channels:platform": "Connect"
  },
  sessionId: "5607918f-f6a8-4c21-909a-6ed5d3db06af",
  inputTranscript: "",
  rawInputTranscript: "",
  interpretations: [
    {
      nluConfidence: 1,
      intent: {
        confirmationState: "None",
        name: "FallbackIntent",
        slots: {},
        state: "InProgress"
      },
      interpretationSource: "Lex"
    }
  ],
  bot: {
    aliasId: "IOJK1ETPVF",
    aliasName: "active",
    name: "PersonaYesNo",
    version: "2",
    localeId: "en_US",
    id: "HD28LCY2MR"
  },
  sessionState: {
    sessionAttributes: {
      supported_intents: "yes; no; dasher; customer; merchant; customerservice",
      dtmf_option_4: "",
      dtmf_option_5: "",
      dtmf_option_6: "",
      "x-amz-lex:dtmf:end-timeout-ms:*:*": "50",
      "x-amz-lex:allow-interrupt:*:*": "true",
      "x-amz-lex:audio:start-timeout-ms:*:*": "4000",
      dtmf_option_0: "customerservice",
      dtmf_option_1: "yes",
      "x-amz-lex:audio:end-timeout-ms:*:*": "200",
      dtmf_option_2: "no",
      "x-amz-lex:audio:max-length-ms:*:*": "13000",
      dtmf_option_3: ""
    },
    activeContexts: [],
    intent: {
      confirmationState: "None",
      name: "FallbackIntent",
      slots: {},
      state: "InProgress"
    },
    originatingRequestId: "bfd19131-0b2c-41a1-8346-5e5fcd1968be"
  },
  messageVersion: "1.0",
  invocationSource: "DialogCodeHook",
  responseContentType: "text/plain; charset=utf-8",
  transcriptions: [
    {
      resolvedContext: {
        intent: "FallbackIntent"
      },
      resolvedSlots: {},
      transcriptionConfidence: 1,
      transcription: "",
      rawTranscription: ""
    }
  ],
  inputMode: "Speech"
};

module.exports.eventWithNoMatch = {
  requestAttributes: {
    "x-amz-lex:accept-content-types": "PlainText,SSML",
    "x-amz-lex:channels:platform": "Connect"
  },
  sessionId: "771fdb9a-6ca4-44bd-ab4c-b91ef797b803",
  inputTranscript: "i don't care i didn't call to test alexa bot",
  rawInputTranscript: "i don't care i didn't call to test alexa bot",
  interpretations: [
    {
      intent: {
        name: "FallbackIntent",
        slots: {},
        state: "InProgress",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.21,
      intent: {
        name: "cxAccountDeactivation",
        slots: {
          cxAccountDeactivationSlot: null
        },
        state: "InProgress",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.19,
      intent: {
        name: "cxPotentialDasher",
        slots: {
          cxPotentialDasherSlot: null
        },
        state: "InProgress",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.18,
      intent: {
        name: "cxReportUnauthorizedCharges",
        slots: {
          cxReportUnauthorizedChargesSlot: {
            value: {
              originalValue: "to bot",
              resolvedValues: [],
              interpretedValue: "to bot"
            },
            shape: "Scalar"
          }
        },
        state: "InProgress",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.15,
      intent: {
        name: "cxAccountReactivation",
        slots: {
          cxAccountReactivationSlot: {
            value: {
              originalValue: "call to",
              resolvedValues: ["I'm calling to get my account reactivated"],
              interpretedValue: "call to"
            },
            shape: "Scalar"
          }
        },
        state: "InProgress",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    }
  ],
  bot: {
    name: "Cx",
    version: "1",
    localeId: "en_US",
    id: "PSAYU8NUSB",
    aliasId: "MS1RD4YZH2",
    aliasName: "active"
  },
  responseContentType: "text/plain; charset=utf-8",
  sessionState: {
    sessionAttributes: {
      supported_intents:
        "cxneverdelivered; cxmissingorincorrectitems; cxpromodiscount; cxcancelorder; cxdashpassinquiries; cxaccountupdate; cxcustomerservice; cxissueswithpayment; cxorderstatus; cxreportunauthorizedcharges; cxRefundOrCredit; cxwhywasordercanceled; cxaccountdeactivation; cxfoodquality; cxpotentialdasher; cxaccountreactivation; cxgiftcardinquiry; cxwrongorder",
      dtmf_option_4: "",
      dtmf_option_5: "",
      dtmf_option_6: "",
      "x-amz-lex:dtmf:end-timeout-ms:*:*": "50",
      "x-amz-lex:allow-interrupt:*:*": "true",
      "x-amz-lex:audio:start-timeout-ms:*:*": "4000",
      dtmf_option_0: "cxcustomerservice",
      dtmf_option_1: "",
      "x-amz-lex:audio:end-timeout-ms:*:*": "200",
      dtmf_option_2: "",
      "x-amz-lex:audio:max-length-ms:*:*": "13000",
      dtmf_option_3: ""
    },
    intent: {
      name: "FallbackIntent",
      slots: {},
      state: "InProgress",
      confirmationState: "None"
    },
    originatingRequestId: "65601223-fdb6-4c13-bfca-2668e8d79b37"
  },
  messageVersion: "1.0",
  invocationSource: "DialogCodeHook",
  transcriptions: [
    {
      transcriptionConfidence: 0.79,
      resolvedContext: {
        intent: "FallbackIntent"
      },
      transcription: "i don't care i didn't call to test alexa bot",
      rawTranscription: "i don't care i didn't call to test alexa bot",
      resolvedSlots: {}
    },
    {
      transcriptionConfidence: 0.69,
      resolvedContext: {},
      transcription: "i don't care i didn't call the test alexa bot",
      rawTranscription: "i don't care i didn't call the test alexa bot",
      resolvedSlots: {}
    },
    {
      transcriptionConfidence: 0.6,
      resolvedContext: {},
      transcription: "i don't care i didn't call to test the bot",
      rawTranscription: "i don't care i didn't call to test the bot",
      resolvedSlots: {}
    }
  ],
  inputMode: "Speech"
};

module.exports.eventWithoutSupportedIntents = {
  requestAttributes: {
    "x-amz-lex:accept-content-types": "PlainText,SSML",
    "x-amz-lex:channels:platform": "Connect"
  },
  sessionId: "771fdb9a-6ca4-44bd-ab4c-b91ef797b803",
  inputTranscript: "i need a refund",
  rawInputTranscript: "i need a refund",
  interpretations: [
    {
      nluConfidence: 1,
      intent: {
        name: "RefundOrCredit",
        slots: {
          cxRefundOrCreditSlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [
                "I need a refund",
                "I need a complete refund",
                "I need to request a refund",
                "I need help with my refund"
              ],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.16,
      intent: {
        name: "FoodQuality",
        slots: {
          cxFoodQualitySlot: {
            value: {
              originalValue: "need a refund",
              resolvedValues: [],
              interpretedValue: "need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.14,
      intent: {
        name: "GiftCardInquiry",
        slots: {
          cxGiftCardInquirySlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      intent: {
        name: "FallbackIntent",
        slots: {},
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.13,
      intent: {
        name: "IssuesWithPayment",
        slots: {
          cxIssuesWithPaymentSlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    }
  ],
  bot: {
    name: "Cx",
    version: "1",
    localeId: "en_US",
    id: "PSAYU8NUSB",
    aliasId: "MS1RD4YZH2",
    aliasName: "active"
  },
  responseContentType: "text/plain; charset=utf-8",
  sessionState: {
    sessionAttributes: {
      dtmf_option_4: "",
      dtmf_option_5: "",
      dtmf_option_6: "",
      "x-amz-lex:dtmf:end-timeout-ms:*:*": "50",
      "x-amz-lex:allow-interrupt:*:*": "true",
      "x-amz-lex:audio:start-timeout-ms:*:*": "4000",
      dtmf_option_0: "customerservice",
      dtmf_option_1: "",
      "x-amz-lex:audio:end-timeout-ms:*:*": "200",
      dtmf_option_2: "",
      "x-amz-lex:audio:max-length-ms:*:*": "13000",
      dtmf_option_3: ""
    },
    activeContexts: [],
    intent: {
      name: "RefundOrCredit",
      slots: {
        cxRefundOrCreditSlot: {
          value: {
            originalValue: "i need a refund",
            resolvedValues: [
              "I need a refund",
              "I need a complete refund",
              "I need to request a refund",
              "I need help with my refund"
            ],
            interpretedValue: "i need a refund"
          },
          shape: "Scalar"
        }
      },
      state: "ReadyForFulfillment",
      confirmationState: "None"
    },
    originatingRequestId: "65601223-fdb6-4c13-bfca-2668e8d79b37"
  },
  messageVersion: "1.0",
  invocationSource: "FulfillmentCodeHook",
  transcriptions: [
    {
      transcriptionConfidence: 0.92,
      resolvedContext: {
        intent: "RefundOrCredit"
      },
      transcription: "i need a refund",
      rawTranscription: "i need a refund",
      resolvedSlots: {
        cxRefundOrCreditSlot: {
          value: {
            originalValue: "i need a refund",
            resolvedValues: [
              "I need a refund",
              "I need a complete refund",
              "I need to request a refund",
              "I need help with my refund"
            ]
          },
          shape: "Scalar"
        }
      }
    }
  ],
  inputMode: "Speech"
};

module.exports.eventWithMultipleInterpretations = {
  requestAttributes: {
    "x-amz-lex:accept-content-types": "PlainText,SSML",
    "x-amz-lex:channels:platform": "Connect"
  },
  sessionId: "771fdb9a-6ca4-44bd-ab4c-b91ef797b803",
  inputTranscript: "i need a refund",
  rawInputTranscript: "i need a refund",
  interpretations: [
    {
      nluConfidence: 1,
      intent: {
        name: "FoodQuality",
        slots: {
          cxFoodQualitySlot: {
            value: {
              originalValue: "need a refund",
              resolvedValues: [],
              interpretedValue: "need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.9,
      intent: {
        name: "RefundOrCredit",
        slots: {
          cxRefundOrCreditSlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [
                "I need a refund",
                "I need a complete refund",
                "I need to request a refund",
                "I need help with my refund"
              ],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },

    {
      nluConfidence: 0.14,
      intent: {
        name: "GiftCardInquiry",
        slots: {
          cxGiftCardInquirySlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      intent: {
        name: "FallbackIntent",
        slots: {},
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.13,
      intent: {
        name: "IssuesWithPayment",
        slots: {
          cxIssuesWithPaymentSlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    }
  ],
  bot: {
    name: "Cx",
    version: "1",
    localeId: "en_US",
    id: "PSAYU8NUSB",
    aliasId: "MS1RD4YZH2",
    aliasName: "active"
  },
  responseContentType: "text/plain; charset=utf-8",
  sessionState: {
    sessionAttributes: {
      supported_intents:
        "neverdelivered; missingorincorrectitems; promodiscount; cancelorder; dashpassinquiries; accountupdate; customerservice; issueswithpayment; orderstatus; reportunauthorizedcharges; RefundOrCredit; whywasordercanceled; accountdeactivation; potentialdasher; accountreactivation; giftcardinquiry; wrongorder",
      dtmf_option_4: "",
      dtmf_option_5: "",
      dtmf_option_6: "",
      "x-amz-lex:dtmf:end-timeout-ms:*:*": "50",
      "x-amz-lex:allow-interrupt:*:*": "true",
      "x-amz-lex:audio:start-timeout-ms:*:*": "4000",
      dtmf_option_0: "customerservice",
      dtmf_option_1: "",
      "x-amz-lex:audio:end-timeout-ms:*:*": "200",
      dtmf_option_2: "",
      "x-amz-lex:audio:max-length-ms:*:*": "13000",
      dtmf_option_3: ""
    },
    activeContexts: [],
    intent: {
      name: "RefundOrCredit",
      slots: {
        cxRefundOrCreditSlot: {
          value: {
            originalValue: "i need a refund",
            resolvedValues: [
              "I need a refund",
              "I need a complete refund",
              "I need to request a refund",
              "I need help with my refund"
            ],
            interpretedValue: "i need a refund"
          },
          shape: "Scalar"
        }
      },
      state: "ReadyForFulfillment",
      confirmationState: "None"
    },
    originatingRequestId: "65601223-fdb6-4c13-bfca-2668e8d79b37"
  },
  messageVersion: "1.0",
  invocationSource: "FulfillmentCodeHook",
  transcriptions: [
    {
      transcriptionConfidence: 0.92,
      resolvedContext: {
        intent: "RefundOrCredit"
      },
      transcription: "i need a refund",
      rawTranscription: "i need a refund",
      resolvedSlots: {
        cxRefundOrCreditSlot: {
          value: {
            originalValue: "i need a refund",
            resolvedValues: [
              "I need a refund",
              "I need a complete refund",
              "I need to request a refund",
              "I need help with my refund"
            ]
          },
          shape: "Scalar"
        }
      }
    }
  ],
  inputMode: "Speech"
};

module.exports.eventWithoutDtmfOptionsEvent = {
  inputMode: "Text",
  requestAttributes: {
    "x-amz-lex:accept-content-types": "PlainText,SSML",
    "x-amz-lex:channels:platform": "Connect"
  },
  sessionId: "5607918f-f6a8-4c21-909a-6ed5d3db06af",
  inputTranscript: "1",
  interpretations: [
    {
      interpretationSource: "Lex",
      intent: {
        name: "FallbackIntent",
        slots: {},
        state: "InProgress",
        confirmationState: "None"
      }
    },
    {
      interpretationSource: "Lex",
      nluConfidence: 0.53,
      intent: {
        name: "yes",
        slots: {
          yesSlot: null
        },
        state: "InProgress",
        confirmationState: "None"
      }
    },
    {
      interpretationSource: "Lex",
      nluConfidence: 0.5,
      intent: {
        name: "customer",
        slots: {
          customerSlot: null
        },
        state: "InProgress",
        confirmationState: "None"
      }
    },
    {
      interpretationSource: "Lex",
      nluConfidence: 0.49,
      intent: {
        name: "CustomerService",
        slots: {
          CustomerServiceSlot: null
        },
        state: "InProgress",
        confirmationState: "None"
      }
    },
    {
      interpretationSource: "Lex",
      nluConfidence: 0.45,
      intent: {
        name: "no",
        slots: {
          noSlot: null
        },
        state: "InProgress",
        confirmationState: "None"
      }
    }
  ],
  bot: {
    name: "PersonaYesNo",
    version: "2",
    localeId: "en_US",
    id: "HD28LCY2MR",
    aliasId: "IOJK1ETPVF",
    aliasName: "active"
  },
  responseContentType: "text/plain; charset=utf-8",
  sessionState: {
    originatingRequestId: "bfd19131-0b2c-41a1-8346-5e5fcd1968be",
    sessionAttributes: {
      supported_intents: "yes; no; dasher; customer; merchant; customerservice",
      dtmf_option_4: "",
      dtmf_option_5: "",
      dtmf_option_6: "",
      "x-amz-lex:dtmf:end-timeout-ms:*:*": "50",
      "x-amz-lex:allow-interrupt:*:*": "true",
      "x-amz-lex:audio:start-timeout-ms:*:*": "4000",
      dtmf_option_0: "",
      dtmf_option_1: "",
      "x-amz-lex:audio:end-timeout-ms:*:*": "200",
      dtmf_option_2: "",
      "x-amz-lex:audio:max-length-ms:*:*": "13000",
      dtmf_option_3: ""
    },
    intent: {
      name: "FallbackIntent",
      slots: {},
      state: "InProgress",
      confirmationState: "None"
    }
  },
  messageVersion: "1.0",
  invocationSource: "DialogCodeHook",
  transcriptions: [
    {
      resolvedContext: {
        intent: "FallbackIntent"
      },
      resolvedSlots: {},
      transcriptionConfidence: 1,
      transcription: "1"
    }
  ]
};

module.exports.eventWithLowConfidence = {
  requestAttributes: {
    "x-amz-lex:accept-content-types": "PlainText,SSML",
    "x-amz-lex:channels:platform": "Connect"
  },
  sessionId: "771fdb9a-6ca4-44bd-ab4c-b91ef797b803",
  inputTranscript: "i need a refund",
  rawInputTranscript: "i need a refund",
  interpretations: [
    {
      nluConfidence: 0.6,
      intent: {
        name: "RefundOrCredit",
        slots: {
          cxRefundOrCreditSlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [
                "I need a refund",
                "I need a complete refund",
                "I need to request a refund",
                "I need help with my refund"
              ],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.16,
      intent: {
        name: "FoodQuality",
        slots: {
          cxFoodQualitySlot: {
            value: {
              originalValue: "need a refund",
              resolvedValues: [],
              interpretedValue: "need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.14,
      intent: {
        name: "GiftCardInquiry",
        slots: {
          cxGiftCardInquirySlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      intent: {
        name: "FallbackIntent",
        slots: {},
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    },
    {
      nluConfidence: 0.13,
      intent: {
        name: "IssuesWithPayment",
        slots: {
          cxIssuesWithPaymentSlot: {
            value: {
              originalValue: "i need a refund",
              resolvedValues: [],
              interpretedValue: "i need a refund"
            },
            shape: "Scalar"
          }
        },
        state: "ReadyForFulfillment",
        confirmationState: "None"
      },
      interpretationSource: "Lex"
    }
  ],
  bot: {
    name: "Cx",
    version: "1",
    localeId: "en_US",
    id: "PSAYU8NUSB",
    aliasId: "MS1RD4YZH2",
    aliasName: "active"
  },
  responseContentType: "text/plain; charset=utf-8",
  sessionState: {
    sessionAttributes: {
      supported_intents:
        "neverdelivered; missingorincorrectitems; promodiscount; cancelorder; dashpassinquiries; accountupdate; customerservice; issueswithpayment; orderstatus; reportunauthorizedcharges; RefundOrCredit; whywasordercanceled; accountdeactivation; foodquality; potentialdasher; accountreactivation; giftcardinquiry; wrongorder",
      dtmf_option_4: "",
      dtmf_option_5: "",
      dtmf_option_6: "",
      "x-amz-lex:dtmf:end-timeout-ms:*:*": "50",
      "x-amz-lex:allow-interrupt:*:*": "true",
      "x-amz-lex:audio:start-timeout-ms:*:*": "4000",
      dtmf_option_0: "customerservice",
      dtmf_option_1: "",
      "x-amz-lex:audio:end-timeout-ms:*:*": "200",
      dtmf_option_2: "",
      "x-amz-lex:audio:max-length-ms:*:*": "13000",
      dtmf_option_3: ""
    },
    activeContexts: [],
    intent: {
      name: "RefundOrCredit",
      slots: {
        cxRefundOrCreditSlot: {
          value: {
            originalValue: "i need a refund",
            resolvedValues: [
              "I need a refund",
              "I need a complete refund",
              "I need to request a refund",
              "I need help with my refund"
            ],
            interpretedValue: "i need a refund"
          },
          shape: "Scalar"
        }
      },
      state: "ReadyForFulfillment",
      confirmationState: "None"
    },
    originatingRequestId: "65601223-fdb6-4c13-bfca-2668e8d79b37"
  },
  messageVersion: "1.0",
  invocationSource: "FulfillmentCodeHook",
  transcriptions: [
    {
      transcriptionConfidence: 0.92,
      resolvedContext: {
        intent: "RefundOrCredit"
      },
      transcription: "i need a refund",
      rawTranscription: "i need a refund",
      resolvedSlots: {
        cxRefundOrCreditSlot: {
          value: {
            originalValue: "i need a refund",
            resolvedValues: [
              "I need a refund",
              "I need a complete refund",
              "I need to request a refund",
              "I need help with my refund"
            ]
          },
          shape: "Scalar"
        }
      }
    }
  ],
  inputMode: "Speech"
};
