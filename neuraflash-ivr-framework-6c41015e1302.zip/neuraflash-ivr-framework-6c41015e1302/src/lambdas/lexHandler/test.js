const { handler } = require("./index.js");

let event = {
  "sessionId": "c8a35842-722d-4686-8f2e-4b25f9094ff9",
  "requestAttributes": {
      "x-amz-lex:accept-content-types": "PlainText",
      "x-amz-lex:channels:platform": "Connect Chat"
  },
  "inputTranscript": "23456",
  "interpretations": [
      {
          "interpretationSource": "Lex",
          "nluConfidence": 1,
          "intent": {
              "name": "number",
              "slots": {
                  "number_slot": {
                      "value": {
                          "originalValue": "23456",
                          "resolvedValues": [
                              "23456"
                          ],
                          "interpretedValue": "23456"
                      },
                      "shape": "Scalar"
                  }
              },
              "state": "InProgress",
              "confirmationState": "None"
          }
      },
      {
          "interpretationSource": "Lex",
          "intent": {
              "name": "FallbackIntent",
              "slots": {},
              "state": "InProgress",
              "confirmationState": "None"
          }
      },
      {
          "interpretationSource": "Lex",
          "nluConfidence": 0.58,
          "intent": {
              "name": "agent",
              "slots": {},
              "state": "InProgress",
              "confirmationState": "None"
          }
      },
      {
          "interpretationSource": "Lex",
          "nluConfidence": 0.43,
          "intent": {
              "name": "warm_lex",
              "slots": {},
              "state": "InProgress",
              "confirmationState": "None"
          }
      }
  ],
  "bot": {
      "name": "nf-dev-us-west-2-router-bot",
      "version": "10",
      "localeId": "en_US",
      "id": "0Z4NBEHUUP",
      "aliasId": "FSG96UKFL4",
      "aliasName": "active"
  },
  "responseContentType": "text/plain; charset=utf-8",
  "messageVersion": "1.0",
  "sessionState": {
      "originatingRequestId": "5435e8ba-cdbf-41c2-9a55-2642b6e587b5",
      "sessionAttributes": {
          "x-amz-lex:dtmf:end-timeout-ms:*:*": "4000",
          "firstConnectInvocation": "true",
          "lex_session_attributes": "{\"Typing\":\"dialogState\",\"dtmf_option_0\":\"agent\",\"x-amz-lex:text:start-timeout-ms:*:*\":\"6000\",\"x-amz-lex:text:end-timeout-ms:*:*\":\"4000\",\"required_slots\":\"number_slot:5\",\"initial_prompt_indexing\":\"get_zipcode_ini\",\"dialog_name\":\"get_phone\",\"x-amz-lex:allow-interrupt:*:*\":\"true\",\"x-amz-lex:audio:max-length-ms:*:*\":\"13000\",\"x-amz-lex:dtmf:end-timeout-ms:*:*\":\"4000\",\"retry_prompt_2_indexing\":\"get_zipcode_rep2\",\"x-amz-lex:audio:start-timeout-ms:*:*\":\"6000\",\"Indexing\":\"get_zipcode\",\"x-amz-lex:dtmf:start-timeout-ms:*:*\":\"6000\",\"bot_name\":\"{lex-prefix}-router-bot\",\"retry_prompt_1_indexing\":\"get_zipcode_rep1\",\"x-amz-lex:audio:end-timeout-ms:*:*\":\"3500\",\"supported_intents\":\"number; agent\",\"initial_prompt\":\"<speak><prosody rate=\\\"100%\\\">Can you please provide me your 5 digit zip code?</prosody></speak>\",\"retry_prompt_1\":\"<speak><prosody rate=\\\"100%\\\">Sorry, I didn’t get that. Please say your 5-digit ZIP code.</prosody></speak>\",\"botArn\":\"arn:aws:lex:us-west-2:918888467489:bot-alias/0Z4NBEHUUP/FSG96UKFL4\",\"retry_prompt_2\":\"<speak><prosody rate=\\\"100%\\\">Let’s try one more time. You can say or enter your 5-digit ZIP code using the keypad on your phone.</prosody></speak>\",\"isChat\":\"true\"}",
          "x-amz-lex:text:end-timeout-ms:*:*": "",
          "x-amz-lex:text:start-timeout-ms:*:*": "6000",
          "x-amz-lex:allow-interrupt:*:*": "true",
          "x-amz-lex:audio:start-timeout-ms:*:*": "6000",
          "x-amz-lex:dtmf:start-timeout-ms:*:*": "",
          "x-amz-lex:audio:end-timeout-ms:*:*": "3500",
          "x-amz-lex:audio:max-length-ms:*:*": "13000"
      },
      "activeContexts": [],
      "intent": {
          "name": "number",
          "slots": {
              "number_slot": {
                  "value": {
                      "originalValue": "23456",
                      "resolvedValues": [
                          "23456"
                      ],
                      "interpretedValue": "23456"
                  },
                  "shape": "Scalar"
              }
          },
          "state": "InProgress",
          "confirmationState": "None"
      }
  },
  "invocationSource": "DialogCodeHook",
  "transcriptions": [
      {
          "resolvedContext": {
              "intent": "number"
          },
          "resolvedSlots": {
              "number_slot": {
                  "value": {
                      "originalValue": "23456",
                      "resolvedValues": [
                          "23456"
                      ]
                  },
                  "shape": "Scalar"
              }
          },
          "transcriptionConfidence": 1,
          "transcription": "23456"
      }
  ],
  "inputMode": "Text"
};


handler(event);
