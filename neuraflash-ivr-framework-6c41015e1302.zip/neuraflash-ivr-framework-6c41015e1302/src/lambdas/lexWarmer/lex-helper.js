import { RecognizeTextCommand } from "@aws-sdk/client-lex-runtime-v2";
import {
  ListBotsCommand,
  ListBotVersionsCommand,
  ListBotAliasesCommand,
  ListBotLocalesCommand,
} from "@aws-sdk/client-lex-models-v2";

import * as crypto from "crypto";

export async function warmLex(client, botDetails, localeId) {
  const input = {
    botId: botDetails.botId,
    botAliasId: botDetails.botAliasId,
    localeId: localeId,
    sessionId: crypto.randomUUID(),
    text: "warm lex",
    sessionState: {
      sessionAttributes: {
        inputMode: "text",
        lexWarmer: "true",
      },
    },
    messages: [
      {
        content: "warm lex",
        contentType: "PlainText",
      },
    ],
  };

  const command1 = new RecognizeTextCommand(input);
  try {
    let result1 = await client.send(command1);
    return result1;
  } catch (error) {
    console.log(error);
  }
}

export async function botListBots(client) {
  console.log("Inside list bots");
  const input = {
    maxResults: 50
  };
  const command = new ListBotsCommand(input);
  try {
    let result = await client.send(command);
    console.log(result);
    return result;
  } catch (error) {
    console.log(error);
  }
}

export async function botListVersions(client) {
  console.log("Inside list Versions");
  const command = new ListBotVersionsCommand();
  try {
    let result = await client.send(command);
    return result;
  } catch (error) {
    console.log(error);
  }
}

export async function botListAliases(client, botDetails) {
  console.log("Inside list Aliases");

  const input = {
    botId: botDetails.botId,
    maxResults: 10
  };
  console.log(JSON.stringify(input));
  const command = new ListBotAliasesCommand(input);
  try {
    let result = client.send(command);
    console.log(JSON.stringify(result, "", 2));
    return result;
  } catch (error) {
    console.log(JSON.stringify(error, "", 2));
  }
}

export async function getLocalesForBotAlias(lexClient, botId, botVersion){
  try {
    let locales = [];
    let nextToken;

    do {
      const listBotLocalesCommand = new ListBotLocalesCommand({
        botId: botId,
        botVersion: botVersion,
        localeId: nextToken
      });
      const localeData = await lexClient.send(listBotLocalesCommand);
      locales = locales.concat(localeData.botLocaleSummaries);
      nextToken = localeData.nextToken;
    } while (nextToken);

    locales.forEach((locale) => {
      console.log(
        `Locale: ${locale.localeId}, Description: ${locale.description}`
      );
    });
    return locales;
  } catch (error) {
    console.error("Error retrieving locales for bot alias:", error);
  }
};
