import { LexRuntimeV2Client } from "@aws-sdk/client-lex-runtime-v2";

import { LexModelsV2Client } from "@aws-sdk/client-lex-models-v2";

import {
  botListBots,
  botListAliases,
  getLocalesForBotAlias,
  warmLex,
} from "./lex-helper.js";

const config = { region: process.env.region };
const client = new LexModelsV2Client(config);
const lexRunTimeClient = new LexRuntimeV2Client(config);

export const handler = async (event) => {
  console.log("Event: ", event);
  const listOfBots = [];
  let listResult = await botListBots(client);
  try {
    listResult.botSummaries.forEach((element) => {
      listOfBots.push({
        botId: element.botId,
        botName: element.botName,
        botVersion: element.latestBotVersion,
      });
    });
    // get the aliasId for each bot
    for (let bot of listOfBots) {
      let result = await botListAliases(client, bot);
      let activeAlias = result.botAliasSummaries.filter(
        (element) => element.botAliasName == "active"
      );
      if (activeAlias.length == 1) {
        console.log("Found active Alias", activeAlias[0]);
        bot.botAliasId = activeAlias[0].botAliasId;
        bot.botAliasName = "active";
        bot.botVersion = activeAlias[0].botVersion;
        bot.botAliasStatus = activeAlias[0].botAliasStatus;
      }
    }

    const activeBots = [];
    for (let bot of listOfBots) {
      console.log("Currently iterating:", bot.botName);
      if (bot.botAliasName == "active" && bot.botAliasStatus == "Available") {
        activeBots.push(bot.botName);
        const botLocales = await getLocalesForBotAlias(
          client,
          bot.botId,
          bot.botVersion
        );
        for (let botLocale of botLocales) {
          let result = await warmLex(lexRunTimeClient, bot, botLocale.localeId);
          console.log(JSON.stringify(result, "", 2));
        }
      }
    }

    let response = {
      statusCode: 200,
      body: {
        "activeBots:": activeBots,
      },
    };
    console.log(
      "These bots are sent recognize text:",
      JSON.stringify(response, "", 2)
    );
    return response;
  } catch (error) {
    console.log(JSON.stringify(error, "", 2));
    return {
      statusCode: 500,
      body: "Error:" + JSON.stringify(error),
    };
  }
};
