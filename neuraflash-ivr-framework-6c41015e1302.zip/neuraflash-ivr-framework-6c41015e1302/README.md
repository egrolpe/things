# Welcome to the Project Repository

## Useful commands

- `bash scripts/deployCdkStack.sh <stage> <region>` 
  Deploys the CDK stack for the dev environment.
  - Replace <stage> with dev, qa or prod to target the desired environment.
  - Replace <region> with the AWS region you want to deploy to.
  Example - `bash scripts/deployCdkStack.sh dev us-west-2`
    - Alternately, you can run the appropriate cdk-deploy-\<stage\> command.
    Example - `npm run cdk-deploy-dev` for the dev environment. You can see the list of available scripts in `package.json`.

- `bash scripts/getConnectResources.sh <clientPrefix> <stage>` 
   To fetch and save the connect resources and dynamo data. 
   - Replace <stage> with 'dev', 'prod' or 'qa' as per the current stage
   - Replace <clientPrefix> with the client prefix ex- nf.
   - Replace <region> with the region you want to fetch from.
   Example - `bash scripts/getConnectResources.sh nf dev us-west-2`
  
- `bash scripts/deployConnectResources.sh <clientPrefix> <stage> <region>`
  Deploy the connect resources, lex bot and dynamo data. 
  - Replace <stage> with 'dev', 'prod' or 'qa' as per the current stage
  - Replace <clientPrefix> with the client prefix.
  - Replace <region> with the region you want to deploy to.
  Example - `bash scripts/deployConnectResources.sh nf dev us-west-2`


## Setup

### Install HomeBrew

- Open Terminal and install using the command:
  `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`

When it finishes installing, there will be next step instructions. Follow them.

### Install Node.js and NPM:

- Install Node using the command: `brew install node`

Verify installation by checking version: `node -v`

\*NPM (Node Package Manager) comes with Node.js and allows us to manage packages and dependencies.

Verify installation by checking version: `npm -v`

### Install Python3:

- Install Node using the command: `brew install python`

Verify installation by checking version: `python3 --version`

### Install AWS CLI:

- Open a terminal in VS Code (`Ctrl + '`)

- If you have sudo permissions, you can install the AWS CLI for all users on the computer. We provide the steps in one easy to copy and paste group. See the descriptions of each line in the following steps.

`$ curl "https://awscli.amazonaws.com/AWSCLIV2.pkg" -o "AWSCLIV2.pkg"`
`$ sudo installer -pkg AWSCLIV2.pkg -target /`

Download the file using the curl command. The -o option specifies the file name that the downloaded package is written to. In this example, the file is written to AWSCLIV2.pkg in the current folder.

`$ curl "https://awscli.amazonaws.com/AWSCLIV2.pkg" -o "AWSCLIV2.pkg"`

Run the standard macOS installer program, specifying the downloaded .pkg file as the source. Use the -pkg parameter to specify the name of the package to install, and the -target / parameter for which drive to install the package to. The files are installed to /usr/local/aws-cli, and a symlink is automatically created in /usr/local/bin. You must include sudo on the command to grant write permissions to those folders.

`$ sudo installer -pkg ./AWSCLIV2.pkg -target /`

After installation is complete, debug logs are written to /var/log/install.log.

To verify that the shell can find and run the aws command in your $PATH, use the following command:

`aws --version`

You should get something like: “aws-cli/2.13.27 Python/3.11.6 Darwin/23.0.0 exe/x86_64 prompt/off”

If the aws command cannot be found, you might need to restart your terminal or follow the troubleshooting in Troubleshoot AWS CLI errors.

### Install AWS CDK:

- Open a terminal in VS Code.

- Install AWS CLI using the command: `sudo npm install -g aws-cdk`

- Verify installation by checking version: `cdk --version`

### Install Prettier to VS Code:

- Prettier is an opinionated code formatter, it enforces a consistent styling.

- Open VS Code and navigate to the Extensions tab (`Ctrl + Shift + X`)

- Search for Prettier - Code formatter

- Click Install

### Ensure you've configured your source control appropriately, Configure Git Identity::

\*Update the quoted value below before executing.

`git config --global user.name "Your Name"`

`git config --global user.email your.email@example.com`

## Committing Changes

### Committing Changes to the Repository

- Open a terminal in VS Code (`Ctrl + '`)
- Navigate to the project directory
- Run the following commands:
- Create a new branch: `git checkout -b <branch-name>`
- Run the lint command to ensure your code is formatted correctly: `npm run lint`
- Stage changes to the newly created branch: `git add .`
- `git commit -m "Your commit message here"`

- If you are pushing to a new branch, you will need to run the following command:
- `git push --set-upstream origin <branch-name>`

- If you are pushing to an existing branch, you can run the following command:
- `git push`

- Create a pull request on GitHub and assign request a review from @BenBurk
- Once the pull request is approved, it will be merged into the main branch
